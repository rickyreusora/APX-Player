/// <reference path="../pb_data/types.d.ts" />

// Notify users by email when an admin approves or rejects their GCash top-up.
// Fires after a credit_transactions record is updated.
onRecordAfterUpdateSuccess((e) => {
  const tx = e.record;
  const status = tx.getString("status");
  const type = tx.getString("type");

  // Only react to top-up approval/rejection actions.
  if (type !== "topup") {
    e.next();
    return;
  }
  if (status !== "completed" && status !== "rejected") {
    e.next();
    return;
  }
  // Only notify when an admin actually performed the approval/rejection
  // (approval_by is stamped by the admin panel), so unrelated updates
  // (e.g. balance_after backfills) don't spam the user.
  const approverId = tx.getString("approval_by");
  if (!approverId) {
    e.next();
    return;
  }

  const ownerId = tx.getString("owner");
  if (!ownerId) {
    e.next();
    return;
  }

  let owner = null;
  try {
    owner = $app.findRecordById("users", ownerId);
  } catch (err) {
    $app
      .logger()
      .error(
        "credit-approval: owner not found",
        "owner",
        ownerId,
        "err",
        String(err),
      );
    e.next();
    return;
  }

  const recipient = owner.getString("email");
  if (!recipient) {
    e.next();
    return;
  }

  const amount = tx.getFloat("amount") || 0;
  const reference = tx.getString("reference") || "";
  const reason = tx.getString("rejection_reason") || "";

  let subject = "";
  let html = "";

  if (status === "completed") {
    subject = "Your ApX Player top-up is approved";
    html =
      '<div style="font-family:Inter,Arial,sans-serif;max-width:560px;margin:auto">' +
      "<h2 style=\"color:#e11d48\">Your top-up is approved</h2>" +
      "<p>Hi " + (owner.getString("name") || "there") + ",</p>" +
      "<p>Your GCash payment of <strong>₱" + amount + "</strong> has been approved by our team. " +
      "The credits have been added to your ApX Player balance and you can now use them for karaoke sessions.</p>" +
      (reference ? "<p style=\"color:#666\">Reference: " + reference + "</p>" : "") +
      "<p>Thank you for using ApX Player.</p>" +
      "</div>";
  } else {
    subject = "Your ApX Player top-up was rejected";
    html =
      '<div style="font-family:Inter,Arial,sans-serif;max-width:560px;margin:auto">' +
      "<h2 style=\"color:#e11d48\">Your top-up was rejected</h2>" +
      "<p>Hi " + (owner.getString("name") || "there") + ",</p>" +
      "<p>We were unable to approve your GCash payment of <strong>₱" + amount + "</strong>.</p>" +
      (reason ? "<p><strong>Reason:</strong> " + reason + "</p>" : "<p>Please double-check your payment and try again, or contact support if you believe this is an error.</p>") +
      (reference ? "<p style=\"color:#666\">Reference: " + reference + "</p>" : "") +
      "</div>";
  }

  const message = new MailerMessage({
    from: { name: "ApX Player" },
    to: [{ address: recipient }],
    subject: subject,
    html: html,
  });

  try {
    $app.newMailClient().send(message);
  } catch (err) {
    $app
      .logger()
      .error(
        "credit-approval email failed",
        "to",
        recipient,
        "status",
        status,
        "err",
        String(err),
      );
  }

  e.next();
}, "credit_transactions");
