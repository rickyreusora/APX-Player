/// <reference path="../pb_data/types.d.ts" />

// Auto-link the Google identity for rickyjohnreusora@gmail.com as an admin.
//
// Fires during the OAuth2 sign-in/sign-up request on the `users` collection,
// after PocketBase has exchanged the provider token but before the external
// identity is linked. The `oAuth2User.email` field is the VERIFIED email
// returned by Google (PocketBase only populates it when the provider can
// verify email ownership), so we elevate to admin ONLY when that verified
// address matches the designated admin email.
//
// This never weakens authorization for any other account: every non-matching
// email is left exactly as PocketBase left it. The admin account itself is
// pre-seeded by migration 1791396015, so PocketBase resolves `e.record` by
// email; the role assignment here is the authoritative, server-side grant
// that survives any client-side createData (which can only set role='user').

onRecordAuthWithOAuth2Request((e) => {
  const ADMIN_EMAIL = "rickyjohnreusora@gmail.com";

  const oauth2User = e.oAuth2User;
  if (!oauth2User || oauth2User.email !== ADMIN_EMAIL) {
    e.next();
    return;
  }

  // The admin account is pre-seeded, so PocketBase resolves e.record by the
  // verified email. If it is somehow missing, create the record here so the
  // Google identity still links to an admin account rather than a regular
  // user created from the client createData.
  let record = e.record;
  if (!record) {
    const collection = $app.findCollectionByNameOrId("users");
    record = new Record(collection);
    record.set("email", ADMIN_EMAIL);
    if (oauth2User.name) {
      record.set("name", oauth2User.name);
    }
  }

  record.set("role", "admin");
  record.set("verified", true);
  e.record = record;

  e.next();
}, "users");
