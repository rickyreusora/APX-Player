/// <reference path="../pb_data/types.d.ts" />

// Forward every new ApX Player sign-up to the connected Reach audience.
// Fires after a user record is created in the `users` auth collection (the
// collection the existing sign-up flow writes to). Reach requires an email;
// submissions without one are skipped. Any Reach failure is logged but never
// blocks the local save — the contact is always preserved in PocketBase.

onRecordAfterCreateSuccess((e) => {
  const email = e.record.get("email");
  if (!email) {
    e.next();
    return;
  }

  try {
    $http.send({
      url: $os.getenv("REACH_API_URL") + "/api/public/v1/contacts",
      method: "POST",
      headers: {
        Authorization: "Bearer " + $os.getenv("REACH_API_TOKEN"),
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        groupName: "Hostinger AI Builder sign-up form",
        contacts: [
          {
            email: email,
            name: e.record.get("name") || "",
          },
        ],
      }),
    });
  } catch (err) {
    $app.logger().error("Reach contact sync failed", "err", String(err));
  }

  e.next();
}, "users");
