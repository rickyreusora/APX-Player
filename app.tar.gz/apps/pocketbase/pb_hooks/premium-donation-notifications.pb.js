/// <reference path="../pb_data/types.d.ts" />

// Notify users by email for premium donation events:
//  - submission confirmation (after create, status = pending)
//  - approval (premium access granted)
//  - rejection (with reason)
//
// NOTE: PocketBase runs each hook callback in an isolated JSVM scope, so a
// helper declared at the file's top level is NOT reachable inside the
// callbacks. Define every helper INSIDE the callback that uses it.

// 1) Confirmation email when a donation is submitted.
onRecordAfterCreateSuccess((e) => {
  const sendMail = (recipient, subject, html) => {
    const message = new MailerMessage({
      from: { name: "ApX Player" },
      to: [{ address: recipient }],
      subject: subject,
      html: html,
    });
    try {
      $app.newMailClient().send(message);
    } catch (err) {
      $app
        .logger()
        .error(
          "premium-donation email failed",
          "to",
          recipient,
          "err",
          String(err),
        );
    }
  };

  const donation = e.record;
  const status = donation.getString("status");
  if (status !== "pending") {
    e.next();
    return;
  }

  const ownerId = donation.getString("owner");
  if (!ownerId) {
    e.next();
    return;
  }

  let owner = null;
  try {
    owner = $app.findRecordById("users", ownerId);
  } catch (err) {
    $app.logger().error("premium-donation: owner not found", "owner", ownerId, "err", String(err));
    e.next();
    return;
  }

  const recipient = owner.getString("email");
  if (!recipient) {
    e.next();
    return;
  }

  const amount = donation.getFloat("amount") || 0;
  const reference = donation.getString("gcash_reference") || "";

  const subject = "Your ApX Player premium donation is received";
  const html =
    '<div style="font-family:Inter,Arial,sans-serif;max-width:560px;margin:auto">' +
    "<h2 style=\"color:#06b6d4\">Donation received</h2>" +
    "<p>Hi " + (owner.getString("name") || "there") + ",</p>" +
    "<p>Thank you for your GCash donation of <strong>₱" + amount + "</strong> toward ApX Player premium access.</p>" +
    "<p>Your submission is now <strong>pending admin review</strong>. Once approved, you will get premium access to Vivamax and Viva One content, and we will email you to confirm.</p>" +
    (reference ? "<p style=\"color:#666\">GCash reference: " + reference + "</p>" : "") +
    "<p>Thank you for supporting ApX Player.</p>" +
    "</div>";

  sendMail(recipient, subject, html);
  e.next();
}, "premium_donations");

// 2) Approval / rejection email when an admin updates the status.
onRecordAfterUpdateSuccess((e) => {
  const sendMail = (recipient, subject, html) => {
    const message = new MailerMessage({
      from: { name: "ApX Player" },
      to: [{ address: recipient }],
      subject: subject,
      html: html,
    });
    try {
      $app.newMailClient().send(message);
    } catch (err) {
      $app
        .logger()
        .error(
          "premium-donation email failed",
          "to",
          recipient,
          "err",
          String(err),
        );
    }
  };

  const donation = e.record;
  const status = donation.getString("status");
  if (status !== "approved" && status !== "rejected") {
    e.next();
    return;
  }
  // Only notify when an admin actually performed the action.
  const approverId = donation.getString("approval_by");
  if (!approverId) {
    e.next();
    return;
  }

  const ownerId = donation.getString("owner");
  if (!ownerId) {
    e.next();
    return;
  }

  let owner = null;
  try {
    owner = $app.findRecordById("users", ownerId);
  } catch (err) {
    $app.logger().error("premium-donation: owner not found", "owner", ownerId, "err", String(err));
    e.next();
    return;
  }

  const recipient = owner.getString("email");
  if (!recipient) {
    e.next();
    return;
  }

  const amount = donation.getFloat("amount") || 0;
  const reference = donation.getString("gcash_reference") || "";
  const reason = donation.getString("rejection_reason") || "";

  let subject = "";
  let html = "";

  if (status === "approved") {
    subject = "Premium access granted on ApX Player";
    html =
      '<div style="font-family:Inter,Arial,sans-serif;max-width:560px;margin:auto">' +
      "<h2 style=\"color:#06b6d4\">You are now a premium member</h2>" +
      "<p>Hi " + (owner.getString("name") || "there") + ",</p>" +
      "<p>Your GCash donation of <strong>₱" + amount + "</strong> has been approved. " +
      "You now have <strong>premium access</strong> to Vivamax and Viva One content on ApX Player.</p>" +
      (reference ? "<p style=\"color:#666\">GCash reference: " + reference + "</p>" : "") +
      "<p>Enjoy the show!</p>" +
      "</div>";
  } else {
    subject = "Your ApX Player premium donation was rejected";
    html =
      '<div style="font-family:Inter,Arial,sans-serif;max-width:560px;margin:auto">' +
      "<h2 style=\"color:#e11d48\">Donation rejected</h2>" +
      "<p>Hi " + (owner.getString("name") || "there") + ",</p>" +
      "<p>We were unable to approve your GCash donation of <strong>₱" + amount + "</strong>.</p>" +
      (reason ? "<p><strong>Reason:</strong> " + reason + "</p>" : "<p>Please double-check your payment and try again, or contact support if you believe this is an error.</p>") +
      (reference ? "<p style=\"color:#666\">GCash reference: " + reference + "</p>" : "") +
      "</div>";
  }

  sendMail(recipient, subject, html);
  e.next();
}, "premium_donations");
