/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    const collection = app.findCollectionByNameOrId("credit_transactions");

    // 0) Allow admins to update a user's credits (top-up approval credits
    //    the owner, who is not the admin).
    users.updateRule = "id = @request.auth.id || @request.auth.role = 'admin'";
    app.save(users);

    // 1) Allow admins to list/view/update (approve) any user's transactions.
    collection.listRule =
      "@request.auth.id != '' && (@request.auth.id = owner || @request.auth.role = 'admin')";
    collection.viewRule =
      "@request.auth.id != '' && (@request.auth.id = owner || @request.auth.role = 'admin')";
    collection.updateRule =
      "@request.auth.id != '' && (@request.auth.id = owner || @request.auth.role = 'admin')";

    // 2) Extend the `status` select with approval-flow values.
    const statusField = collection.fields.getByName("status");
    statusField.values = [
      "pending_approval",
      "completed",
      "rejected",
      "pending",
      "failed",
      "reversed",
    ];

    // 3) Add approval tracking fields (idempotent).
    if (!collection.fields.getByName("approval_by")) {
      collection.fields.add(
        new RelationField({
          name: "approval_by",
          required: false,
          maxSelect: 1,
          collectionId: users.id,
          cascadeDelete: false,
        }),
      );
    }
    if (!collection.fields.getByName("approval_date")) {
      collection.fields.add(
        new DateField({
          name: "approval_date",
          required: false,
        }),
      );
    }
    if (!collection.fields.getByName("rejection_reason")) {
      collection.fields.add(
        new TextField({
          name: "rejection_reason",
          required: false,
          max: 500,
        }),
      );
    }

    app.save(collection);
  },
  (app) => {
    try {
      const collection = app.findCollectionByNameOrId("credit_transactions");

      collection.listRule = "@request.auth.id != '' && @request.auth.id = owner";
      collection.viewRule = "@request.auth.id != '' && @request.auth.id = owner";
      collection.updateRule = "@request.auth.id != '' && @request.auth.id = owner";

      const statusField = collection.fields.getByName("status");
      if (statusField) {
        statusField.values = ["pending", "completed", "failed", "reversed"];
      }

      if (collection.fields.getByName("approval_by")) {
        collection.fields.removeByName("approval_by");
      }
      if (collection.fields.getByName("approval_date")) {
        collection.fields.removeByName("approval_date");
      }
      if (collection.fields.getByName("rejection_reason")) {
        collection.fields.removeByName("rejection_reason");
      }

      app.save(collection);
    } catch (e) {
      if (!e.message.includes("no rows in result set")) throw e;
    }

    // Restore the original users updateRule.
    try {
      const users = app.findCollectionByNameOrId("users");
      users.updateRule = "id = @request.auth.id";
      app.save(users);
    } catch (e) {
      if (!e.message.includes("no rows in result set")) throw e;
    }
  },
);
