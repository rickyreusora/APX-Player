/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    if (!users.fields.getByName("role")) {
      users.fields.add(
        new SelectField({
          name: "role",
          maxSelect: 1,
          values: ["user", "admin"],
        }),
      );
    }
    if (!users.fields.getByName("deletion_requested")) {
      users.fields.add(new BoolField({ name: "deletion_requested" }));
    }
    users.createRule = "";
    users.listRule = "id = @request.auth.id || @request.auth.role = 'admin'";
    users.viewRule = "id = @request.auth.id || @request.auth.role = 'admin'";
    users.updateRule = "id = @request.auth.id";
    users.deleteRule = "id = @request.auth.id";
    app.save(users);

    const adminWrite = "@request.auth.id != '' && @request.auth.role = 'admin'";

    const genres = new Collection({
      type: "base",
      name: "genres",
      listRule: "",
      viewRule: "",
      createRule: adminWrite,
      updateRule: adminWrite,
      deleteRule: adminWrite,
      fields: [
        { name: "name", type: "text", required: true, max: 60 },
        { name: "slug", type: "text", required: true, max: 60 },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
      indexes: ["CREATE UNIQUE INDEX idx_genres_slug ON genres (slug)"],
    });
    app.save(genres);

    const titles = new Collection({
      type: "base",
      name: "titles",
      listRule: "published = true || @request.auth.role = 'admin'",
      viewRule: "published = true || @request.auth.role = 'admin'",
      createRule: adminWrite,
      updateRule: adminWrite,
      deleteRule: adminWrite,
      fields: [
        { name: "title", type: "text", required: true, max: 200 },
        { name: "slug", type: "text", required: true, max: 200 },
        {
          name: "kind",
          type: "select",
          required: true,
          maxSelect: 1,
          values: ["movie", "series"],
        },
        { name: "synopsis", type: "text", max: 4000 },
        { name: "poster", type: "text", max: 500 },
        { name: "backdrop", type: "text", max: 500 },
        { name: "year", type: "number", onlyInt: true },
        { name: "rating", type: "number" },
        { name: "age_rating", type: "text", max: 20 },
        { name: "duration_minutes", type: "number", onlyInt: true },
        { name: "cast_list", type: "text", max: 1000 },
        { name: "creator", type: "text", max: 200 },
        { name: "trailer_url", type: "text", max: 500 },
        { name: "source_url", type: "text", max: 500 },
        { name: "subtitles", type: "json", maxSize: 200000 },
        {
          name: "genres",
          type: "relation",
          maxSelect: 8,
          collectionId: genres.id,
          cascadeDelete: false,
        },
        {
          name: "category",
          type: "select",
          maxSelect: 1,
          values: ["featured", "recently_added", "popular", "originals", "documentary"],
        },
        { name: "popularity", type: "number" },
        { name: "featured", type: "bool" },
        { name: "published", type: "bool" },
        { name: "rights_holder", type: "text", max: 200 },
        { name: "rights_notes", type: "text", max: 1000 },
        { name: "rights_confirmed", type: "bool" },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
      indexes: ["CREATE UNIQUE INDEX idx_titles_slug ON titles (slug)"],
    });
    app.save(titles);

    const seasons = new Collection({
      type: "base",
      name: "seasons",
      listRule: "",
      viewRule: "",
      createRule: adminWrite,
      updateRule: adminWrite,
      deleteRule: adminWrite,
      fields: [
        {
          name: "title",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: titles.id,
          cascadeDelete: true,
        },
        { name: "number", type: "number", onlyInt: true },
        { name: "name", type: "text", max: 120 },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(seasons);

    const episodes = new Collection({
      type: "base",
      name: "episodes",
      listRule: "",
      viewRule: "",
      createRule: adminWrite,
      updateRule: adminWrite,
      deleteRule: adminWrite,
      fields: [
        {
          name: "title",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: titles.id,
          cascadeDelete: true,
        },
        {
          name: "season",
          type: "relation",
          maxSelect: 1,
          collectionId: seasons.id,
          cascadeDelete: true,
        },
        { name: "number", type: "number", onlyInt: true },
        { name: "name", type: "text", required: true, max: 200 },
        { name: "synopsis", type: "text", max: 2000 },
        { name: "still", type: "text", max: 500 },
        { name: "duration_minutes", type: "number", onlyInt: true },
        { name: "source_url", type: "text", max: 500 },
        { name: "subtitles", type: "json", maxSize: 200000 },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(episodes);

    const ownerField = {
      name: "owner",
      type: "relation",
      required: true,
      maxSelect: 1,
      collectionId: users.id,
      cascadeDelete: true,
    };
    const ownerRules = {
      listRule: "@request.auth.id != '' && @request.auth.id = owner",
      viewRule: "@request.auth.id != '' && @request.auth.id = owner",
      createRule: "@request.auth.id != '' && @request.auth.id = @request.body.owner",
      updateRule: "@request.auth.id != '' && @request.auth.id = owner",
      deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
    };

    const favorites = new Collection({
      type: "base",
      name: "favorites",
      ...ownerRules,
      fields: [
        ownerField,
        {
          name: "title",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: titles.id,
          cascadeDelete: true,
        },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
      indexes: [
        "CREATE UNIQUE INDEX idx_fav_owner_title ON favorites (owner, title)",
      ],
    });
    app.save(favorites);

    const playlists = new Collection({
      type: "base",
      name: "playlists",
      ...ownerRules,
      listRule: "@request.auth.id != '' && (@request.auth.id = owner || @request.auth.role = 'admin')",
      fields: [
        ownerField,
        { name: "name", type: "text", required: true, max: 120 },
        { name: "description", type: "text", max: 500 },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(playlists);

    const playlistItems = new Collection({
      type: "base",
      name: "playlist_items",
      ...ownerRules,
      fields: [
        ownerField,
        {
          name: "playlist",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: playlists.id,
          cascadeDelete: true,
        },
        {
          name: "title",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: titles.id,
          cascadeDelete: true,
        },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(playlistItems);

    const progress = new Collection({
      type: "base",
      name: "progress",
      ...ownerRules,
      fields: [
        ownerField,
        {
          name: "title",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: titles.id,
          cascadeDelete: true,
        },
        {
          name: "episode",
          type: "relation",
          maxSelect: 1,
          collectionId: episodes.id,
          cascadeDelete: true,
        },
        { name: "position_seconds", type: "number" },
        { name: "duration_seconds", type: "number" },
        { name: "completed", type: "bool" },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(progress);
  },
  (app) => {
    for (const name of [
      "progress",
      "playlist_items",
      "playlists",
      "favorites",
      "episodes",
      "seasons",
      "titles",
      "genres",
    ]) {
      try {
        app.delete(app.findCollectionByNameOrId(name));
      } catch (e) {
        if (!e.message.includes("no rows in result set")) throw e;
      }
    }
  },
);
