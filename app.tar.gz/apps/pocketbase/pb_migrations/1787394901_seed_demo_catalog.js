/// <reference path="../pb_data/types.d.ts" />

const DEMO_SOURCES = [
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
];

migrate(
  (app) => {
    const genresCol = app.findCollectionByNameOrId("genres");
    const titlesCol = app.findCollectionByNameOrId("titles");
    const seasonsCol = app.findCollectionByNameOrId("seasons");
    const episodesCol = app.findCollectionByNameOrId("episodes");
    const usersCol = app.findCollectionByNameOrId("users");

    const genreSeeds = [
      "Sci-Fi",
      "Thriller",
      "Drama",
      "Documentary",
      "Horror",
      "Crime",
      "Nature",
      "Food",
    ];
    const genreIds = {};
    for (const name of genreSeeds) {
      const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
      const r = new Record(genresCol);
      r.set("name", name);
      r.set("slug", slug);
      app.save(r);
      genreIds[name] = r.id;
    }

    const rows = [
      {
        title: "Neon Meridian",
        kind: "movie",
        year: 2024,
        rating: 8.4,
        duration_minutes: 118,
        age_rating: "PG-13",
        category: "featured",
        featured: true,
        popularity: 96,
        genres: ["Sci-Fi", "Drama"],
        creator: "Directed by Ilse Vandermeer (fictional)",
        cast_list: "Ana Beltrán, Marek Dvorak, Yusuf Adeyemi",
        poster: "https://images.hostinger.com/3aa17a0e-cda1-46bc-8dd7-fa4d7afe9564.png",
        backdrop: "https://images.hostinger.com/3029676a-35b7-4b4b-b24e-ee75d1023385.png",
        synopsis:
          "DEMO TITLE. A solitary surveyor crosses a black desert toward a dying crimson sun, chasing a signal that may be the last human voice left. A fictional sample title created for preview purposes only.",
      },
      {
        title: "The Last Tram",
        kind: "movie",
        year: 2023,
        rating: 7.9,
        duration_minutes: 104,
        age_rating: "R",
        category: "popular",
        popularity: 88,
        genres: ["Thriller", "Crime"],
        creator: "Directed by Rui Marcelino (fictional)",
        cast_list: "Teresa Coelho, Bruno Salgado",
        poster: "https://images.hostinger.com/21d6e349-7602-48f8-9675-601e2da906f6.png",
        backdrop: "https://images.hostinger.com/ff94a226-b7eb-4030-b04b-34742a3e63be.png",
        synopsis:
          "DEMO TITLE. A night-shift tram driver in Lisbon picks up a passenger who should not exist. Fictional sample content for preview only.",
      },
      {
        title: "Orbit Nine",
        kind: "series",
        year: 2025,
        rating: 8.8,
        duration_minutes: 48,
        age_rating: "TV-14",
        category: "featured",
        featured: true,
        popularity: 99,
        genres: ["Sci-Fi", "Thriller"],
        creator: "Created by Hanna Lindqvist (fictional)",
        cast_list: "Devi Raghunathan, Colm Byrne, Ines Farah",
        poster: "https://images.hostinger.com/04e5dc2a-0503-42b5-a23c-538fd9a3ec12.png",
        backdrop: "https://images.hostinger.com/09e93684-b056-455c-a236-98613f335e07.png",
        synopsis:
          "DEMO TITLE. Nine crew members wake on a station that has drifted three years off course, and only one of them remembers why. Fictional sample series for preview only.",
      },
      {
        title: "Wild Corridors",
        kind: "series",
        year: 2024,
        rating: 8.1,
        duration_minutes: 42,
        age_rating: "TV-G",
        category: "documentary",
        popularity: 74,
        genres: ["Documentary", "Nature"],
        creator: "Created by Petra Nagy (fictional)",
        cast_list: "Narrated by Owen Frazier",
        poster: "https://images.hostinger.com/887cc3c0-8fb3-46c5-ba3d-e6fad4a1a235.png",
        backdrop: "https://images.hostinger.com/3029676a-35b7-4b4b-b24e-ee75d1023385.png",
        synopsis:
          "DEMO TITLE. Following the hidden migration routes that stitch a fractured continent back together. Fictional sample series for preview only.",
      },
      {
        title: "Salt & Ember",
        kind: "series",
        year: 2025,
        rating: 7.6,
        duration_minutes: 36,
        age_rating: "TV-PG",
        category: "recently_added",
        popularity: 68,
        genres: ["Documentary", "Food"],
        creator: "Created by Nuria Bosch (fictional)",
        cast_list: "Nuria Bosch, Ilias Petrou",
        poster: "https://images.hostinger.com/cac853e0-8ba5-4a5c-80ce-5f47eb966cc2.png",
        backdrop: "https://images.hostinger.com/ff94a226-b7eb-4030-b04b-34742a3e63be.png",
        synopsis:
          "DEMO TITLE. Six kitchens, one flame, and the cooks who refuse to let it go out. Fictional sample series for preview only.",
      },
      {
        title: "Paper Crown",
        kind: "movie",
        year: 2025,
        rating: 7.2,
        duration_minutes: 127,
        age_rating: "R",
        category: "recently_added",
        popularity: 81,
        genres: ["Crime", "Thriller"],
        creator: "Directed by Dana Okonkwo (fictional)",
        cast_list: "Marcus Hale, Lidia Grosu, Sam Whitfield",
        poster: "https://images.hostinger.com/c7f6d785-014b-4490-a81c-dc4b39145f54.png",
        backdrop: "https://images.hostinger.com/09e93684-b056-455c-a236-98613f335e07.png",
        synopsis:
          "DEMO TITLE. Three ex-auditors plan the quietest robbery in Chicago history: nothing is taken, only corrected. Fictional sample title for preview only.",
      },
      {
        title: "Summer Static",
        kind: "movie",
        year: 2022,
        rating: 7.4,
        duration_minutes: 96,
        age_rating: "PG-13",
        category: "popular",
        popularity: 63,
        genres: ["Drama"],
        creator: "Directed by Eleni Stavrou (fictional)",
        cast_list: "Zoi Karras, Andreas Milonas",
        poster: "https://images.hostinger.com/ce896469-4b71-4d3e-8ade-1fd0b17470b0.png",
        backdrop: "https://images.hostinger.com/ff94a226-b7eb-4030-b04b-34742a3e63be.png",
        synopsis:
          "DEMO TITLE. One Athens rooftop, one broken radio, and the last summer before everything changes. Fictional sample title for preview only.",
      },
      {
        title: "The Quiet Floor",
        kind: "series",
        year: 2024,
        rating: 8.0,
        duration_minutes: 44,
        age_rating: "TV-MA",
        category: "originals",
        popularity: 85,
        genres: ["Horror", "Thriller"],
        creator: "Created by Vera Lindgren (fictional)",
        cast_list: "Jonas Reuter, Amara Diallo",
        poster: "https://images.hostinger.com/bd0cf04b-beab-4e7b-b644-f47af60085d4.png",
        backdrop: "https://images.hostinger.com/09e93684-b056-455c-a236-98613f335e07.png",
        synopsis:
          "DEMO TITLE. The eleventh floor of the Hotel Marlow has no guests, no staff, and no way down. Fictional sample series for preview only.",
      },
    ];

    rows.forEach((row, i) => {
      const rec = new Record(titlesCol);
      rec.set("title", row.title);
      rec.set("slug", row.title.toLowerCase().replace(/[^a-z0-9]+/g, "-"));
      rec.set("kind", row.kind);
      rec.set("synopsis", row.synopsis);
      rec.set("poster", row.poster);
      rec.set("backdrop", row.backdrop);
      rec.set("year", row.year);
      rec.set("rating", row.rating);
      rec.set("age_rating", row.age_rating);
      rec.set("duration_minutes", row.duration_minutes);
      rec.set("cast_list", row.cast_list);
      rec.set("creator", row.creator);
      rec.set("source_url", DEMO_SOURCES[i % DEMO_SOURCES.length]);
      rec.set("trailer_url", DEMO_SOURCES[(i + 1) % DEMO_SOURCES.length]);
      rec.set(
        "genres",
        row.genres.map((g) => genreIds[g]),
      );
      rec.set("category", row.category);
      rec.set("popularity", row.popularity);
      rec.set("featured", !!row.featured);
      rec.set("published", true);
      rec.set("rights_holder", "Demo Rights Holder (placeholder)");
      rec.set(
        "rights_notes",
        "Placeholder demo entry. Replace with your own authorized distribution agreement reference before publishing.",
      );
      rec.set("rights_confirmed", true);
      app.save(rec);

      if (row.kind === "series") {
        for (let s = 1; s <= 1; s++) {
          const season = new Record(seasonsCol);
          season.set("title", rec.id);
          season.set("number", s);
          season.set("name", `Season ${s}`);
          app.save(season);

          for (let e = 1; e <= 4; e++) {
            const ep = new Record(episodesCol);
            ep.set("title", rec.id);
            ep.set("season", season.id);
            ep.set("number", e);
            ep.set("name", `Episode ${e}`);
            ep.set(
              "synopsis",
              `DEMO EPISODE. Placeholder synopsis for ${row.title}, season ${s}, episode ${e}.`,
            );
            ep.set("still", row.backdrop);
            ep.set("duration_minutes", row.duration_minutes);
            ep.set("source_url", DEMO_SOURCES[(i + e) % DEMO_SOURCES.length]);
            app.save(ep);
          }
        }
      }
    });

    try {
      app.findAuthRecordByEmail("users", "admin@movieplayer.demo");
    } catch (_) {
      const admin = new Record(usersCol);
      admin.setEmail("admin@movieplayer.demo");
      admin.setPassword("Rk7-Ember-Marlow-42");
      admin.set("name", "Demo Admin");
      admin.set("role", "admin");
      admin.set("verified", true);
      app.save(admin);
    }
  },
  (app) => {
    for (const col of ["episodes", "seasons", "titles", "genres"]) {
      const records = app.findAllRecords(col);
      for (const r of records) app.delete(r);
    }
    try {
      app.delete(app.findAuthRecordByEmail("users", "admin@movieplayer.demo"));
    } catch (e) {
      if (!e.message.includes("no rows in result set")) throw e;
    }
  },
);
