/// <reference path="../pb_data/types.d.ts" />

// Set the administrator account to rickyjohnreusora@gmail.com with the
// requested password, and ensure it has the admin role. This runs
// server-side (as the superuser) — the secure account-management path — so
// the password is never exposed to the browser, logs, or API responses.
//
// Pre-creating the account with this exact email also lets the Google OAuth2
// flow resolve the existing record by email (Google emails are verified),
// which the google-admin-autolink hook then elevates to admin on sign-in.
//
// Admin login: rickyjohnreusora@gmail.com / AdminCuteko!

migrate(
  (app) => {
    const ADMIN_EMAIL = "rickyjohnreusora@gmail.com";
    const users = app.findCollectionByNameOrId("users");

    // 1. If a user already holds the target email, promote it to admin and
    //    (re)set the password. This covers a Google sign-up that created a
    //    regular user with this address before the admin was configured.
    let admin = null;
    try {
      admin = app.findAuthRecordByEmail("users", ADMIN_EMAIL);
    } catch (e) {
      if (!String(e.message || e).includes("no rows in result set")) throw e;
    }

    // 2. Otherwise, adopt the existing admin account (e.g. the previous
    //    adminmaruya@maruya.ph seed) by repointing its email + password.
    if (!admin) {
      try {
        admin = app.findFirstRecordByFilter("users", "role = 'admin'");
      } catch (e) {
        if (!String(e.message || e).includes("no rows in result set")) throw e;
      }
    }

    // 3. Otherwise, create a fresh admin account.
    if (!admin) {
      admin = new Record(users);
    }

    admin.setEmail(ADMIN_EMAIL);
    admin.setPassword("AdminCuteko!");
    admin.set("name", "Ricky John Reusora");
    admin.set("role", "admin");
    admin.set("verified", true);

    try {
      app.save(admin);
    } catch (e) {
      // If the email is already taken by another record (unique constraint),
      // the lookup above should have found it; treat a duplicate as success.
      const msg = String(e.message || e);
      if (!/unique|already exists|duplicate/i.test(msg)) throw e;
      console.log("Admin account already present, skipping save:", msg);
    }
  },
  (app) => {
    // No-op downgrade: reverting would lock the user out of admin access.
  },
);
