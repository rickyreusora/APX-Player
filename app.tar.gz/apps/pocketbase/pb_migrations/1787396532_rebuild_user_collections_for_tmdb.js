/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    const ownerField = {
      name: "owner",
      type: "relation",
      required: true,
      maxSelect: 1,
      collectionId: users.id,
      cascadeDelete: true,
    };
    const ownerRules = {
      listRule: "@request.auth.id != '' && @request.auth.id = owner",
      viewRule: "@request.auth.id != '' && @request.auth.id = owner",
      createRule: "@request.auth.id != '' && @request.auth.id = @request.body.owner",
      updateRule: "@request.auth.id != '' && @request.auth.id = owner",
      deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
    };

    // Drop the old relation-based user collections so we can rebuild them
    // around TMDB ids instead of PocketBase title ids.
    for (const name of ["progress", "playlist_items", "favorites"]) {
      try {
        app.delete(app.findCollectionByNameOrId(name));
      } catch (e) {
        if (!e.message.includes("no rows in result set")) throw e;
      }
    }

    const favorites = new Collection({
      type: "base",
      name: "favorites",
      ...ownerRules,
      fields: [
        ownerField,
        { name: "tmdb_id", type: "number", required: true, onlyInt: true },
        {
          name: "kind",
          type: "select",
          required: true,
          maxSelect: 1,
          values: ["movie", "series"],
        },
        { name: "title_text", type: "text", max: 200 },
        { name: "poster", type: "text", max: 500 },
        { name: "year", type: "number", onlyInt: true },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
      indexes: [
        "CREATE UNIQUE INDEX idx_fav_owner_tmdb ON favorites (owner, tmdb_id, kind)",
      ],
    });
    app.save(favorites);

    const playlists = app.findCollectionByNameOrId("playlists");

    const playlistItems = new Collection({
      type: "base",
      name: "playlist_items",
      ...ownerRules,
      fields: [
        ownerField,
        {
          name: "playlist",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: playlists.id,
          cascadeDelete: true,
        },
        { name: "tmdb_id", type: "number", required: true, onlyInt: true },
        {
          name: "kind",
          type: "select",
          required: true,
          maxSelect: 1,
          values: ["movie", "series"],
        },
        { name: "title_text", type: "text", max: 200 },
        { name: "poster", type: "text", max: 500 },
        { name: "year", type: "number", onlyInt: true },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(playlistItems);

    const progress = new Collection({
      type: "base",
      name: "progress",
      ...ownerRules,
      fields: [
        ownerField,
        { name: "tmdb_id", type: "number", required: true, onlyInt: true },
        {
          name: "kind",
          type: "select",
          required: true,
          maxSelect: 1,
          values: ["movie", "series"],
        },
        { name: "season", type: "number", onlyInt: true },
        { name: "episode", type: "number", onlyInt: true },
        { name: "position_seconds", type: "number" },
        { name: "duration_seconds", type: "number" },
        { name: "completed", type: "bool" },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(progress);
  },
  (app) => {
    for (const name of ["progress", "playlist_items", "favorites"]) {
      try {
        app.delete(app.findCollectionByNameOrId(name));
      } catch (e) {
        if (!e.message.includes("no rows in result set")) throw e;
      }
    }
  },
);
