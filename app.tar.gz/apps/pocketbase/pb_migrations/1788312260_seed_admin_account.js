/// <reference path="../pb_data/types.d.ts" />

// Ensures the demo admin account exists with the documented credentials.
// A previous credentials migration (1787449684) is already marked applied
// but the account never persisted (users table is empty), and that file is
// now immutable. This forward migration (re)creates the admin account
// idempotently so login works in both preview and published databases.
//
// Demo login: adminmaruya@maruya.ph / cuteko123

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    // Look up by the target email first; fall back to the legacy email so
    // re-runs and databases that still hold the old account stay idempotent.
    let admin = null;
    try {
      admin = app.findAuthRecordByEmail("users", "adminmaruya@maruya.ph");
    } catch (e) {
      if (!String(e.message || e).includes("no rows in result set")) throw e;
    }
    if (!admin) {
      try {
        admin = app.findAuthRecordByEmail("users", "admin@movieplayer.demo");
      } catch (e) {
        if (!String(e.message || e).includes("no rows in result set")) throw e;
      }
    }

    if (!admin) {
      admin = new Record(users);
    }

    admin.setEmail("adminmaruya@maruya.ph");
    admin.setPassword("cuteko123");
    admin.set("name", "Admin Maruya");
    admin.set("role", "admin");
    admin.set("verified", true);

    try {
      app.save(admin);
    } catch (e) {
      // If the account already exists with the same email (unique
      // constraint), treat as success — credentials are already in place.
      const msg = String(e.message || e);
      if (!/unique|already exists|duplicate/i.test(msg)) throw e;
      console.log("Admin account already present, skipping save:", msg);
    }
  },
  (app) => {
    // No-op downgrade: removing the admin account would lock the user out.
  },
);
