/// <reference path="../pb_data/types.d.ts" />

// Updates the demo admin account credentials from
//   admin@movieplayer.demo / Rk7-Ember-Marlow-42
// to
//   adminmaruya / cuteko123  (username + email adminmaruya@maruya.ph)
// Also enables username-based password login when the built-in username
// system field is present on the users auth collection.

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    // Enable username as an accepted identity for password auth, but only
    // when the built-in username field actually exists on the collection.
    const usernameField = users.fields.getByName("username");
    if (usernameField) {
      try {
        users.passwordAuth.identityFields = ["username", "email"];
        app.save(users);
      } catch (e) {
        console.log("Could not enable username auth:", e.message);
      }
    }

    // Update the existing demo admin account, or create it if missing.
    // Look up by either the old or new email so re-runs / production
    // databases that already hold the target account stay idempotent.
    let admin;
    try {
      admin = app.findAuthRecordByEmail("users", "admin@movieplayer.demo");
    } catch (e) {
      if (!String(e.message || e).includes("no rows in result set")) throw e;
    }
    if (!admin) {
      try {
        admin = app.findAuthRecordByEmail("users", "adminmaruya@maruya.ph");
      } catch (e) {
        if (!String(e.message || e).includes("no rows in result set")) throw e;
      }
    }

    if (!admin) {
      admin = new Record(users);
    }

    if (usernameField) {
      try {
        admin.set("username", "adminmaruya");
      } catch (e) {
        console.log("Could not set admin username:", e.message);
      }
    }
    admin.setEmail("adminmaruya@maruya.ph");
    admin.setPassword("cuteko123");
    admin.set("name", "Admin Maruya");
    admin.set("role", "admin");
    admin.set("verified", true);
    try {
      app.save(admin);
    } catch (e) {
      // If the target account already exists with the same email (unique
      // constraint), treat as success — credentials are already in place.
      const msg = String(e.message || e);
      if (!/unique|already exists|duplicate/i.test(msg)) throw e;
      console.log("Admin account already present, skipping save:", msg);
    }
  },
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    const usernameField = users.fields.getByName("username");
    if (usernameField) {
      try {
        users.passwordAuth.identityFields = ["email"];
        app.save(users);
      } catch (e) {
        console.log("Could not revert username auth:", e.message);
      }
    }

    let admin;
    try {
      // The users collection has no built-in `username` field, so filter by
      // email only to avoid "unknown field username" parse errors on revert.
      admin = app.findFirstRecordByFilter(
        "users",
        "email = 'adminmaruya@maruya.ph'",
      );
    } catch (e) {
      if (!e.message.includes("no rows in result set")) throw e;
    }

    if (admin) {
      if (usernameField) {
        admin.set("username", "");
      }
      admin.setEmail("admin@movieplayer.demo");
      admin.setPassword("Rk7-Ember-Marlow-42");
      admin.set("name", "Demo Admin");
      app.save(admin);
    }
  },
);
