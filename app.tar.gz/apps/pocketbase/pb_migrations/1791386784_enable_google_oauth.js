/// <reference path="../pb_data/types.d.ts" />

// Enable Google OAuth2 sign-in on the `users` auth collection.
//
// Credentials are read from the GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET env
// vars. PocketBase rejects a provider with blank clientId/clientSecret, so
// when the env vars are not set this migration is an intentional no-op: the
// Google provider is not added, the frontend hides the "Continue with
// Google" button (via listAuthMethods), and the site boots normally.
//
// To activate Google sign-in, set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET
// (and register the redirect URI in Google Cloud Console), then run a
// follow-up migration that adds the provider — ask for it once you have the
// credentials.
migrate(
  (app) => {
    const clientId = $os.getenv("GOOGLE_CLIENT_ID") || "";
    const clientSecret = $os.getenv("GOOGLE_CLIENT_SECRET") || "";

    if (!clientId || !clientSecret) {
      // Intentional no-op until Google OAuth credentials are provided.
      return;
    }

    const collection = app.findCollectionByNameOrId("users");

    const googleProvider = {
      name: "google",
      clientId: clientId,
      clientSecret: clientSecret,
      authURL: "",
      tokenURL: "",
      userInfoURL: "",
      displayName: "",
      pkce: null,
    };

    collection.oauth2.providers = [
      ...collection.oauth2.providers.filter((p) => p.name !== "google"),
      googleProvider,
    ];
    collection.oauth2.enabled = true;
    collection.oauth2.mappedFields = {
      id: "",
      name: "name",
      username: "",
      avatarURL: "avatar",
    };

    app.save(collection);
  },
  (app) => {
    const collection = app.findCollectionByNameOrId("users");
    collection.oauth2.providers = collection.oauth2.providers.filter(
      (p) => p.name !== "google",
    );
    if (collection.oauth2.providers.length === 0) {
      collection.oauth2.enabled = false;
    }
    app.save(collection);
  },
);
