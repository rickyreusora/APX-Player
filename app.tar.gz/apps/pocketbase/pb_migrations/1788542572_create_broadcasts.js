/// <reference path="../pb_data/types.d.ts" />

// Broadcast messages — admin-managed, public-read for active ones.
// Admins create/update/delete; any visitor (signed-in or not) can read
// active broadcasts so the pop-up dialog can render site-wide.
migrate(
  (app) => {
    let collection;
    try {
      collection = app.findCollectionByNameOrId("broadcasts");
    } catch (_) {
      collection = new Collection({
        type: "base",
        name: "broadcasts",
        // Public can read active broadcasts; admins can read all (for management).
        listRule:
          "active = true || (@request.auth.id != '' && @request.auth.role = 'admin')",
        viewRule:
          "active = true || (@request.auth.id != '' && @request.auth.role = 'admin')",
        // Only admins may create/update/delete broadcasts.
        createRule:
          "@request.auth.id != '' && @request.auth.role = 'admin'",
        updateRule:
          "@request.auth.id != '' && @request.auth.role = 'admin'",
        deleteRule:
          "@request.auth.id != '' && @request.auth.role = 'admin'",
        fields: [
          { name: "title", type: "text", max: 120 },
          { name: "message", type: "text", required: true, max: 1000 },
          { name: "active", type: "bool" },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: [
          "CREATE INDEX idx_broadcasts_active ON broadcasts (active)",
        ],
      });
      app.save(collection);
    }
  },
  (app) => {
    try {
      const collection = app.findCollectionByNameOrId("broadcasts");
      app.delete(collection);
    } catch (e) {
      if (e.message && e.message.includes("no rows in result set")) {
        return;
      }
      throw e;
    }
  },
);
