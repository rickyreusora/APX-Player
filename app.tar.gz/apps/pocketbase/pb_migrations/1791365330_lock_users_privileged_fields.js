/// <reference path="../pb_data/types.d.ts" />

// Lock privileged fields on the users auth collection so a regular user
// cannot self-grant admin role, credits, or premium access. Only admins
// (and server-side code) can change these. This keeps admin-only controls
// restricted to administrators and protects the top-up / donation flows
// from being bypassed by editing one's own profile.

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    // Update rule: a user may edit their own profile (name, avatar, etc.)
    // but cannot change role, credits, or is_premium. Admins can edit any
    // user (used by the top-up / donation approval flows).
    users.updateRule =
      "(id = @request.auth.id && @request.body.role:changed = false && @request.body.credits:changed = false && @request.body.is_premium:changed = false) || @request.auth.role = 'admin'";

    // Create rule: public sign-up may set role to 'user' (or omit it) but
    // cannot set credits or is_premium at all.
    users.createRule =
      "(@request.body.role:isset = false || @request.body.role = 'user') && @request.body.is_premium:isset = false && @request.body.credits:isset = false";

    app.save(users);
  },
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    users.updateRule = "id = @request.auth.id || @request.auth.role = 'admin'";
    users.createRule = "";
    app.save(users);
  },
);
