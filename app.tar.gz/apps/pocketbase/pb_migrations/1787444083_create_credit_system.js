/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // 1) Add a `credits` balance field to the existing users auth collection.
    const users = app.findCollectionByNameOrId("users");
    if (!users.fields.getByName("credits")) {
      users.fields.add(
        new NumberField({
          name: "credits",
          required: false,
          min: 0,
        }),
      );
      app.save(users);
    }

    // 2) Create the credit_transactions collection (owner-scoped).
    let collection;
    try {
      collection = app.findCollectionByNameOrId("credit_transactions");
    } catch (_) {
      collection = new Collection({
        type: "base",
        name: "credit_transactions",
        listRule: "@request.auth.id != '' && @request.auth.id = owner",
        viewRule: "@request.auth.id != '' && @request.auth.id = owner",
        createRule: "@request.auth.id != '' && @request.auth.id = @request.body.owner",
        updateRule: "@request.auth.id != '' && @request.auth.id = owner",
        deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
        fields: [
          {
            name: "owner",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          {
            name: "amount",
            type: "number",
            required: true,
          },
          {
            name: "type",
            type: "select",
            required: true,
            maxSelect: 1,
            values: ["topup", "usage", "refund", "adjustment"],
          },
          {
            name: "status",
            type: "select",
            required: true,
            maxSelect: 1,
            values: ["pending", "completed", "failed", "reversed"],
          },
          {
            name: "method",
            type: "select",
            maxSelect: 1,
            values: ["gcash", "system", "admin"],
          },
          {
            name: "reference",
            type: "text",
            max: 200,
          },
          {
            name: "notes",
            type: "text",
            max: 500,
          },
          {
            name: "balance_after",
            type: "number",
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: [
          "CREATE INDEX idx_credit_tx_owner ON credit_transactions (owner)",
        ],
      });
      app.save(collection);
    }
  },
  (app) => {
    try {
      const users = app.findCollectionByNameOrId("users");
      if (users.fields.getByName("credits")) {
        users.fields.removeByName("credits");
        app.save(users);
      }
    } catch (e) {
      if (!e.message.includes("no rows in result set")) throw e;
    }
    try {
      const collection = app.findCollectionByNameOrId("credit_transactions");
      app.delete(collection);
    } catch (e) {
      if (!e.message.includes("no rows in result set")) throw e;
    }
  },
);
