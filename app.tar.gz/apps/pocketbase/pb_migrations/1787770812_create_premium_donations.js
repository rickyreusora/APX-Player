/// <reference path="../pb_data/types.d.ts" />

// Premium access workflow for Vivamax / Viva One content.
// 1) Adds an `is_premium` bool flag to the users auth collection.
// 2) Creates the `premium_donations` collection (owner-scoped, admin-managed)
//    storing GCash donation submissions with a proof-of-payment image.

migrate(
  (app) => {
    // 1) Add `is_premium` flag to users.
    const users = app.findCollectionByNameOrId("users");
    if (!users.fields.getByName("is_premium")) {
      users.fields.add(
        new BoolField({
          name: "is_premium",
          required: false,
        }),
      );
      app.save(users);
    }

    // 2) Create premium_donations collection.
    let collection;
    try {
      collection = app.findCollectionByNameOrId("premium_donations");
    } catch (_) {
      collection = new Collection({
        type: "base",
        name: "premium_donations",
        // Owner can read their own; admins can read all. Only the owner can
        // create their own donation. Updates/deletes are admin-managed.
        listRule:
          "@request.auth.id != '' && (@request.auth.id = owner || @request.auth.role = 'admin')",
        viewRule:
          "@request.auth.id != '' && (@request.auth.id = owner || @request.auth.role = 'admin')",
        createRule: "@request.auth.id != '' && @request.auth.id = @request.body.owner",
        updateRule:
          "@request.auth.id != '' && @request.auth.role = 'admin'",
        deleteRule:
          "@request.auth.id != '' && @request.auth.role = 'admin'",
        fields: [
          {
            name: "owner",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          {
            name: "amount",
            type: "number",
            required: true,
            min: 1,
          },
          {
            name: "sender_name",
            type: "text",
            required: true,
            max: 200,
          },
          {
            name: "gcash_reference",
            type: "text",
            required: true,
            max: 200,
          },
          {
            name: "proof_image",
            type: "file",
            maxSelect: 1,
            maxSize: 10485760, // 10 MB
            mimeTypes: [
              "image/jpeg",
              "image/png",
              "image/webp",
              "image/gif",
            ],
          },
          {
            name: "status",
            type: "select",
            required: true,
            maxSelect: 1,
            values: ["pending", "approved", "rejected"],
          },
          {
            name: "approval_by",
            type: "relation",
            maxSelect: 1,
            collectionId: users.id,
          },
          {
            name: "approval_date",
            type: "date",
          },
          {
            name: "rejection_reason",
            type: "text",
            max: 500,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: [
          "CREATE INDEX idx_premium_donations_owner ON premium_donations (owner)",
          "CREATE INDEX idx_premium_donations_status ON premium_donations (status)",
        ],
      });
      app.save(collection);
    }
  },
  (app) => {
    try {
      const users = app.findCollectionByNameOrId("users");
      if (users.fields.getByName("is_premium")) {
        users.fields.removeByName("is_premium");
        app.save(users);
      }
    } catch (e) {
      if (!e.message.includes("no rows in result set")) throw e;
    }
    try {
      const collection = app.findCollectionByNameOrId("premium_donations");
      app.delete(collection);
    } catch (e) {
      if (!e.message.includes("no rows in result set")) throw e;
    }
  },
);
