/// <reference path="../pb_data/types.d.ts" />

// Download limit tracking for the /downloader page.
//
// - Adds `free_downloads_used` to users (how many of the 3 free downloads
//   the user has consumed) and locks it against self-edits so a member
//   cannot reset their own counter.
// - Creates `download_tokens`: single-use, short-lived tokens issued by the
//   Express claim endpoint after a free download or a credit is spent. The
//   file-streaming endpoints consume one token per delivered file, which
//   prevents bypassing the limit and blocks duplicate/replayed requests.

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    // 1) free_downloads_used counter (idempotent).
    if (!users.fields.getByName("free_downloads_used")) {
      users.fields.add(
        new NumberField({
          name: "free_downloads_used",
          required: false,
          min: 0,
        }),
      );
    }

    // 2) Lock free_downloads_used against self-edits (admins still can).
    //    Mirrors the existing locks on role / credits / is_premium.
    users.updateRule =
      "(id = @request.auth.id && @request.body.role:changed = false && @request.body.credits:changed = false && @request.body.is_premium:changed = false && @request.body.free_downloads_used:changed = false) || @request.auth.role = 'admin'";
    app.save(users);

    // 3) download_tokens collection (server-managed; no public REST access).
    let tokens;
    try {
      tokens = app.findCollectionByNameOrId("download_tokens");
    } catch (_) {
      tokens = new Collection({
        type: "base",
        name: "download_tokens",
        // Tokens are only ever read/written by the Express superuser client.
        listRule: null,
        viewRule: null,
        createRule: "@request.auth.id != '' && @request.auth.id = owner",
        updateRule: null,
        deleteRule: null,
        fields: [
          {
            name: "owner",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "used", type: "bool" },
          {
            name: "kind",
            type: "select",
            maxSelect: 1,
            values: ["free", "credit"],
          },
          { name: "source", type: "text", max: 60 },
          { name: "expires", type: "date" },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: [
          "CREATE INDEX idx_download_tokens_owner ON download_tokens (owner)",
        ],
      });
      app.save(tokens);
    }
  },
  (app) => {
    try {
      const users = app.findCollectionByNameOrId("users");
      if (users.fields.getByName("free_downloads_used")) {
        users.fields.removeByName("free_downloads_used");
      }
      // Restore the prior updateRule (without the free_downloads_used lock).
      users.updateRule =
        "(id = @request.auth.id && @request.body.role:changed = false && @request.body.credits:changed = false && @request.body.is_premium:changed = false) || @request.auth.role = 'admin'";
      app.save(users);
    } catch (e) {
      if (!e.message.includes("no rows")) throw e;
    }
    try {
      const tokens = app.findCollectionByNameOrId("download_tokens");
      app.delete(tokens);
    } catch (e) {
      if (!e.message.includes("no rows")) throw e;
    }
  },
);
