// apps/pocketbase/pb_migrations/1787561720_create_karaoke_songs.js
/// <reference path="../pb_data/types.d.ts" />

// karaoke_songs — persistent karaoke song database backing the ApX Karaoke
// YouTube + MaruyaTVPH search. The Express /youtube route upserts results here
// (via the superuser client, which bypasses rules). Public read so any visitor
// can browse; admin-only writes for curation/moderation.

migrate(
  (app) => {
    let collection;
    try {
      collection = app.findCollectionByNameOrId("karaoke_songs");
    } catch (_) {
      const users = app.findCollectionByNameOrId("users");
      collection = new Collection({
        type: "base",
        name: "karaoke_songs",
        // Public read (shared song database); admin-only writes.
        listRule: "",
        viewRule: "",
        createRule: "@request.auth.id != '' && @request.auth.role = 'admin'",
        updateRule: "@request.auth.id != '' && @request.auth.role = 'admin'",
        deleteRule: "@request.auth.id != '' && @request.auth.role = 'admin'",
        fields: [
          { name: "video_id", type: "text", required: true, max: 50 },
          { name: "title", type: "text", required: true, max: 300 },
          { name: "artist", type: "text", max: 300 },
          { name: "duration_seconds", type: "number", onlyInt: true },
          { name: "thumbnail", type: "url", max: 500 },
          {
            name: "source",
            type: "select",
            required: true,
            maxSelect: 1,
            values: ["youtube", "maruyatvph"],
          },
          { name: "language", type: "text", max: 60 },
          { name: "genre", type: "text", max: 60 },
          { name: "view_count", type: "number", onlyInt: true },
          { name: "upload_date", type: "date" },
          {
            name: "difficulty",
            type: "select",
            maxSelect: 1,
            values: ["Easy", "Normal", "Hard", "Expert"],
          },
          { name: "play_count", type: "number", onlyInt: true },
          {
            name: "owner",
            type: "relation",
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: false,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: [
          "CREATE UNIQUE INDEX idx_karaoke_songs_video_id ON karaoke_songs (video_id)",
          "CREATE INDEX idx_karaoke_songs_source ON karaoke_songs (source)",
          "CREATE INDEX idx_karaoke_songs_genre ON karaoke_songs (genre)",
        ],
      });
      app.save(collection);
    }
  },
  (app) => {
    try {
      const collection = app.findCollectionByNameOrId("karaoke_songs");
      app.delete(collection);
    } catch (e) {
      if (e.message.includes("no rows in result set")) return;
      throw e;
    }
  },
);
