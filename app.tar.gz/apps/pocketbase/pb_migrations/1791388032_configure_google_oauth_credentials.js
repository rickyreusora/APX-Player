/// <reference path="../pb_data/types.d.ts" />

// Configure the Google OAuth2 provider on the `users` auth collection with
// the user-supplied credentials. The earlier 1791386784_enable_google_oauth.js
// migration reads GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET from the environment
// and is an intentional no-op when those vars are absent — it already applied
// as a no-op, so it will not re-run. This migration performs the actual
// provider upsert server-side so the credentials are never shipped to the
// browser or written to logs.
//
// Authorized redirect URI registered in Google Cloud Console:
//   https://moviepinas.com/hcgi/platform/api/oauth2-redirect
migrate(
  (app) => {
    const collection = app.findCollectionByNameOrId("users");

    const googleProvider = {
      name: "google",
      clientId:
        "781707648661-ave6nmvn30dkfc3p22afaqfn6dj0kth9.apps.googleusercontent.com",
      clientSecret: "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",
      authURL: "",
      tokenURL: "",
      userInfoURL: "",
      displayName: "",
      pkce: null,
    };

    collection.oauth2.providers = [
      ...collection.oauth2.providers.filter((p) => p.name !== "google"),
      googleProvider,
    ];
    collection.oauth2.enabled = true;
    collection.oauth2.mappedFields = {
      id: "",
      name: "name",
      username: "",
      avatarURL: "avatar",
    };

    app.save(collection);
  },
  (app) => {
    const collection = app.findCollectionByNameOrId("users");
    collection.oauth2.providers = collection.oauth2.providers.filter(
      (p) => p.name !== "google",
    );
    if (collection.oauth2.providers.length === 0) {
      collection.oauth2.enabled = false;
    }
    app.save(collection);
  },
);
