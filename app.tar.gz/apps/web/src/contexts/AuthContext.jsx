import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import pb from '@/lib/pocketbaseClient';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(pb.authStore.record);

    useEffect(() => pb.authStore.onChange((_token, record) => setUser(record)), []);

    // Refresh the auth record on mount so premium status and credit balance
    // reflect the latest server state (e.g. after an admin approves a
    // donation or top-up). A 401 means the token is no longer valid.
    useEffect(() => {
        if (!pb.authStore.isValid) return;
        pb.collection('users')
            .authRefresh()
            .catch((err) => {
                if (err?.status === 401) {
                    pb.authStore.clear();
                }
            });
    }, []);

    const value = useMemo(
        () => ({
            user,
            isAuthed: pb.authStore.isValid,
            isAdmin: !!user && user.role === 'admin',
            isPremium: !!user && user.is_premium === true,
            requestPasswordReset: (email) => pb.collection('users').requestPasswordReset(email),
            refreshUser: async () => {
                if (!pb.authStore.record) return null;
                return pb.collection('users').authRefresh();
            },
            login: (email, password) => pb.collection('users').authWithPassword(email, password),
            // Google OAuth — creates the account on first sign-in (role: 'user'
            // satisfies the locked createRule) and authenticates returning users.
            // The SDK opens the Google consent popup and updates the authStore
            // on success, which the onChange listener below mirrors into `user`.
            loginWithGoogle: () =>
                pb.collection('users').authWithOAuth2({
                    provider: 'google',
                    createData: { role: 'user' },
                }),
            signup: async (email, password, extraFields = {}) => {
                await pb.collection('users').create({ email, password, passwordConfirm: password, ...extraFields });

                return pb.collection('users').authWithPassword(email, password);
            },
            logout: () => pb.authStore.clear(),
        }),
        [user],
    );

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);

export default AuthContext;
