import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Download, Share, PlusSquare, Home, Smartphone, Monitor, Apple, CheckCircle2, X } from 'lucide-react';

/**
 * Cross-platform install modal for ApX Player.
 *
 * - iOS / iPadOS: step-by-step "Add to Home Screen" guide (Safari only).
 * - Android: native APK download + browser PWA install prompt.
 * - Desktop: PWA install prompt (Chrome/Edge) or per-browser instructions.
 *
 * Open it from anywhere by dispatching:
 *   window.dispatchEvent(new CustomEvent('apx-open-install'))
 */
const InstallModal = () => {
    const [open, setOpen] = useState(false);
    const [deferred, setDeferred] = useState(null);
    const [installed, setInstalled] = useState(false);

    const platform = (() => {
        if (typeof navigator === 'undefined') return 'desktop';
        const ua = navigator.userAgent || '';
        if (/iphone|ipad|ipod/i.test(ua)) return 'ios';
        if (/android/i.test(ua)) return 'android';
        return 'desktop';
    })();

    const isStandalone = () =>
        typeof window !== 'undefined' &&
        (window.matchMedia('(display-mode: standalone)').matches ||
            window.matchMedia('(display-mode: fullscreen)').matches ||
            window.navigator.standalone === true);

    useEffect(() => {
        const onOpen = () => setOpen(true);
        window.addEventListener('apx-open-install', onOpen);

        const onBeforeInstall = (e) => {
            e.preventDefault();
            setDeferred(e);
        };
        window.addEventListener('beforeinstallprompt', onBeforeInstall);

        const onInstalled = () => {
            setInstalled(true);
            setDeferred(null);
        };
        window.addEventListener('appinstalled', onInstalled);

        return () => {
            window.removeEventListener('apx-open-install', onOpen);
            window.removeEventListener('beforeinstallprompt', onBeforeInstall);
            window.removeEventListener('appinstalled', onInstalled);
        };
    }, []);

    const runNativeInstall = async () => {
        if (!deferred) return;
        try {
            deferred.prompt();
            const { outcome } = await deferred.userChoice.catch(() => ({}));
            if (outcome === 'accepted' || outcome === 'dismissed') {
                setDeferred(null);
            }
        } catch {
            setDeferred(null);
        }
    };

    const steps = [
        { icon: Share, title: 'Tap the Share button', detail: 'In Safari, tap the Share icon at the bottom of the screen.' },
        { icon: PlusSquare, title: 'Choose “Add to Home Screen”', detail: 'Scroll the Share sheet and select Add to Home Screen.' },
        { icon: Home, title: 'Tap Add', detail: 'Confirm the name “ApX Player” and tap Add in the top-right.' },
        { icon: CheckCircle2, title: 'Launch from your Home Screen', detail: 'ApX Player opens full-screen, just like a native app.' },
    ];

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogContent className="max-w-md overflow-hidden rounded-3xl border-white/10 bg-card p-0 sm:max-w-lg">
                <DialogHeader className="space-y-0 sr-only">
                    <DialogTitle>Install ApX Player</DialogTitle>
                    <DialogDescription>
                        Install ApX Player on your device for quick access to movies, series, live TV and karaoke.
                    </DialogDescription>
                </DialogHeader>

                {/* Hero banner */}
                <div className="relative grad-ax px-6 pb-7 pt-8 text-primary-foreground">
                    <button
                        type="button"
                        onClick={() => setOpen(false)}
                        className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full bg-black/20 text-primary-foreground transition-colors hover:bg-black/40"
                        aria-label="Close"
                    >
                        <X className="h-5 w-5" aria-hidden="true" />
                    </button>
                    <div className="flex items-center gap-4">
                        <span className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-black/25 p-1.5 backdrop-blur">
                            <img src="/icon-512.png" alt="" className="h-full w-full rounded-xl object-cover" />
                        </span>
                        <div className="min-w-0">
                            <p className="display text-2xl leading-none">APX PLAYER</p>
                            <p className="mt-1 text-sm text-primary-foreground/85">
                                Install the app on your device
                            </p>
                        </div>
                    </div>
                    <div className="mt-5 flex flex-wrap gap-2">
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-black/25 px-3 py-1 text-xs font-semibold">
                            <Smartphone className="h-3.5 w-3.5" aria-hidden="true" /> Works offline
                        </span>
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-black/25 px-3 py-1 text-xs font-semibold">
                            <Home className="h-3.5 w-3.5" aria-hidden="true" /> Home-screen icon
                        </span>
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-black/25 px-3 py-1 text-xs font-semibold">
                            <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" /> Full-screen
                        </span>
                    </div>
                </div>

                <div className="px-6 py-6">
                    {installed || isStandalone() ? (
                        <div className="flex flex-col items-center gap-3 py-6 text-center">
                            <CheckCircle2 className="h-12 w-12 text-primary" aria-hidden="true" />
                            <p className="text-lg font-semibold">ApX Player is installed</p>
                            <p className="max-w-xs text-sm text-muted-foreground">
                                Launch it from your Home Screen or app drawer. Movies, shows, live TV and karaoke — ready when you are.
                            </p>
                        </div>
                    ) : platform === 'ios' ? (
                        <div>
                            <div className="mb-4 flex items-center gap-2 text-sm font-semibold text-foreground">
                                <Apple className="h-4 w-4" aria-hidden="true" />
                                iPhone &amp; iPad · Add to Home Screen
                            </div>
                            <p className="mb-5 text-sm leading-relaxed text-muted-foreground">
                                iOS installs ApX Player right from Safari — no App Store needed. Follow these steps:
                            </p>
                            <ol className="space-y-3">
                                {steps.map((s, i) => (
                                    <li key={s.title} className="flex gap-3">
                                        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-primary/40 bg-primary/10 text-xs font-bold text-primary">
                                            {i + 1}
                                        </span>
                                        <div className="min-w-0 pt-0.5">
                                            <p className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
                                                <s.icon className="h-4 w-4 text-primary" aria-hidden="true" />
                                                {s.title}
                                            </p>
                                            <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{s.detail}</p>
                                        </div>
                                    </li>
                                ))}
                            </ol>
                            <p className="mt-5 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-xs leading-relaxed text-muted-foreground">
                                Tip: use Safari for the best result. The installed app opens in its own full-screen window.
                            </p>
                        </div>
                    ) : platform === 'android' ? (
                        <div className="space-y-5">
                            <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                                <Smartphone className="h-4 w-4" aria-hidden="true" /> Android
                            </div>
                            <a
                                href="https://maruyatvph.com/apx/ApX.apk"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="focus-glow flex items-center justify-between gap-3 rounded-2xl grad-ax px-5 py-4 text-primary-foreground transition-transform hover:scale-[1.02] active:scale-[0.98]"
                            >
                                <span className="flex items-center gap-3">
                                    <Download className="h-5 w-5" aria-hidden="true" />
                                    <span>
                                        <span className="block text-sm font-bold">Download APK</span>
                                        <span className="block text-xs text-primary-foreground/85">Native Android app</span>
                                    </span>
                                </span>
                                <span aria-hidden="true">→</span>
                            </a>
                            {deferred ? (
                                <button
                                    type="button"
                                    onClick={runNativeInstall}
                                    className="focus-glow flex w-full items-center justify-center gap-2 rounded-2xl border border-primary/40 bg-primary/10 px-5 py-4 text-sm font-semibold text-primary transition-colors hover:bg-primary/20"
                                >
                                    <PlusSquare className="h-5 w-5" aria-hidden="true" /> Install from browser
                                </button>
                            ) : (
                                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-xs leading-relaxed text-muted-foreground">
                                    Prefer a browser install? Open this page in Chrome, tap the menu (⋮), then <span className="font-semibold text-foreground">Add to Home screen</span> or <span className="font-semibold text-foreground">Install app</span>.
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="space-y-5">
                            <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                                <Monitor className="h-4 w-4" aria-hidden="true" /> Desktop
                            </div>
                            {deferred ? (
                                <button
                                    type="button"
                                    onClick={runNativeInstall}
                                    className="focus-glow flex w-full items-center justify-center gap-2 rounded-2xl grad-ax px-5 py-4 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02] active:scale-[0.98]"
                                >
                                    <Download className="h-5 w-5" aria-hidden="true" /> Install ApX Player
                                </button>
                            ) : (
                                <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-xs leading-relaxed text-muted-foreground">
                                    In Chrome or Edge, click the <span className="font-semibold text-foreground">install icon</span> in the address bar, or open the menu (⋮) and choose <span className="font-semibold text-foreground">Install ApX Player</span>.
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default InstallModal;
