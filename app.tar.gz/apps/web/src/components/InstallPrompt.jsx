import React, { useEffect, useState } from 'react';
import { Download, X, Apple, Smartphone } from 'lucide-react';

/**
 * Auto install banner. Listens for `beforeinstallprompt` (Android Chrome /
 * desktop) and shows a dismissible banner. On iOS — which never fires that
 * event — it shows a one-time hint that opens the full step-by-step install
 * modal (InstallModal). The modal itself is mounted once in App.jsx and opens
 * via the `apx-open-install` custom event.
 */
const InstallPrompt = () => {
    const [deferred, setDeferred] = useState(null);
    const [visible, setVisible] = useState(false);
    const [iosHint, setIosHint] = useState(false);

    useEffect(() => {
        const dismissed = localStorage.getItem('mp_install_dismissed') === '1';
        if (dismissed) return;

        const onBeforeInstall = (e) => {
            e.preventDefault();
            setDeferred(e);
            setVisible(true);
        };
        window.addEventListener('beforeinstallprompt', onBeforeInstall);

        // iOS Safari does not fire beforeinstallprompt; show a hint instead.
        const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
        const isStandalone =
            window.matchMedia('(display-mode: standalone)').matches ||
            window.matchMedia('(display-mode: fullscreen)').matches ||
            window.navigator.standalone === true;
        if (isIos && !isStandalone) setIosHint(true);

        return () => window.removeEventListener('beforeinstallprompt', onBeforeInstall);
    }, []);

    const dismiss = () => {
        setVisible(false);
        setIosHint(false);
        localStorage.setItem('mp_install_dismissed', '1');
    };

    const install = async () => {
        if (!deferred) return;
        deferred.prompt();
        const { outcome } = await deferred.userChoice.catch(() => ({}));
        setDeferred(null);
        setVisible(false);
        if (outcome === 'accepted' || outcome === 'dismissed') {
            localStorage.setItem('mp_install_dismissed', '1');
        }
    };

    const openModal = () => {
        window.dispatchEvent(new CustomEvent('apx-open-install'));
        dismiss();
    };

    if (!visible && !iosHint) return null;

    return (
        <div className="fixed inset-x-0 bottom-0 z-40 px-4 pb-4 sm:px-6 sm:pb-6">
            <div className="mx-auto flex max-w-3xl items-center gap-3 rounded-2xl border border-primary/40 bg-card/95 p-3 shadow-lg backdrop-blur sm:p-4">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl grad-ax">
                    {iosHint ? (
                        <Apple className="h-5 w-5 text-primary-foreground" aria-hidden="true" />
                    ) : (
                        <Download className="h-5 w-5 text-primary-foreground" aria-hidden="true" />
                    )}
                </span>
                <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold">Install ApX Player</p>
                    <p className="truncate text-xs text-muted-foreground">
                        {iosHint
                            ? 'Add ApX Player to your Home Screen — see how in a few steps.'
                            : 'Add it to your device for quick access to movies, series, live TV and karaoke.'}
                    </p>
                </div>
                {iosHint ? (
                    <button
                        type="button"
                        onClick={openModal}
                        className="focus-glow shrink-0 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-transform hover:bg-primary/90 active:scale-[0.98]"
                    >
                        Show steps
                    </button>
                ) : (
                    <button
                        type="button"
                        onClick={install}
                        className="focus-glow shrink-0 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-transform hover:bg-primary/90 active:scale-[0.98]"
                    >
                        Install
                    </button>
                )}
                <button
                    type="button"
                    onClick={dismiss}
                    className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-muted-foreground transition-colors hover:text-foreground"
                    aria-label="Dismiss install prompt"
                >
                    <X className="h-5 w-5" aria-hidden="true" />
                </button>
            </div>
        </div>
    );
};

export default InstallPrompt;
