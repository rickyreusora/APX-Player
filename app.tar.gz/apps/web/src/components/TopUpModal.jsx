import React, { useMemo, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Copy, Smartphone, Clock, Loader2, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import {
    TOPUP_AMOUNT,
    GCASH_NUMBER,
    buildGcashQrPayload,
    applyTopUp,
    isAndroidApp,
} from '@/lib/credits';

const STEPS = [
    'Open the GCash app and tap "Scan QR".',
    'Point your camera at the QR code on this screen.',
    'Confirm the amount is ₱20 and the recipient is the ApX Player account.',
    'Approve the payment in GCash with your MPIN.',
    'Tap "I have paid" below to submit your payment for admin approval.',
];

const TopUpModal = ({ open, onClose, user, onSuccess }) => {
    const [stage, setStage] = useState('instructions'); // instructions | confirming | pending
    const [reference, setReference] = useState('');
    const [result, setResult] = useState(null);

    const qrPayload = useMemo(() => buildGcashQrPayload(GCASH_NUMBER, TOPUP_AMOUNT), []);

    if (!open) return null;

    const copyNumber = async () => {
        try {
            await navigator.clipboard.writeText(GCASH_NUMBER);
            toast.success('GCash number copied');
        } catch (_) {
            toast.error('Could not copy — enter it manually');
        }
    };

    const confirmPayment = async () => {
        setStage('confirming');
        try {
            const res = await applyTopUp(user, {
                amount: TOPUP_AMOUNT,
                reference: reference.trim() || undefined,
                notes: 'GCash top-up',
            });
            // Do NOT credit the account or notify the Android app here —
            // an administrator must approve the payment first. The Android
            // unlock fires only after approval (handled in the admin panel).
            setResult(res);
            setStage('pending');
            toast.success('Payment submitted — pending admin approval');
            onSuccess?.(res);
        } catch (err) {
            toast.error(err?.message || 'Could not submit the top-up.');
            setStage('instructions');
        }
    };

    const close = () => {
        setStage('instructions');
        setReference('');
        setResult(null);
        onClose?.();
    };

    return (
        <div
            className="fixed inset-0 z-[80] flex items-end justify-center bg-black/80 p-0 backdrop-blur-sm sm:items-center sm:p-4"
            role="dialog"
            aria-modal="true"
            aria-label="Top up credits with GCash"
        >
            <div className="relative w-full max-w-md overflow-hidden rounded-t-2xl border border-border bg-card shadow-2xl sm:rounded-xl">
                {/* header */}
                <div className="flex items-center justify-between border-b border-border px-5 py-4">
                    <div className="flex items-center gap-2">
                        <Wallet className="h-5 w-5 text-primary" />
                        <h2 className="text-base font-semibold">Add ₱{TOPUP_AMOUNT} Credit</h2>
                    </div>
                    <button
                        type="button"
                        onClick={close}
                        className="grid h-9 w-9 place-items-center rounded-sm text-muted-foreground hover:bg-secondary hover:text-foreground"
                        aria-label="Close"
                    >
                        <X className="h-5 w-5" />
                    </button>
                </div>

                {stage === 'pending' ? (
                    <div className="px-5 py-10 text-center">
                        <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-amber-500/15">
                            <Clock className="h-9 w-9 text-amber-500" />
                        </div>
                        <h3 className="display text-3xl">Payment submitted</h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                            Your ₱{TOPUP_AMOUNT} GCash payment is now <span className="font-semibold text-amber-500">pending admin approval</span>.
                        </p>
                        <p className="mt-4 text-sm text-muted-foreground">
                            Credits are not added until an administrator verifies your payment. You will be notified by email once it is approved or rejected.
                        </p>
                        {result?.transaction?.reference && (
                            <p className="mt-4 text-xs text-muted-foreground">
                                Reference: <span className="font-mono text-foreground">{result.transaction.reference}</span>
                            </p>
                        )}
                        <button
                            type="button"
                            onClick={close}
                            className="focus-glow mt-6 min-h-[44px] w-full rounded-full grad-ax text-sm font-semibold text-primary-foreground active:scale-[0.99]"
                        >
                            Done
                        </button>
                    </div>
                ) : (
                    <div className="max-h-[80dvh] overflow-y-auto px-5 py-5">
                        {/* QR */}
                        <div className="flex flex-col items-center">
                            <div className="rounded-xl bg-white p-3 shadow-lg">
                                <QRCodeSVG
                                    value={qrPayload}
                                    size={208}
                                    level="M"
                                    includeMargin={false}
                                />
                            </div>
                            <p className="mt-3 text-xs text-muted-foreground">
                                Scan with the GCash app to pay ₱{TOPUP_AMOUNT}
                            </p>
                        </div>

                        {/* GCash account details */}
                        <div className="mt-5 rounded-sm border border-border bg-secondary/40 p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-[11px] uppercase tracking-wider text-muted-foreground">GCash account</p>
                                    <p className="text-lg font-semibold tracking-wide">{GCASH_NUMBER}</p>
                                </div>
                                <button
                                    type="button"
                                    onClick={copyNumber}
                                    className="inline-flex items-center gap-1.5 rounded-sm border border-border px-3 py-2 text-xs font-medium hover:border-primary hover:text-primary"
                                >
                                    <Copy className="h-3.5 w-3.5" /> Copy
                                </button>
                            </div>
                            <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
                                <span className="text-xs text-muted-foreground">Amount to send</span>
                                <span className="text-base font-bold text-primary">₱{TOPUP_AMOUNT}.00</span>
                            </div>
                        </div>

                        {/* steps */}
                        <ol className="mt-5 space-y-2.5">
                            {STEPS.map((s, i) => (
                                <li key={i} className="flex gap-3 text-sm">
                                    <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-primary/15 text-[11px] font-bold text-primary">
                                        {i + 1}
                                    </span>
                                    <span className="text-muted-foreground">{s}</span>
                                </li>
                            ))}
                        </ol>

                        {/* optional reference */}
                        <div className="mt-5">
                            <label htmlFor="gcash-ref" className="text-xs text-muted-foreground">
                                GCash reference number (optional)
                            </label>
                            <input
                                id="gcash-ref"
                                value={reference}
                                onChange={(e) => setReference(e.target.value)}
                                placeholder="e.g. 2301 4567 8901"
                                className="mt-1.5 h-11 w-full rounded-sm border border-border bg-secondary/50 px-3 text-sm"
                            />
                        </div>

                        {isAndroidApp() && (
                            <p className="mt-4 inline-flex items-center gap-1.5 rounded-sm bg-primary/10 px-3 py-2 text-xs font-medium text-primary">
                                <Smartphone className="h-3.5 w-3.5" /> Running inside ApX Player Android app
                            </p>
                        )}

                        <button
                            type="button"
                            onClick={confirmPayment}
                            disabled={stage === 'confirming'}
                            className="focus-glow mt-5 min-h-[48px] w-full rounded-full grad-ax text-sm font-semibold text-primary-foreground shadow-[0_0_20px_hsl(187_95%_55%/0.4)] active:scale-[0.99] disabled:opacity-60"
                        >
                            {stage === 'confirming' ? (
                                <span className="inline-flex items-center gap-2">
                                    <Loader2 className="h-4 w-4 animate-spin" /> Confirming…
                                </span>
                            ) : (
                                `I have paid — add ₱${TOPUP_AMOUNT}`
                            )}
                        </button>
                        <p className="mt-3 text-center text-[11px] text-muted-foreground">
                            Credits unlock immediately after confirmation. For help, contact support.
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default TopUpModal;
