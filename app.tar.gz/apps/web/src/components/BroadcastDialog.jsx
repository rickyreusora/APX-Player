import React, { useEffect, useState } from 'react';
import { Megaphone, X } from 'lucide-react';
import {
    dismissBroadcast,
    getActiveBroadcast,
    isBroadcastDismissed,
} from '@/lib/broadcast';

/**
 * Site-wide broadcast pop-up. Fetches the active broadcast and shows it
 * as a modal dialog until the visitor dismisses it with the OK button.
 * Dismissal is persisted per broadcast version (id + updated timestamp)
 * so it stays hidden for the rest of the session but reappears when an
 * admin publishes or edits the broadcast.
 */
const BroadcastDialog = () => {
    const [broadcast, setBroadcast] = useState(null);
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        let cancelled = false;
        getActiveBroadcast().then((rec) => {
            if (cancelled || !rec) return;
            setBroadcast(rec);
            if (!isBroadcastDismissed(rec)) setVisible(true);
        });
        return () => {
            cancelled = true;
        };
    }, []);

    // Re-check when the tab regains focus, so a newly published broadcast
    // appears without requiring a full reload.
    useEffect(() => {
        const onFocus = () => {
            getActiveBroadcast().then((rec) => {
                setBroadcast(rec);
                if (rec && !isBroadcastDismissed(rec)) setVisible(true);
            });
        };
        window.addEventListener('focus', onFocus);
        return () => window.removeEventListener('focus', onFocus);
    }, []);

    const handleClose = () => {
        if (broadcast) dismissBroadcast(broadcast);
        setVisible(false);
    };

    if (!visible || !broadcast) return null;

    return (
        <div
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
            role="dialog"
            aria-modal="true"
            aria-label="Announcement"
        >
            <div className="ring-grad relative w-full max-w-md overflow-hidden rounded-2xl border border-white/10 bg-card p-6 shadow-2xl">
                <button
                    type="button"
                    onClick={handleClose}
                    className="focus-glow absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-white/5 text-muted-foreground hover:bg-white/10 hover:text-foreground"
                    aria-label="Close announcement"
                >
                    <X className="h-4 w-4" />
                </button>

                <div className="mb-4 flex items-center gap-3">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl grad-ax shadow-[0_0_18px_hsl(187_95%_55%/0.4)]">
                        <Megaphone className="h-5 w-5 text-primary-foreground" strokeWidth={2.4} />
                    </span>
                    <div className="min-w-0">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">
                            Announcement
                        </p>
                        <h2 className="font-display text-xl font-bold leading-tight">
                            {broadcast.title || 'Message from ApX Player'}
                        </h2>
                    </div>
                </div>

                <p className="whitespace-pre-line text-sm leading-relaxed text-foreground/90">
                    {broadcast.message}
                </p>

                <div className="mt-6 flex justify-end">
                    <button
                        type="button"
                        onClick={handleClose}
                        className="focus-glow inline-flex min-h-[44px] items-center justify-center rounded-full grad-ax px-8 text-sm font-semibold text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.35)] transition-transform hover:scale-[1.03] active:scale-[0.98]"
                    >
                        OK
                    </button>
                </div>
            </div>
        </div>
    );
};

export default BroadcastDialog;
