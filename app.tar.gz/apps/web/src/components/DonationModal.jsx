import React, { useMemo, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Copy, Smartphone, Clock, Loader2, Crown, Upload, Image as ImageIcon } from 'lucide-react';
import { toast } from 'sonner';
import {
    PREMIUM_MIN_DONATION,
    GCASH_NUMBER,
    buildGcashQrPayload,
    submitDonation,
    isAndroidApp,
} from '@/lib/premium';

const STEPS = [
    'Open the GCash app and tap "Send Money" or "Scan QR".',
    'Send at least ₱50 to the ApX Player GCash account shown here.',
    'Take a screenshot of the GCash confirmation / receipt.',
    'Fill in the form below with your name, reference number and the receipt screenshot.',
    'Tap "Submit donation" — our team will review and grant your premium access.',
];

const DonationModal = ({ open, onClose, user, onSuccess }) => {
    const [amount, setAmount] = useState(String(PREMIUM_MIN_DONATION));
    const [senderName, setSenderName] = useState(user?.name || '');
    const [gcashReference, setGcashReference] = useState('');
    const [proofFile, setProofFile] = useState(null);
    const [proofPreview, setProofPreview] = useState('');
    const [submitting, setSubmitting] = useState(false);
    const [done, setDone] = useState(false);

    const qrPayload = useMemo(
        () => buildGcashQrPayload(GCASH_NUMBER, Number(amount) || PREMIUM_MIN_DONATION),
        [amount],
    );

    if (!open) return null;

    const copyNumber = async () => {
        try {
            await navigator.clipboard.writeText(GCASH_NUMBER);
            toast.success('GCash number copied');
        } catch (_) {
            toast.error('Could not copy — enter it manually');
        }
    };

    const onPickFile = (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) {
            toast.error('Please upload an image file (JPG, PNG, WEBP or GIF).');
            return;
        }
        if (file.size > 10 * 1024 * 1024) {
            toast.error('Image is too large — maximum 10 MB.');
            return;
        }
        setProofFile(file);
        setProofPreview(URL.createObjectURL(file));
    };

    const validate = () => {
        const amt = Number(amount);
        if (!Number.isFinite(amt) || amt < PREMIUM_MIN_DONATION) {
            toast.error(`Donation must be at least ₱${PREMIUM_MIN_DONATION}.`);
            return false;
        }
        if (!senderName.trim()) {
            toast.error('Please enter your sender name.');
            return false;
        }
        if (!gcashReference.trim()) {
            toast.error('Please enter your GCash reference number.');
            return false;
        }
        if (!proofFile) {
            toast.error('Please upload a proof-of-payment screenshot.');
            return false;
        }
        return true;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;
        setSubmitting(true);
        try {
            await submitDonation(user, {
                amount: Number(amount),
                senderName,
                gcashReference,
                proofFile,
            });
            setDone(true);
            toast.success('Donation submitted — pending admin approval');
            onSuccess?.();
        } catch (err) {
            toast.error(err?.message || 'Could not submit the donation.');
        } finally {
            setSubmitting(false);
        }
    };

    const close = () => {
        setAmount(String(PREMIUM_MIN_DONATION));
        setSenderName(user?.name || '');
        setGcashReference('');
        setProofFile(null);
        setProofPreview('');
        setDone(false);
        onClose?.();
    };

    return (
        <div
            className="fixed inset-0 z-[90] flex items-end justify-center bg-black/85 p-0 backdrop-blur-sm sm:items-center sm:p-4"
            role="dialog"
            aria-modal="true"
            aria-label="Submit a premium donation"
        >
            <div className="relative max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-t-2xl border border-border bg-card shadow-2xl sm:rounded-xl">
                {/* header */}
                <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-card/95 px-5 py-4 backdrop-blur">
                    <div className="flex items-center gap-2">
                        <Crown className="h-5 w-5 text-primary" />
                        <h2 className="text-base font-semibold">Get Premium Access</h2>
                    </div>
                    <button
                        type="button"
                        onClick={close}
                        className="grid h-9 w-9 place-items-center rounded-sm text-muted-foreground hover:bg-secondary hover:text-foreground"
                        aria-label="Close"
                    >
                        <X className="h-5 w-5" />
                    </button>
                </div>

                {done ? (
                    <div className="px-5 py-12 text-center">
                        <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-amber-500/15">
                            <Clock className="h-9 w-9 text-amber-500" />
                        </div>
                        <h3 className="display text-3xl">Donation submitted</h3>
                        <div className="mt-3 inline-flex items-center gap-2 rounded-full border border-amber-500/40 bg-amber-500/15 px-4 py-1.5 text-sm font-semibold text-amber-500">
                            <Clock className="h-4 w-4" aria-hidden="true" />
                            Waiting for admin approval
                        </div>
                        <p className="mt-4 text-sm text-muted-foreground">
                            Your ₱{Number(amount)} GCash donation was received and is now{' '}
                            <span className="font-semibold text-amber-500">waiting for admin approval</span>.
                        </p>
                        <p className="mt-4 text-sm text-muted-foreground">
                            Premium access to Vivamax and Viva One is granted once an administrator verifies your
                            payment. You will be notified by email when it is approved or rejected.
                        </p>
                        <button
                            type="button"
                            onClick={close}
                            className="focus-glow mt-6 min-h-[44px] w-full rounded-full grad-ax text-sm font-semibold text-primary-foreground active:scale-[0.99]"
                        >
                            Done
                        </button>
                    </div>
                ) : (
                    <form onSubmit={handleSubmit} className="px-5 py-5">
                        {/* QR + account */}
                        <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start">
                            <div className="shrink-0 rounded-xl bg-white p-3 shadow-lg">
                                <QRCodeSVG value={qrPayload} size={176} level="M" includeMargin={false} />
                            </div>
                            <div className="w-full rounded-sm border border-border bg-secondary/40 p-4">
                                <p className="text-[11px] uppercase tracking-wider text-muted-foreground">GCash account</p>
                                <div className="mt-1 flex items-center justify-between gap-2">
                                    <p className="text-lg font-semibold tracking-wide">{GCASH_NUMBER}</p>
                                    <button
                                        type="button"
                                        onClick={copyNumber}
                                        className="inline-flex items-center gap-1.5 rounded-sm border border-border px-3 py-2 text-xs font-medium hover:border-primary hover:text-primary"
                                    >
                                        <Copy className="h-3.5 w-3.5" /> Copy
                                    </button>
                                </div>
                                <p className="mt-3 text-xs text-muted-foreground">
                                    Send a donation of at least{' '}
                                    <span className="font-semibold text-primary">₱{PREMIUM_MIN_DONATION}</span> to unlock
                                    Vivamax &amp; Viva One.
                                </p>
                            </div>
                        </div>

                        {/* steps */}
                        <ol className="mt-5 space-y-2.5">
                            {STEPS.map((s, i) => (
                                <li key={i} className="flex gap-3 text-sm">
                                    <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-primary/15 text-[11px] font-bold text-primary">
                                        {i + 1}
                                    </span>
                                    <span className="text-muted-foreground">{s}</span>
                                </li>
                            ))}
                        </ol>

                        {/* form fields */}
                        <div className="mt-6 grid gap-4">
                            <div>
                                <label htmlFor="don-amount" className="text-xs font-medium text-muted-foreground">
                                    Donation amount (₱) — minimum ₱{PREMIUM_MIN_DONATION}
                                </label>
                                <input
                                    id="don-amount"
                                    type="number"
                                    min={PREMIUM_MIN_DONATION}
                                    step="1"
                                    value={amount}
                                    onChange={(e) => setAmount(e.target.value)}
                                    required
                                    className="mt-1.5 h-11 w-full rounded-sm border border-border bg-secondary/60 px-3 text-sm"
                                />
                            </div>

                            <div>
                                <label htmlFor="don-name" className="text-xs font-medium text-muted-foreground">
                                    Sender name <span className="text-destructive">*</span>
                                </label>
                                <input
                                    id="don-name"
                                    type="text"
                                    value={senderName}
                                    onChange={(e) => setSenderName(e.target.value)}
                                    required
                                    placeholder="Your full name"
                                    className="mt-1.5 h-11 w-full rounded-sm border border-border bg-secondary/60 px-3 text-sm"
                                />
                            </div>

                            <div>
                                <label htmlFor="don-ref" className="text-xs font-medium text-muted-foreground">
                                    GCash reference number <span className="text-destructive">*</span>
                                </label>
                                <input
                                    id="don-ref"
                                    type="text"
                                    value={gcashReference}
                                    onChange={(e) => setGcashReference(e.target.value)}
                                    required
                                    placeholder="e.g. 2301 4567 8901"
                                    className="mt-1.5 h-11 w-full rounded-sm border border-border bg-secondary/60 px-3 text-sm"
                                />
                            </div>

                            <div>
                                <label htmlFor="don-proof" className="text-xs font-medium text-muted-foreground">
                                    Proof-of-payment screenshot <span className="text-destructive">*</span>
                                </label>
                                <label
                                    htmlFor="don-proof"
                                    className="mt-1.5 flex cursor-pointer items-center gap-3 rounded-sm border border-dashed border-border bg-secondary/40 p-4 text-sm text-muted-foreground transition-colors hover:border-primary hover:text-primary"
                                >
                                    {proofPreview ? (
                                        <img
                                            src={proofPreview}
                                            alt="Proof preview"
                                            className="h-16 w-16 rounded-sm object-cover"
                                        />
                                    ) : (
                                        <span className="grid h-16 w-16 place-items-center rounded-sm bg-secondary">
                                            <ImageIcon className="h-6 w-6" />
                                        </span>
                                    )}
                                    <span className="flex-1">
                                        <span className="inline-flex items-center gap-1.5 font-medium text-foreground">
                                            <Upload className="h-4 w-4" /> {proofFile ? proofFile.name : 'Choose an image'}
                                        </span>
                                        <span className="mt-0.5 block text-[11px]">JPG, PNG, WEBP or GIF — max 10 MB</span>
                                    </span>
                                </label>
                                <input
                                    id="don-proof"
                                    type="file"
                                    accept="image/jpeg,image/png,image/webp,image/gif"
                                    onChange={onPickFile}
                                    className="sr-only"
                                />
                            </div>
                        </div>

                        {isAndroidApp() && (
                            <p className="mt-4 inline-flex items-center gap-1.5 rounded-sm bg-primary/10 px-3 py-2 text-xs font-medium text-primary">
                                <Smartphone className="h-3.5 w-3.5" /> Running inside ApX Player Android app
                            </p>
                        )}

                        <button
                            type="submit"
                            disabled={submitting}
                            className="focus-glow mt-6 min-h-[48px] w-full rounded-full grad-ax text-sm font-semibold text-primary-foreground shadow-[0_0_20px_hsl(187_95%_55%/0.4)] active:scale-[0.99] disabled:opacity-60"
                        >
                            {submitting ? (
                                <span className="inline-flex items-center gap-2">
                                    <Loader2 className="h-4 w-4 animate-spin" /> Submitting…
                                </span>
                            ) : (
                                'Submit donation'
                            )}
                        </button>
                        <p className="mt-3 text-center text-[11px] text-muted-foreground">
                            Premium access is granted after an admin verifies your payment. For help, contact support.
                        </p>
                    </form>
                )}
            </div>
        </div>
    );
};

export default DonationModal;
