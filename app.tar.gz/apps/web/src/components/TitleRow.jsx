import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import TitleCard from '@/components/TitleCard';

const SkeletonCard = () => (
    <div className="w-[150px] shrink-0 sm:w-[180px]">
        <div className="aspect-[2/3] animate-pulse rounded-2xl bg-secondary" />
    </div>
);

const TitleRow = ({ heading, kicker, items = [], loading = false, emptyMessage = 'Nothing here yet.', progressMap }) => {
    const scroller = useRef(null);

    const scrollBy = (dir) => {
        scroller.current?.scrollBy({ left: dir * (scroller.current.clientWidth * 0.8), behavior: 'smooth' });
    };

    return (
        <section className="py-8">
            <div className="mx-auto flex max-w-[90rem] items-end justify-between gap-4 px-4 sm:px-6">
                <div className="flex items-center gap-3">
                    <span className="h-9 w-1.5 rounded-full grad-ax" aria-hidden="true" />
                    <div>
                        {kicker && (
                            <p className="mb-0.5 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">{kicker}</p>
                        )}
                        <h2 className="font-display text-2xl font-bold sm:text-3xl">{heading}</h2>
                    </div>
                </div>
                <div className="hidden gap-2 sm:flex">
                    <button
                        type="button"
                        onClick={() => scrollBy(-1)}
                        aria-label={`Scroll ${heading} left`}
                        className="focus-glow grid h-9 w-9 place-items-center rounded-full border border-white/10 bg-white/5 transition-colors hover:border-primary hover:text-primary"
                    >
                        <ChevronLeft className="h-4 w-4" />
                    </button>
                    <button
                        type="button"
                        onClick={() => scrollBy(1)}
                        aria-label={`Scroll ${heading} right`}
                        className="focus-glow grid h-9 w-9 place-items-center rounded-full border border-white/10 bg-white/5 transition-colors hover:border-primary hover:text-primary"
                    >
                        <ChevronRight className="h-4 w-4" />
                    </button>
                </div>
            </div>

            <div
                ref={scroller}
                className="no-scrollbar mt-5 flex snap-x gap-4 overflow-x-auto px-4 pb-2 sm:px-6"
            >
                {loading &&
                    Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)}
                {!loading && items.length === 0 && (
                    <p className="py-8 text-sm text-muted-foreground">{emptyMessage}</p>
                )}
                {!loading &&
                    items.map((t) => (
                        <div key={`${t.kind || 'item'}-${t.tmdb_id || t.id}`} className="w-[150px] shrink-0 snap-start sm:w-[180px]">
                            <TitleCard title={t} progressPercent={progressMap ? progressMap[t.id] ?? progressMap[t.tmdb_id] ?? null : null} />
                        </div>
                    ))}
            </div>
        </section>
    );
};

export default TitleRow;
