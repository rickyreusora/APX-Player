import React from 'react';
import { AlertTriangle, Loader2, Inbox } from 'lucide-react';

export const LoadingState = ({ label = 'Loading…' }) => (
    <div className="flex items-center justify-center gap-3 py-20 text-sm text-muted-foreground" role="status">
        <Loader2 className="h-5 w-5 animate-spin text-primary" aria-hidden="true" />
        {label}
    </div>
);

export const ErrorState = ({ message = 'Something went wrong.', onRetry }) => (
    <div className="mx-auto max-w-md rounded-sm border border-destructive/40 bg-destructive/10 p-6 text-center" role="alert">
        <AlertTriangle className="mx-auto mb-3 h-6 w-6 text-destructive" aria-hidden="true" />
        <p className="text-sm text-foreground">{message}</p>
        {onRetry && (
            <button
                type="button"
                onClick={onRetry}
                className="focus-glow mt-4 rounded-full grad-ax px-4 py-2 text-sm font-semibold text-primary-foreground active:scale-[0.98]"
            >
                Try again
            </button>
        )}
    </div>
);

export const EmptyState = ({ title = 'Nothing here yet', description, action }) => (
    <div className="mx-auto max-w-md rounded-sm border border-dashed border-border bg-card/40 p-10 text-center">
        <Inbox className="mx-auto mb-3 h-7 w-7 text-muted-foreground" aria-hidden="true" />
        <h3 className="text-base font-semibold">{title}</h3>
        {description && <p className="mt-2 text-sm text-muted-foreground">{description}</p>}
        {action && <div className="mt-5">{action}</div>}
    </div>
);

export const SkeletonGrid = ({ count = 12 }) => (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
        {Array.from({ length: count }).map((_, i) => (
            <div key={i} className="aspect-[2/3] animate-pulse rounded-sm bg-secondary" />
        ))}
    </div>
);
