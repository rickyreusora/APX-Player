import React, { useMemo, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Copy, Crown, Lock } from 'lucide-react';
import { toast } from 'sonner';
import {
    PREMIUM_MIN_DONATION,
    GCASH_NUMBER,
    buildGcashQrPayload,
} from '@/lib/premium';
import DonationModal from '@/components/DonationModal';
import { useAuth } from '@/contexts/AuthContext';

/**
 * Shown when a non-premium user tries to play Vivamax / Viva One content.
 * Lets them open the full donation form.
 */
const PremiumPromptModal = ({ open, onClose, titleName = 'this title' }) => {
    const { user, refreshUser } = useAuth();
    const [donateOpen, setDonateOpen] = useState(false);

    const qrPayload = useMemo(
        () => buildGcashQrPayload(GCASH_NUMBER, PREMIUM_MIN_DONATION),
        [],
    );

    if (!open) return null;

    const copyNumber = async () => {
        try {
            await navigator.clipboard.writeText(GCASH_NUMBER);
            toast.success('GCash number copied');
        } catch (_) {
            toast.error('Could not copy — enter it manually');
        }
    };

    const close = () => {
        setDonateOpen(false);
        onClose?.();
    };

    return (
        <>
            <div
                className="fixed inset-0 z-[85] flex items-end justify-center bg-black/85 p-0 backdrop-blur-sm sm:items-center sm:p-4"
                role="dialog"
                aria-modal="true"
                aria-label="Premium access required"
            >
                <div className="relative w-full max-w-md overflow-hidden rounded-t-2xl border border-border bg-card shadow-2xl sm:rounded-xl">
                    <div className="flex items-center justify-between border-b border-border px-5 py-4">
                        <div className="flex items-center gap-2">
                            <Lock className="h-5 w-5 text-primary" />
                            <h2 className="text-base font-semibold">Premium access required</h2>
                        </div>
                        <button
                            type="button"
                            onClick={close}
                            className="grid h-9 w-9 place-items-center rounded-sm text-muted-foreground hover:bg-secondary hover:text-foreground"
                            aria-label="Close"
                        >
                            <X className="h-5 w-5" />
                        </button>
                    </div>

                    <div className="px-5 py-6 text-center">
                        <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full grad-ax shadow-[0_0_24px_hsl(187_95%_55%/0.5)]">
                            <Crown className="h-8 w-8 text-primary-foreground" />
                        </div>
                        <h3 className="display text-3xl">Unlock {titleName}</h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                            This title is part of our <span className="font-semibold text-foreground">Vivamax / Viva One</span>{' '}
                            premium collection. Send a one-time donation of at least{' '}
                            <span className="font-semibold text-primary">₱{PREMIUM_MIN_DONATION}</span> to unlock every
                            premium title.
                        </p>

                        <div className="mt-5 flex flex-col items-center gap-4 sm:flex-row sm:items-start">
                            <div className="shrink-0 rounded-xl bg-white p-2.5 shadow-lg">
                                <QRCodeSVG value={qrPayload} size={150} level="M" includeMargin={false} />
                            </div>
                            <div className="w-full rounded-sm border border-border bg-secondary/40 p-4 text-left">
                                <p className="text-[11px] uppercase tracking-wider text-muted-foreground">GCash account</p>
                                <div className="mt-1 flex items-center justify-between gap-2">
                                    <p className="text-base font-semibold tracking-wide">{GCASH_NUMBER}</p>
                                    <button
                                        type="button"
                                        onClick={copyNumber}
                                        className="inline-flex items-center gap-1.5 rounded-sm border border-border px-2.5 py-1.5 text-xs font-medium hover:border-primary hover:text-primary"
                                    >
                                        <Copy className="h-3.5 w-3.5" /> Copy
                                    </button>
                                </div>
                                <p className="mt-2 text-xs text-muted-foreground">
                                    Minimum donation: <span className="font-semibold text-primary">₱{PREMIUM_MIN_DONATION}</span>
                                </p>
                            </div>
                        </div>

                        <button
                            type="button"
                            onClick={() => setDonateOpen(true)}
                            className="focus-glow mt-6 min-h-[48px] w-full rounded-full grad-ax text-sm font-semibold text-primary-foreground shadow-[0_0_20px_hsl(187_95%_55%/0.4)] active:scale-[0.99]"
                        >
                            Submit my donation
                        </button>
                        <button
                            type="button"
                            onClick={close}
                            className="mt-3 min-h-[44px] w-full rounded-full border border-border text-sm font-semibold hover:border-primary hover:text-primary"
                        >
                            Maybe later
                        </button>
                    </div>
                </div>
            </div>

            <DonationModal
                open={donateOpen}
                onClose={() => setDonateOpen(false)}
                user={user}
                onSuccess={() => refreshUser().catch(() => {})}
            />
        </>
    );
};

export default PremiumPromptModal;
