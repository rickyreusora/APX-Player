import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
    Download,
    Gauge,
    Loader2,
    Mic,
    MicOff,
    Music2,
    Pause,
    Play,
    Radio,
    RotateCcw,
    ShieldAlert,
    SkipForward,
    Square,
    Volume2,
    Waves,
    X,
} from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { cn } from '@/lib/utils';
import { loadYouTubeIframeApi } from '@/lib/loadYouTubeIframeApi';
import { KaraokeEngine, blobToWav } from '@/lib/karaokeEngine';
import { getGreeting } from '@/lib/uiScore';

const fmt = (s) => {
    if (!s || Number.isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${String(sec).padStart(2, '0')}`;
};

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const freqToMidi = (f) => (f && f > 0 ? Math.round(12 * Math.log2(f / 440)) + 69 : null);
const midiToName = (n) => {
    if (n == null) return null;
    return `${NOTE_NAMES[((n % 12) + 12) % 12]}${Math.floor(n / 12) - 1}`;
};

const ControlButton = ({ icon: Icon, label, onClick, active, disabled, children }) => (
    <button
        type="button"
        data-focusable
        onClick={onClick}
        disabled={disabled}
        aria-label={label}
        title={label}
        className={cn(
            'inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-sm font-medium transition-colors',
            active
                ? 'border-primary bg-primary/15 text-primary'
                : 'border-white/10 bg-white/5 text-foreground hover:border-primary/40 hover:bg-white/10',
            disabled && 'cursor-not-allowed opacity-40',
        )}
    >
        {Icon && <Icon className="h-4 w-4" aria-hidden="true" />}
        {children}
    </button>
);

/**
 * YoutubeKaraokePlayer — plays a YouTube karaoke video with simple transport
 * controls (play/pause, restart, seek, volume, tempo), microphone input for
 * singing along, real-time pitch detection + vocal-accuracy score, echo/reverb
 * effects, and recording with WAV download. No lyrics synchronisation — the
 * video is shown directly so the user can follow the on-screen karaoke text.
 */
const YoutubeKaraokePlayer = ({ videoId, title, author, onClose }) => {
    const playerRef = useRef(null);
    const containerRef = useRef(null);
    const engineRef = useRef(null);
    const waveCanvasRef = useRef(null);
    const rafRef = useRef(0);
    const scoreRef = useRef({ with: 0, total: 0 });
    const endedHandledRef = useRef(false);

    const [ready, setReady] = useState(false);
    const [playing, setPlaying] = useState(false);
    const [elapsed, setElapsed] = useState(0);
    const [duration, setDuration] = useState(0);
    const [rate, setRate] = useState(1);
    const [volume, setVolume] = useState(100);

    const [micOn, setMicOn] = useState(false);
    const [micError, setMicError] = useState('');
    const [recording, setRecording] = useState(false);
    const [recUrl, setRecUrl] = useState(null);
    const [detectedNote, setDetectedNote] = useState(null);
    const [score, setScore] = useState(0);
    const [echo, setEcho] = useState(0);
    const [reverb, setReverb] = useState(0);

    const ensureEngine = useCallback(() => {
        if (!engineRef.current) engineRef.current = new KaraokeEngine();
        return engineRef.current;
    }, []);

    // Persist a performance record (vocal-accuracy score + greeting) to
    // localStorage so the dashboard / ranking can surface past performances.
    const savePerformance = useCallback((finalScore) => {
        try {
            const key = 'apx-karaoke-history';
            const raw = localStorage.getItem(key);
            const list = raw ? JSON.parse(raw) : [];
            list.unshift({
                title: title || 'Karaoke',
                artist: author || '',
                code: videoId || null,
                score: finalScore,
                greeting: getGreeting(finalScore),
                date: Date.now(),
            });
            localStorage.setItem(key, JSON.stringify(list.slice(0, 50)));
        } catch {
            /* ignore quota / parse errors */
        }
    }, [title, author, videoId]);

    // Create the YouTube player. The iframe is shown directly so the user can
    // follow the karaoke video; its audio is the backing track.
    useEffect(() => {
        let cancelled = false;
        let api;
        endedHandledRef.current = false;
        loadYouTubeIframeApi()
            .then((YT) => {
                if (cancelled) return;
                api = YT;
                playerRef.current = new YT.Player(containerRef.current, {
                    videoId,
                    playerVars: {
                        autoplay: 1,
                        controls: 0,
                        modestbranding: 1,
                        rel: 0,
                        playsinline: 1,
                    },
                    events: {
                        onReady: (e) => {
                            if (cancelled) return;
                            try {
                                e.target.setVolume(volume);
                                setDuration(e.target.getDuration() || 0);
                            } catch (_) { /* ignore */ }
                            setReady(true);
                        },
                        onStateChange: (e) => {
                            if (cancelled) return;
                            const P = api.PlayerState;
                            setPlaying(e.data === P.PLAYING);
                            if (e.data === P.PLAYING) {
                                try { setDuration(e.target.getDuration() || 0); } catch (_) { /* ignore */ }
                            }
                            // On natural end, record the score and advance.
                            if (e.data === P.ENDED && !endedHandledRef.current) {
                                endedHandledRef.current = true;
                                const finalScore = scoreRef.current.total > 0
                                    ? Math.round((scoreRef.current.with / scoreRef.current.total) * 100)
                                    : 0;
                                savePerformance(finalScore);
                                toast.success(`Performance complete — score ${finalScore}/100`);
                                if (onClose) onClose();
                            }
                        },
                    },
                });
            })
            .catch(() => {
                setMicError('Could not load the YouTube video. Check your connection and try again.');
            });
        return () => {
            cancelled = true;
            cancelAnimationFrame(rafRef.current);
            try { if (playerRef.current) playerRef.current.destroy(); } catch (_) { /* ignore */ }
            playerRef.current = null;
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [videoId]);

    // Animation loop: time + pitch + waveform + score.
    useEffect(() => {
        const loop = () => {
            const p = playerRef.current;
            if (p && ready) {
                try {
                    setElapsed(p.getCurrentTime() || 0);
                    const d = p.getDuration();
                    if (d) setDuration(d);
                } catch (_) { /* ignore */ }
            }
            const eng = engineRef.current;
            if (eng && micOn) {
                const f = eng.detectPitch();
                if (f > 0) {
                    const midi = freqToMidi(f);
                    setDetectedNote(midiToName(midi));
                    scoreRef.current.total++;
                    scoreRef.current.with++;
                } else {
                    scoreRef.current.total++;
                    setDetectedNote(null);
                }
                if (scoreRef.current.total > 0) {
                    setScore(Math.round((scoreRef.current.with / scoreRef.current.total) * 100));
                }
                drawWave(eng);
            }
            rafRef.current = requestAnimationFrame(loop);
        };
        rafRef.current = requestAnimationFrame(loop);
        return () => cancelAnimationFrame(rafRef.current);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ready, micOn]);

    const drawWave = (eng) => {
        const canvas = waveCanvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const data = eng.getMicWaveform();
        if (!data) return;
        const w = canvas.width;
        const h = canvas.height;
        ctx.clearRect(0, 0, w, h);
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#e11d48';
        ctx.beginPath();
        const slice = w / data.length;
        for (let i = 0; i < data.length; i++) {
            const v = data[i] / 128.0;
            const y = (v * h) / 2;
            const x = i * slice;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }
        ctx.stroke();
    };

    const togglePlay = useCallback(() => {
        const p = playerRef.current;
        if (!p || !ready) return;
        try {
            if (playing) p.pauseVideo();
            else p.playVideo();
        } catch (_) { /* ignore */ }
    }, [playing, ready]);

    const restart = useCallback(() => {
        const p = playerRef.current;
        if (!p || !ready) return;
        try { p.seekTo(0, true); p.playVideo(); } catch (_) { /* ignore */ }
    }, [ready]);

    const onSeek = useCallback((val) => {
        const p = playerRef.current;
        if (!p || !ready) return;
        try { p.seekTo(val[0], true); setElapsed(val[0]); } catch (_) { /* ignore */ }
    }, [ready]);

    const onRate = useCallback((val) => {
        const r = val[0];
        setRate(r);
        try { playerRef.current?.setPlaybackRate(r); } catch (_) { /* ignore */ }
    }, []);

    const onVolume = useCallback((val) => {
        const v = val[0];
        setVolume(v);
        try { playerRef.current?.setVolume(v); } catch (_) { /* ignore */ }
    }, []);

    const onEcho = useCallback((val) => {
        setEcho(val[0]);
        engineRef.current?.setEcho(val[0]);
    }, []);

    const onReverb = useCallback((val) => {
        setReverb(val[0]);
        engineRef.current?.setReverb(val[0]);
    }, []);

    const toggleMic = useCallback(async () => {
        const eng = ensureEngine();
        if (micOn) {
            eng.disableMic();
            setMicOn(false);
            setDetectedNote(null);
        } else {
            try {
                await eng.enableMic();
                eng.setEcho(echo);
                eng.setReverb(reverb);
                scoreRef.current = { with: 0, total: 0 };
                setScore(0);
                setMicOn(true);
                setMicError('');
                toast.success('Microphone enabled');
            } catch (err) {
                setMicError(
                    err?.name === 'NotAllowedError'
                        ? 'Microphone access was denied. Allow mic permission in your browser settings.'
                        : 'Could not access microphone. Connect a mic and allow permission.',
                );
            }
        }
    }, [micOn, echo, reverb, ensureEngine]);

    const toggleRecord = useCallback(async () => {
        const eng = engineRef.current;
        if (!eng) return;
        if (recording) {
            const blob = await eng.stopRecording();
            setRecording(false);
            if (blob) {
                const url = URL.createObjectURL(blob);
                setRecUrl((old) => { if (old) URL.revokeObjectURL(old); return url; });
                toast.success('Recording saved — ready to play back or download');
            }
        } else {
            if (!micOn) {
                toast.error('Enable the microphone first to record your vocals');
                return;
            }
            if (eng.startRecording()) {
                setRecording(true);
                setRecUrl((old) => { if (old) URL.revokeObjectURL(old); return null; });
                toast.info('Recording started — sing along!');
            }
        }
    }, [recording, micOn]);

    const downloadRec = useCallback(async () => {
        if (!recUrl) return;
        try {
            const resp = await fetch(recUrl);
            const blob = await resp.blob();
            const out = await blobToWav(blob);
            const url = URL.createObjectURL(out);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${(title || 'karaoke').replace(/[^\w]+/g, '_')}_performance.wav`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            URL.revokeObjectURL(url);
        } catch {
            toast.error('Could not prepare the download');
        }
    }, [recUrl, title]);

    useEffect(() => {
        return () => {
            if (engineRef.current) {
                engineRef.current.destroy();
                engineRef.current = null;
            }
            if (recUrl) URL.revokeObjectURL(recUrl);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <div className="space-y-5">
            {/* Top bar — simple title + artist + score */}
            <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                    <h2 className="display truncate text-2xl leading-none sm:text-3xl">{title || 'Karaoke'}</h2>
                    {author && <p className="mt-1 truncate text-sm text-muted-foreground">{author}</p>}
                </div>
                <div className="flex items-center gap-2">
                    <div className="flex items-center gap-2 rounded-lg border border-primary/30 bg-primary/10 px-3 py-2">
                        <Music2 className="h-4 w-4 text-primary" aria-hidden="true" />
                        <span className="text-sm font-bold tabular-nums">{score}</span>
                        <span className="text-xs text-muted-foreground">/100</span>
                    </div>
                    {onClose && (
                        <Button variant="secondary" data-focusable onClick={onClose} className="active:scale-[0.98]">
                            <SkipForward className="h-4 w-4" aria-hidden="true" /> Close
                        </Button>
                    )}
                </div>
            </div>

            {/* Visible YouTube video — the karaoke backing track + on-screen lyrics */}
            <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-black" style={{ aspectRatio: '16 / 9' }}>
                <div ref={containerRef} className="absolute inset-0 h-full w-full" />
                {!ready && (
                    <div className="absolute inset-0 grid place-items-center bg-black/60">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" aria-hidden="true" />
                    </div>
                )}
            </div>

            {micError && (
                <Alert variant="destructive" className="rounded-lg">
                    <ShieldAlert className="h-4 w-4" aria-hidden="true" />
                    <AlertDescription className="text-xs">{micError}</AlertDescription>
                </Alert>
            )}

            <div className="grid gap-5 lg:grid-cols-[1.3fr_1fr]">
                {/* Transport */}
                <section className="rounded-2xl border border-white/10 bg-card/60 p-5 backdrop-blur-xl sm:p-6">
                    <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                        <Play className="h-4 w-4 text-primary" aria-hidden="true" /> Playback
                    </h3>
                    <div className="flex items-center gap-3">
                        <Button data-focusable onClick={togglePlay} disabled={!ready} size="lg" className="h-12 w-12 rounded-full p-0 active:scale-[0.97]">
                            {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                            <span className="sr-only">{playing ? 'Pause' : 'Play'}</span>
                        </Button>
                        <Button variant="secondary" data-focusable onClick={restart} disabled={!ready} size="lg" className="h-12 w-12 rounded-full p-0 active:scale-[0.97]">
                            <RotateCcw className="h-5 w-5" />
                            <span className="sr-only">Restart</span>
                        </Button>
                        <span className="ml-2 w-12 text-xs tabular-nums text-muted-foreground">{fmt(elapsed)}</span>
                        <Slider data-focusable value={[elapsed]} max={duration || 1} step={0.5} onValueChange={onSeek} disabled={!ready} className="flex-1" aria-label="Seek" />
                        <span className="w-12 text-right text-xs tabular-nums text-muted-foreground">{fmt(duration)}</span>
                    </div>

                    <div className="mt-6 grid gap-5 sm:grid-cols-2">
                        <div className="rounded-xl border border-white/10 bg-white/5 p-4">
                            <div className="mb-3 flex items-center justify-between">
                                <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                                    <Volume2 className="h-4 w-4 text-primary" aria-hidden="true" /> Volume
                                </span>
                                <span className="font-mono text-sm font-bold text-primary">{volume}%</span>
                            </div>
                            <Slider data-focusable value={[volume]} min={0} max={100} step={1} onValueChange={onVolume} disabled={!ready} aria-label="Volume" />
                        </div>
                        <div className="rounded-xl border border-white/10 bg-white/5 p-4">
                            <div className="mb-3 flex items-center justify-between">
                                <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                                    <Gauge className="h-4 w-4 text-primary" aria-hidden="true" /> Tempo
                                </span>
                                <span className="font-mono text-sm font-bold text-primary">{Math.round(rate * 100)}%</span>
                            </div>
                            <Slider data-focusable value={[rate]} min={0.25} max={2} step={0.05} onValueChange={onRate} disabled={!ready} aria-label="Tempo" />
                        </div>
                        <div className="flex flex-col justify-between rounded-xl border border-white/10 bg-white/5 p-4">
                            <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                                <Radio className="h-4 w-4 text-primary" aria-hidden="true" /> Detected pitch
                            </span>
                            <span className="mt-2 font-mono text-2xl font-bold text-primary">{detectedNote || '—'}</span>
                            <p className="mt-1 text-[11px] text-muted-foreground">Vocal score reflects sustained pitched singing.</p>
                        </div>
                        <div className="flex items-center justify-center rounded-xl border border-white/10 bg-white/5 p-4">
                            <Button
                                variant="secondary"
                                data-focusable
                                onClick={onClose}
                                disabled={!onClose}
                                className="active:scale-[0.98]"
                            >
                                <SkipForward className="h-4 w-4" aria-hidden="true" /> Next / Close
                            </Button>
                        </div>
                    </div>
                </section>

                {/* Mic + recording */}
                <section className="space-y-4 rounded-2xl border border-white/10 bg-card/60 p-5 backdrop-blur-xl sm:p-6">
                    <h3 className="flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                        <Mic className="h-4 w-4 text-primary" aria-hidden="true" /> Microphone
                    </h3>
                    <div className="flex flex-wrap gap-2">
                        <ControlButton icon={micOn ? Mic : MicOff} label={micOn ? 'Disable microphone' : 'Enable microphone'} active={micOn} onClick={toggleMic}>
                            {micOn ? 'Mic on' : 'Mic off'}
                        </ControlButton>
                        <ControlButton icon={recording ? Square : Radio} label={recording ? 'Stop recording' : 'Start recording'} active={recording} onClick={toggleRecord} disabled={!micOn && !recording}>
                            {recording ? 'Stop' : 'Record'}
                        </ControlButton>
                    </div>

                    <div className="overflow-hidden rounded-xl border border-white/10 bg-black/40">
                        <canvas ref={waveCanvasRef} width={600} height={120} className="h-24 w-full" />
                    </div>

                    <div className="grid gap-4 sm:grid-cols-2">
                        <div>
                            <div className="mb-2 flex items-center justify-between">
                                <span className="inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                                    <Waves className="h-3.5 w-3.5 text-primary" aria-hidden="true" /> Echo
                                </span>
                                <span className="font-mono text-xs font-bold text-primary">{Math.round(echo * 100)}%</span>
                            </div>
                            <Slider data-focusable value={[echo]} min={0} max={1} step={0.05} onValueChange={onEcho} aria-label="Echo" />
                        </div>
                        <div>
                            <div className="mb-2 flex items-center justify-between">
                                <span className="inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                                    <Radio className="h-3.5 w-3.5 text-primary" aria-hidden="true" /> Reverb
                                </span>
                                <span className="font-mono text-xs font-bold text-primary">{Math.round(reverb * 100)}%</span>
                            </div>
                            <Slider data-focusable value={[reverb]} min={0} max={1} step={0.05} onValueChange={onReverb} aria-label="Reverb" />
                        </div>
                    </div>

                    {recUrl && (
                        <div className="space-y-2 rounded-xl border border-white/10 bg-white/5 p-3">
                            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Your recording (vocals)</p>
                            <audio src={recUrl} controls className="w-full" />
                            <Button size="sm" data-focusable onClick={downloadRec} className="active:scale-[0.98]">
                                <Download className="h-4 w-4" aria-hidden="true" /> Download WAV
                            </Button>
                        </div>
                    )}
                    {recording && (
                        <p className="inline-flex items-center gap-2 text-xs font-medium text-primary">
                            <span className="h-2 w-2 animate-pulse rounded-full bg-primary" /> Recording in progress…
                        </p>
                    )}
                </section>
            </div>
        </div>
    );
};

export default YoutubeKaraokePlayer;
