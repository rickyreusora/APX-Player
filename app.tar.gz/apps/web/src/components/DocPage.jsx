import React from 'react';

const DocPage = ({ kicker, heading, intro, sections = [], lastUpdated }) => (
    <div className="mx-auto max-w-[56rem] px-4 py-16 sm:px-6">
        <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">{kicker}</p>
        <h1 className="display text-5xl sm:text-6xl">{heading}</h1>
        {intro && <p className="mt-5 text-base leading-relaxed text-foreground/80">{intro}</p>}
        {lastUpdated && (
            <p className="mt-3 text-xs text-muted-foreground">Last updated: {lastUpdated}</p>
        )}
        <div className="mt-12 space-y-10">
            {sections.map((s) => (
                <section key={s.title}>
                    <h2 className="text-lg font-semibold">{s.title}</h2>
                    {s.body && s.body.map((p, i) => (
                        <p key={i} className="mt-3 text-sm leading-relaxed text-muted-foreground">
                            {p}
                        </p>
                    ))}
                    {s.list && (
                        <ul className="mt-3 space-y-2">
                            {s.list.map((li, i) => (
                                <li key={i} className="flex gap-2.5 text-sm leading-relaxed text-muted-foreground">
                                    <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-primary" aria-hidden="true" />
                                    <span>{li}</span>
                                </li>
                            ))}
                        </ul>
                    )}
                </section>
            ))}
        </div>
    </div>
);

export default DocPage;
