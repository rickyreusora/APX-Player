import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const ProtectedRoute = ({ children, redirectTo = '/login' }) => {
    const { isAuthed } = useAuth();
    const location = useLocation();

    if (!isAuthed) {
        const returnTo = location.pathname + location.search;
        return <Navigate to={`${redirectTo}?return_to=${encodeURIComponent(returnTo)}`} replace />;
    }

    return children;
}

export default ProtectedRoute;

export { ProtectedRoute };
