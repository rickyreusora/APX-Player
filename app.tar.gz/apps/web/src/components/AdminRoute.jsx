import React, { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

const AdminRoute = ({ children }) => {
    const { isAuthed, isAdmin } = useAuth();

    useEffect(() => {
        if (isAuthed && !isAdmin) {
            toast.error('Admin access required. Only administrators can view the admin dashboard.');
        }
    }, [isAuthed, isAdmin]);

    if (!isAuthed) return <Navigate to="/login" replace />;
    if (!isAdmin) return <Navigate to="/dashboard" replace />;

    return children;
};

export default AdminRoute;
