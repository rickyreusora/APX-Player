import React from 'react';
import { Link } from 'react-router-dom';
import { Play, Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDuration } from '@/lib/catalog';

const TitleCard = ({ title, progressPercent = null, className, premium = false }) => {
    if (!title) return null;
    const watchTo = premium ? `/watch/${title.slug}?premium=1` : `/watch/${title.slug}`;
    return (
        <article className={cn('group relative', className)}>
            <Link
                to={watchTo}
                className="focus-glow block overflow-hidden rounded-2xl border border-white/8 bg-card transition-all duration-300 will-change-transform hover:-translate-y-1.5 hover:border-primary/40 hover:shadow-[0_18px_40px_-12px_hsl(187_95%_55%/0.35)]"
            >
                <div className="relative aspect-[2/3] overflow-hidden bg-secondary">
                    {title.poster ? (
                        <img
                            src={title.poster}
                            alt={`Poster artwork for ${title.title}`}
                            loading="lazy"
                            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.06]"
                        />
                    ) : (
                        <div className="grid h-full w-full place-items-center text-xs text-muted-foreground">No artwork</div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/10 to-transparent opacity-85 transition-opacity group-hover:opacity-95" />
                    <span className="absolute left-2.5 top-2.5 rounded-full bg-black/60 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.15em] text-primary backdrop-blur">
                        {title.kind === 'series' ? 'Series' : 'Movie'}
                    </span>
                    <span className="absolute right-2.5 top-2.5 grid h-10 w-10 translate-y-1 place-items-center rounded-full grad-ax opacity-0 shadow-[0_0_18px_hsl(187_95%_55%/0.5)] transition-all duration-200 group-hover:translate-y-0 group-hover:opacity-100">
                        <Play className="h-4 w-4 fill-current text-primary-foreground" aria-hidden="true" />
                    </span>
                    <div className="absolute inset-x-0 bottom-0 p-3">
                        <h3 className="line-clamp-2 text-sm font-semibold leading-snug">{title.title}</h3>
                        <p className="mt-1 flex items-center gap-2 text-[11px] text-muted-foreground">
                            <span>{title.year || '—'}</span>
                            <span aria-hidden="true">·</span>
                            <span>{formatDuration(title.duration_minutes)}</span>
                            {!!title.rating && (
                                <>
                                    <span aria-hidden="true">·</span>
                                    <span className="inline-flex items-center gap-0.5">
                                        <Star className="h-3 w-3 fill-primary text-primary" aria-hidden="true" />
                                        {title.rating}
                                    </span>
                                </>
                            )}
                        </p>
                    </div>
                    {progressPercent !== null && (
                        <div className="absolute inset-x-0 bottom-0 h-1 bg-white/15">
                            <div className="h-full grad-ax" style={{ width: `${Math.min(100, progressPercent)}%` }} />
                        </div>
                    )}
                </div>
            </Link>
        </article>
    );
};

export default TitleCard;
