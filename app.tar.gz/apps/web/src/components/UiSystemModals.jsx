import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    ArrowRight,
    CheckCircle2,
    Keyboard,
    Loader2,
    Volume2,
} from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * UiSystemModals — renders the standalone startup modal driven by UiSystem.
 * It handles Enter / Space to confirm and Arrow keys to move between actions,
 * and auto-focuses the primary button after appearing.
 */
const UiSystemModals = ({ uiSystem, state, onEnter }) => {
    const { modal, bootStatus } = state;
    const primaryRef = useRef(null);
    const rootRef = useRef(null);

    // Auto-focus the primary button whenever a modal appears.
    useEffect(() => {
        if (!modal) return undefined;
        const t = setTimeout(() => {
            primaryRef.current?.focus();
        }, 60);
        return () => clearTimeout(t);
    }, [modal]);

    // Keyboard interaction: Enter/Space confirm, Arrows move between actions.
    useEffect(() => {
        if (!modal) return undefined;
        const onKey = (e) => {
            const root = rootRef.current;
            if (!root) return;
            const focusables = Array.from(
                root.querySelectorAll('button:not([disabled]), a[href]'),
            ).filter((el) => el.offsetParent !== null);
            if (!focusables.length) return;
            const idx = focusables.indexOf(document.activeElement);
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                if (document.activeElement && document.activeElement.click) {
                    document.activeElement.click();
                } else {
                    focusables[0].click();
                }
                return;
            }
            if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
                e.preventDefault();
                focusables[(idx + 1) % focusables.length].focus();
            } else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
                e.preventDefault();
                focusables[(idx - 1 + focusables.length) % focusables.length].focus();
            }
        };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [modal]);

    const launch = () => {
        uiSystem.dismissModal();
        if (onEnter) onEnter();
    };

    return (
        <AnimatePresence>
            {modal === 'system-ready' && (
                <motion.div
                    key="ready-overlay"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.25 }}
                    className="fixed inset-0 z-[90] flex flex-col items-center justify-center overflow-hidden bg-black/85 p-4 backdrop-blur-md"
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="apx-ready-title"
                >
                    {/* ambient glow */}
                    <div className="pointer-events-none absolute left-1/2 top-1/2 h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-500/20 blur-3xl" aria-hidden="true" />

                    <motion.div
                        ref={rootRef}
                        initial={{ scale: 0.92, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.96, opacity: 0 }}
                        transition={{ duration: 0.35, ease: 'easeOut' }}
                        className="relative z-10 w-full max-w-md rounded-2xl border border-cyan-400/30 bg-[#0a1418]/95 p-8 text-center shadow-[0_0_60px_rgba(34,211,238,0.15)]"
                    >
                        <motion.div
                            initial={{ scale: 0.6, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            transition={{ duration: 0.4, delay: 0.1, ease: 'easeOut' }}
                            className="mx-auto grid h-20 w-20 place-items-center rounded-full border border-emerald-400/40 bg-emerald-500/15 text-emerald-300"
                        >
                            <CheckCircle2 className="h-10 w-10" aria-hidden="true" />
                        </motion.div>

                        <p className="mt-6 text-[11px] font-bold uppercase tracking-[0.4em] text-cyan-400/80">
                            ApX Karaoke
                        </p>
                        <h2 id="apx-ready-title" className="display mt-2 text-4xl leading-none text-white sm:text-5xl">
                            SYSTEM READY
                        </h2>

                        <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-[11px]">
                            <span className="inline-flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 font-semibold text-emerald-400">
                                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                                Catalogue online
                            </span>
                            <span className="inline-flex items-center gap-1 rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1 font-semibold text-cyan-300">
                                <Volume2 className="h-3 w-3" /> Audio engine
                            </span>
                            <span className="inline-flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-3 py-1 font-semibold text-amber-300">
                                <Keyboard className="h-3 w-3" /> Standalone
                            </span>
                        </div>

                        <button
                            ref={primaryRef}
                            type="button"
                            data-focusable
                            onClick={launch}
                            className="mt-8 inline-flex h-14 w-full max-w-xs items-center justify-center gap-3 rounded-full bg-cyan-400 px-8 text-lg font-bold text-black transition-transform hover:bg-cyan-300 active:scale-[0.98]"
                        >
                            USE KARAOKE NOW
                            <ArrowRight className="h-5 w-5" aria-hidden="true" />
                        </button>

                        <p className="mt-4 text-[11px] text-zinc-600">
                            Press <span className="font-semibold text-zinc-400">Enter</span> or tap to begin.
                        </p>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

/** Small inline boot badge for the launch gate, driven by UiSystem state. */
export const BootBadge = ({ state }) => {
    const { bootStatus, bootError } = state;
    const label =
        bootStatus === 'READY'
            ? 'Engine Ready · Karaoke catalogue online'
            : bootStatus === 'LOADING DB'
              ? 'Loading song database…'
              : 'Boot · Initializing engine';
    const tone = bootStatus === 'READY' ? 'emerald' : bootError ? 'amber' : 'cyan';
    return (
        <div
            className={cn(
                'mt-5 inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium',
                tone === 'emerald' && 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400',
                tone === 'cyan' && 'border-cyan-400/30 bg-cyan-400/10 text-cyan-300',
                tone === 'amber' && 'border-amber-500/30 bg-amber-500/10 text-amber-400',
            )}
        >
            {bootStatus !== 'READY' ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
            ) : (
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-current" />
            )}
            {label}
        </div>
    );
};

export default UiSystemModals;
