import React, { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { Crown, Download, Menu, Search, Shield, User, X, ChevronDown, Wallet, LogOut, Mic2, ListMusic, Apple, Monitor, PlusSquare } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { getCredits } from '@/lib/credits';
import { cn } from '@/lib/utils';

const isIos = () => typeof navigator !== 'undefined' && /iphone|ipad|ipod/i.test(navigator.userAgent || '');
const isAndroid = () => typeof navigator !== 'undefined' && /android/i.test(navigator.userAgent || '');
const isStandalone = () =>
    typeof window !== 'undefined' &&
    (window.matchMedia('(display-mode: standalone)').matches ||
        window.matchMedia('(display-mode: fullscreen)').matches ||
        window.navigator.standalone === true);

const openInstall = () => window.dispatchEvent(new CustomEvent('apx-open-install'));

const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/browse', label: 'Browse' },
    { to: '/browse?kind=movie', label: 'Movies' },
    { to: '/browse?kind=series', label: 'Series' },
    { to: '/livetv', label: 'Live TV' },
    { to: '/karaoke-library', label: 'Karaoke' },
    { to: '/pro-reels', label: 'Pro Reels' },
    { to: '/downloader', label: 'Downloader' },
];

export function Header() {
    const { isAuthed, isAdmin, isPremium, user, logout } = useAuth();
    const [open, setOpen] = useState(false);
    const [menu, setMenu] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();
    const [q, setQ] = useState('');
    const menuRef = useRef(null);
    const credits = getCredits(user);

    const onSearch = (e) => {
        e.preventDefault();
        navigate(`/browse?q=${encodeURIComponent(q)}`);
        setOpen(false);
    };

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    useEffect(() => {
        const onClick = (e) => {
            if (menuRef.current && !menuRef.current.contains(e.target)) setMenu(false);
        };
        document.addEventListener('mousedown', onClick);
        return () => document.removeEventListener('mousedown', onClick);
    }, []);

    return (
        <header className="sticky top-0 z-30 border-b border-white/5 bg-background/70 backdrop-blur-xl">
            <div className="mx-auto flex h-16 max-w-[90rem] items-center gap-3 px-4 sm:gap-4 sm:px-6">
                <Link to="/" className="flex items-center gap-2.5 focus-glow rounded-xl" aria-label="ApX Player home">
                    <span className="grid h-9 w-9 place-items-center rounded-xl grad-ax shadow-[0_0_18px_hsl(187_95%_55%/0.45)]">
                        <Mic2 className="h-5 w-5 text-primary-foreground" strokeWidth={2.4} aria-hidden="true" />
                    </span>
                    <span className="display text-2xl leading-none tracking-wide">
                        <span className="text-grad">APX</span> <span className="text-foreground">PLAYER</span>
                    </span>
                </Link>

                <nav className="ml-3 hidden items-center gap-1 md:flex" aria-label="Primary">
                    {navLinks.map((l) => {
                        const active = location.pathname === l.to.split('?')[0] &&
                            location.search === (l.to.split('?')[1] ? `?${l.to.split('?')[1]}` : '');
                        return (
                            <NavLink
                                key={l.to}
                                to={l.to}
                                className={cn(
                                    'focus-glow rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground',
                                    active && 'text-foreground',
                                )}
                            >
                                {l.label}
                            </NavLink>
                        );
                    })}
                </nav>

                <form onSubmit={onSearch} className="ml-auto hidden items-center lg:flex" role="search">
                    <label htmlFor="header-search" className="sr-only">
                        Search titles
                    </label>
                    <div className="group relative">
                        <Search
                            className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary"
                            aria-hidden="true"
                        />
                        <input
                            id="header-search"
                            value={q}
                            onChange={(e) => setQ(e.target.value)}
                            placeholder="Search songs, movies, shows…"
                            className="focus-glow h-10 w-64 rounded-full border border-white/10 bg-white/5 pl-10 pr-4 text-sm placeholder:text-muted-foreground transition-colors hover:border-white/20"
                        />
                    </div>
                </form>

                <div className="ml-auto flex items-center gap-2 lg:ml-2">
                    {isStandalone() ? null : isIos() ? (
                        <button
                            type="button"
                            onClick={openInstall}
                            aria-label="Install ApX Player on iPhone"
                            title="Install ApX Player on iPhone"
                            className="focus-glow inline-flex min-h-12 items-center gap-2 rounded-full grad-ax px-3 text-xs font-semibold text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.35)] transition-transform hover:scale-[1.03] active:scale-[0.98] sm:px-4 sm:text-sm"
                        >
                            <Apple className="h-4 w-4 shrink-0" aria-hidden="true" />
                            <span className="sm:hidden">Install</span>
                            <span className="hidden sm:inline">Install App</span>
                        </button>
                    ) : (
                        <>
                            <button
                                type="button"
                                onClick={openInstall}
                                aria-label="Install ApX Player"
                                title="Install ApX Player on this device"
                                className="focus-glow hidden min-h-12 items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 text-xs font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary sm:inline-flex sm:px-4 sm:text-sm"
                            >
                                <PlusSquare className="h-4 w-4 shrink-0" aria-hidden="true" />
                                <span>Install App</span>
                            </button>
                            <a
                                href="https://maruyatvph.com/apx/ApX.apk"
                                target="_blank"
                                rel="noopener noreferrer"
                                aria-label="Download APX Player APK"
                                title="Download APX Player for Android"
                                className="focus-glow inline-flex min-h-12 items-center gap-2 rounded-full grad-ax px-3 text-xs font-semibold text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.35)] transition-transform hover:scale-[1.03] active:scale-[0.98] sm:px-4 sm:text-sm"
                            >
                                <Download className="h-4 w-4 shrink-0" aria-hidden="true" />
                                <span className="sm:hidden">Get App</span>
                                <span className="hidden sm:inline">Download APK</span>
                            </a>
                        </>
                    )}
                    {isAuthed && (
                        <Link
                            to="/karaoke-library"
                            className="focus-glow hidden h-10 items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 text-sm font-medium text-muted-foreground transition-colors hover:border-primary/50 hover:text-primary sm:flex"
                            title="Karaoke queue"
                        >
                            <ListMusic className="h-4 w-4" aria-hidden="true" />
                            Queue
                        </Link>
                    )}
                    {isAdmin && (
                        <Link
                            to="/admin"
                            className="focus-glow hidden items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-3 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary/20 sm:flex"
                        >
                            <Shield className="h-4 w-4" aria-hidden="true" /> Admin
                        </Link>
                    )}
                    {isAuthed ? (
                        <div className="relative" ref={menuRef}>
                            <button
                                type="button"
                                onClick={() => setMenu((v) => !v)}
                                className="focus-glow flex h-10 items-center gap-2 rounded-full border border-white/10 bg-white/5 py-1 pl-1 pr-3 transition-colors hover:border-white/20"
                                aria-expanded={menu}
                                aria-label="Account menu"
                            >
                                <span className="grid h-8 w-8 place-items-center rounded-full grad-ax text-xs font-bold text-primary-foreground">
                                    {(user?.name || user?.email || 'U').charAt(0).toUpperCase()}
                                </span>
                                <span className="hidden max-w-[8rem] truncate text-sm font-medium sm:block">
                                    {user?.name || 'Account'}
                                </span>
                                <ChevronDown className={cn('h-4 w-4 text-muted-foreground transition-transform', menu && 'rotate-180')} aria-hidden="true" />
                            </button>
                            {menu && (
                                <div
                                    className="glass-strong absolute right-0 top-12 w-64 overflow-hidden rounded-2xl p-2 shadow-2xl"
                                    role="menu"
                                >
                                    <div className="flex items-center gap-3 rounded-xl px-3 py-3">
                                        <span className="grid h-10 w-10 place-items-center rounded-full grad-ax text-sm font-bold text-primary-foreground">
                                            {(user?.name || user?.email || 'U').charAt(0).toUpperCase()}
                                        </span>
                                        <div className="min-w-0">
                                            <p className="truncate text-sm font-semibold">{user?.name || 'Account'}</p>
                                            <p className="truncate text-xs text-muted-foreground">{user?.email}</p>
                                        </div>
                                    </div>
                                    <div className="my-1 flex items-center justify-between rounded-xl bg-white/5 px-3 py-2.5">
                                        <span className="inline-flex items-center gap-2 text-xs text-muted-foreground">
                                            <Wallet className="h-4 w-4 text-primary" aria-hidden="true" /> Credits
                                        </span>
                                        <span className="text-sm font-bold text-grad">₱{credits}</span>
                                    </div>
                                    {isPremium && (
                                        <div className="my-1 flex items-center justify-between rounded-xl bg-primary/10 px-3 py-2.5">
                                            <span className="inline-flex items-center gap-2 text-xs text-muted-foreground">
                                                <Crown className="h-4 w-4 text-primary" aria-hidden="true" /> Premium
                                            </span>
                                            <span className="text-xs font-bold text-primary">Active</span>
                                        </div>
                                    )}
                                    <Link to="/dashboard" onClick={() => setMenu(false)} className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm text-foreground transition-colors hover:bg-white/5" role="menuitem">
                                        <User className="h-4 w-4 text-muted-foreground" aria-hidden="true" /> My account
                                    </Link>
                                    {isAdmin && (
                                        <Link to="/admin" onClick={() => setMenu(false)} className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm text-foreground transition-colors hover:bg-white/5 sm:hidden" role="menuitem">
                                            <Shield className="h-4 w-4 text-muted-foreground" aria-hidden="true" /> Admin console
                                        </Link>
                                    )}
                                    <button type="button" onClick={handleLogout} className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm text-foreground transition-colors hover:bg-white/5" role="menuitem">
                                        <LogOut className="h-4 w-4 text-muted-foreground" aria-hidden="true" /> Sign out
                                    </button>
                                </div>
                            )}
                        </div>
                    ) : (
                        <Link
                            to="/login"
                            className="focus-glow hidden rounded-full grad-ax px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.35)] transition-transform hover:scale-[1.03] active:scale-[0.98] sm:block"
                        >
                            Sign In
                        </Link>
                    )}
                    <button
                        type="button"
                        className="focus-glow grid h-11 w-11 place-items-center rounded-xl border border-white/10 bg-white/5 md:hidden"
                        onClick={() => setOpen((v) => !v)}
                        aria-expanded={open}
                        aria-label={open ? 'Close menu' : 'Open menu'}
                    >
                        {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                    </button>
                </div>
            </div>

            {open && (
                <div className="border-t border-white/5 bg-background/95 px-4 pb-5 pt-3 backdrop-blur-xl md:hidden">
                    <form onSubmit={onSearch} className="mb-3" role="search">
                        <label htmlFor="mobile-search" className="sr-only">
                            Search titles
                        </label>
                        <div className="relative">
                            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                            <input
                                id="mobile-search"
                                value={q}
                                onChange={(e) => setQ(e.target.value)}
                                placeholder="Search songs, movies, shows…"
                                className="focus-glow h-12 w-full rounded-full border border-white/10 bg-white/5 pl-10 pr-4 text-sm"
                            />
                        </div>
                    </form>
                    <nav className="flex flex-col" aria-label="Mobile">
                        {navLinks.map((l) => (
                            <Link
                                key={l.to}
                                to={l.to}
                                onClick={() => setOpen(false)}
                                className="border-b border-white/5 py-3.5 text-base font-medium"
                            >
                                {l.label}
                            </Link>
                        ))}
                        {isAuthed ? (
                            <>
                                <Link to="/dashboard" onClick={() => setOpen(false)} className="border-b border-white/5 py-3.5 text-base font-medium">
                                    My account
                                </Link>
                                {isAdmin && (
                                    <Link to="/admin" onClick={() => setOpen(false)} className="border-b border-white/5 py-3.5 text-base font-medium text-primary">
                                        Admin
                                    </Link>
                                )}
                                <button type="button" onClick={handleLogout} className="py-3.5 text-left text-base font-medium">
                                    Sign out
                                </button>
                            </>
                        ) : (
                            <Link
                                to="/login"
                                onClick={() => setOpen(false)}
                                className="mt-3 rounded-full grad-ax py-3.5 text-center text-base font-semibold text-primary-foreground"
                            >
                                Sign In
                            </Link>
                        )}
                        {!isStandalone() && (
                            <button
                                type="button"
                                onClick={() => {
                                    setOpen(false);
                                    openInstall();
                                }}
                                className="mt-3 flex items-center justify-center gap-2 rounded-full border border-white/10 bg-white/5 py-3.5 text-base font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary"
                            >
                                {isIos() ? <Apple className="h-5 w-5" aria-hidden="true" /> : <Download className="h-5 w-5" aria-hidden="true" />}
                                {isIos() ? 'Install on iPhone' : 'Install App'}
                            </button>
                        )}
                    </nav>
                </div>
            )}
        </header>
    );
}

export function Footer() {
    const year = new Date().getFullYear();
    return (
        <footer className="mt-24 border-t border-white/5 bg-background">
            <div className="mx-auto max-w-[90rem] px-4 py-14 sm:px-6">
                <div className="grid gap-10 md:grid-cols-12">
                    {/* Brand */}
                    <div className="md:col-span-4">
                        <span className="display text-2xl">
                            <span className="text-grad">ApX</span> <span className="text-foreground">PLAYER</span>
                        </span>
                        <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
                            An all-in-one streaming &amp; karaoke platform by MaruyaTVPH. Movies, series, Live TV,
                            Pro Reels, and a full karaoke stage — built for web, mobile, desktop, and Android TV,
                            in one immersive app.
                        </p>
                        <div className="mt-4 h-1.5 w-32 rounded-full grad-ax opacity-80" aria-hidden="true" />
                        <button
                            type="button"
                            onClick={openInstall}
                            className="focus-glow mt-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary"
                        >
                            {isIos() ? <Apple className="h-4 w-4" aria-hidden="true" /> : isAndroid() ? <Download className="h-4 w-4" aria-hidden="true" /> : <Monitor className="h-4 w-4" aria-hidden="true" />}
                            {isIos() ? 'Install on iPhone' : isAndroid() ? 'Get the Android app' : 'Install ApX Player'}
                        </button>
                    </div>

                    {/* Link columns */}
                    <div className="md:col-span-2">
                        <h2 className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Watch</h2>
                        <ul className="space-y-2 text-sm">
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/browse">Browse all</Link></li>
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/browse?kind=movie">Movies</Link></li>
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/browse?kind=series">Series</Link></li>
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/livetv">Live TV</Link></li>
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/pro-reels">Pro Reels</Link></li>
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/downloader">Downloader</Link></li>
                        </ul>
                    </div>
                    <div className="md:col-span-2">
                        <h2 className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Sing</h2>
                        <ul className="space-y-2 text-sm">
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/karaoke-library">Karaoke Library</Link></li>
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/dashboard">My account</Link></li>
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/dns-tutorial">DNS Tutorial</Link></li>
                        </ul>
                    </div>
                    <div className="md:col-span-2">
                        <h2 className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Company</h2>
                        <ul className="space-y-2 text-sm">
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/about">About</Link></li>
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/contact">Contact</Link></li>
                        </ul>
                    </div>
                    <div className="md:col-span-2">
                        <h2 className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">Legal</h2>
                        <ul className="space-y-2 text-sm">
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/privacy">Privacy Policy</Link></li>
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/terms">Terms of Use</Link></li>
                            <li><Link className="text-muted-foreground transition-colors hover:text-primary" to="/content-rights">Content Rights / DMCA</Link></li>
                        </ul>
                    </div>
                </div>

                {/* Bottom bar */}
                <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-6 text-xs text-muted-foreground sm:flex-row">
                    <p className="text-center sm:text-left">
                        &copy; {year} ApX Player by MaruyaTVPH. All rights reserved.
                    </p>
                </div>
            </div>
        </footer>
    );
}

const Layout = ({ children, bare = false }) => (
    <div className="grain flex min-h-[100dvh] flex-col bg-background">
        <Header />
        <main className="flex-1">{children}</main>
        {!bare && <Footer />}
    </div>
);

export default Layout;
