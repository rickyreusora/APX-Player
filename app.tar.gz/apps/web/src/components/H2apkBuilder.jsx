import React, { useCallback, useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import JSZip from 'jszip';
import {
    downloadBuild,
    downloadNamed,
    fileToBase64,
    getBuildStatus,
    getH2apkStatus,
    startBuild,
    streamBuildLog,
} from '@/lib/h2apk';

const PKG_RE = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/;

const Check = ({ id, checked, onChange, label }) => (
    <label className="h2-check" htmlFor={id}>
        <span className={`h2-box${checked ? ' on' : ''}`}>
            <input id={id} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
            <svg viewBox="0 0 22 22" aria-hidden="true">
                <path fill="none" stroke="currentColor" strokeWidth="2.4" d="M4 11.5 9 16.5 18 6" />
            </svg>
        </span>
        <span>{label}</span>
    </label>
);

const H2apkBuilder = () => {
    const [configured, setConfigured] = useState(null);
    const [checking, setChecking] = useState(true);
    const [mode, setMode] = useState('html');
    const [buildMode, setBuildMode] = useState('debug');
    const [advanced, setAdvanced] = useState(false);
    const [extra, setExtra] = useState(false);
    const [ksMode, setKsMode] = useState('file');
    const [supportOpen, setSupportOpen] = useState(false);
    const [supportTab, setSupportTab] = useState('instapay');
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewUrl, setPreviewUrl] = useState('');
    const [dragOver, setDragOver] = useState(false);

    const [form, setForm] = useState({
        app_name: '',
        package_name: '',
        version: '1.0',
        html: '',
        css: '',
        js: '',
        url: '',
        theme_color: '#1C1C1E',
        pull_refresh: false,
        hide_scrollbars: true,
        transparent_nav: false,
        zoom_enabled: false,
        disable_copy_text: false,
        splash_enabled: false,
        splash_duration: 2,
        splash_color: '#000000',
        splash_animation: 'fade',
        splash_image_size: 60,
        splash_use_icon: true,
        block_ads: true,
        adguard_dns: false,
        version_code: 1,
        min_sdk: 24,
        target_sdk: 34,
        ks_pass: '',
        key_alias: '',
        key_pass: '',
        allow_cleartext: false,
    });
    const [iconData, setIconData] = useState('');
    const [splashData, setSplashData] = useState('');
    const [keystore, setKeystore] = useState('');
    const [keystoreName, setKeystoreName] = useState('');
    const [files, setFiles] = useState([]);

    const [building, setBuilding] = useState(false);
    const [phase, setPhase] = useState('idle');
    const [statusText, setStatusText] = useState('');
    const [logs, setLogs] = useState([]);
    const [artifacts, setArtifacts] = useState([]);
    const [buildId, setBuildId] = useState(null);
    const abortRef = useRef(null);
    const logRef = useRef(null);

    const update = (patch) => setForm((f) => ({ ...f, ...patch }));

    const checkStatus = useCallback(async () => {
        setChecking(true);
        try {
            setConfigured(await getH2apkStatus());
        } catch (err) {
            setConfigured({ configured: false, error: err?.message });
        } finally {
            setChecking(false);
        }
    }, []);

    useEffect(() => {
        checkStatus();
        return () => abortRef.current?.();
    }, [checkStatus]);

    useEffect(() => {
        if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
    }, [logs]);

    const readIcon = async (file) => {
        if (!file) return;
        if (!file.type.includes('png')) {
            toast.error('Icon must be a PNG file.');
            return;
        }
        const data = await fileToBase64(file);
        setIconData(String(data).split(',')[1] || '');
    };

    const readKeystoreFile = async (file) => {
        if (!file) return;
        const buf = await file.arrayBuffer();
        const bytes = new Uint8Array(buf);
        let binary = '';
        for (let i = 0; i < bytes.length; i += 1) binary += String.fromCharCode(bytes[i]);
        setKeystore(btoa(binary));
        setKeystoreName(file.name);
    };

    const ingestFiles = async (list) => {
        const incoming = Array.from(list || []);
        const next = [];
        for (const file of incoming) {
            if (file.name.toLowerCase().endsWith('.zip') || file.type === 'application/zip') {
                const zip = await JSZip.loadAsync(file);
                const entries = Object.values(zip.files).filter((f) => !f.dir);
                for (const entry of entries) {
                    const lower = entry.name.toLowerCase();
                    const isText = /\.(html?|css|js|mjs|json|txt|xml|csv|svg)$/.test(lower);
                    if (isText) {
                        next.push({ name: entry.name, text: await entry.async('string'), binary: '' });
                    } else {
                        const b64 = await entry.async('base64');
                        next.push({ name: entry.name, text: '', binary: b64 });
                    }
                }
            } else if (file.type.startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp|avif|ico)$/i.test(file.name)) {
                const data = await fileToBase64(file);
                next.push({ name: file.name, text: '', binary: String(data).split(',')[1] || '' });
            } else {
                next.push({ name: file.name, text: await file.text(), binary: '' });
            }
        }
        setFiles((prev) => {
            const map = new Map(prev.map((f) => [f.name, f]));
            next.forEach((f) => map.set(f.name, f));
            return Array.from(map.values());
        });
    };

    const openPreview = () => {
        if (!form.html.trim()) return;
        const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${form.css || ''}</style></head><body>${form.html}<script>${form.js || ''}<\/script></body></html>`;
        const url = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
        setPreviewUrl(url);
        setPreviewOpen(true);
    };

    const closePreview = () => {
        setPreviewOpen(false);
        if (previewUrl) URL.revokeObjectURL(previewUrl);
        setPreviewUrl('');
    };

    const finishFromStatus = async (id) => {
        try {
            const info = await getBuildStatus(id);
            if (info.success && (info.artifacts?.length || info.apk_name)) {
                setPhase('done');
                setStatusText('Build complete!');
                setArtifacts(info.artifacts?.length ? info.artifacts : [{ name: info.apk_name, kind: 'apk' }]);
                setBuilding(false);
                return;
            }
            if (info.error) {
                setPhase('failed');
                setStatusText(info.error);
                setBuilding(false);
            }
        } catch {
            setPhase('failed');
            setStatusText('Connection lost');
            setBuilding(false);
        }
    };

    const handleBuild = async () => {
        const pkg = form.package_name.trim() || 'com.h2a.app';
        if (!PKG_RE.test(pkg)) {
            setPhase('failed');
            setStatusText('Invalid package name — must have at least one dot (e.g. com.example.app)');
            return;
        }
        if (mode === 'html' && !form.html.trim()) {
            setPhase('failed');
            setStatusText('HTML content is required.');
            return;
        }
        if (mode === 'url' && !form.url.trim()) {
            setPhase('failed');
            setStatusText('A website URL is required.');
            return;
        }
        if (mode === 'upload' && !files.some((f) => f.name.toLowerCase().endsWith('index.html'))) {
            setPhase('failed');
            setStatusText('Missing index.html');
            return;
        }
        if (buildMode === 'release') {
            if (Number(form.version_code) < 1) {
                setPhase('failed');
                setStatusText('Version Code must be a positive integer');
                return;
            }
            if (!keystore) {
                setPhase('failed');
                setStatusText('Keystore file or base64 is required for release');
                return;
            }
            if (!form.ks_pass || !form.key_alias) {
                setPhase('failed');
                setStatusText('Keystore password and key alias are required');
                return;
            }
        }

        setBuilding(true);
        setPhase('building');
        setStatusText('Building APK...');
        setLogs([]);
        setArtifacts([]);
        setBuildId(null);

        const body = {
            app_name: form.app_name.trim() || 'MyApp',
            package_name: pkg,
            icon: iconData,
            pull_refresh: form.pull_refresh,
            theme_color: form.theme_color,
            transparent_nav: form.transparent_nav,
            adguard_dns: form.adguard_dns,
            zoom_enabled: form.zoom_enabled,
            disable_copy_text: form.disable_copy_text,
            hide_scrollbars: form.hide_scrollbars,
            splash_enabled: form.splash_enabled,
            splash_duration: Math.round(Number(form.splash_duration) * 1000),
            splash_color: form.splash_color,
            splash_image: splashData,
            splash_use_icon: form.splash_use_icon,
            splash_image_size: Number(form.splash_image_size),
            splash_animation: form.splash_animation,
            version: form.version || '1.0',
            build_mode: buildMode,
        };

        if (buildMode === 'release') {
            body.version_code = Number(form.version_code) || 1;
            body.min_sdk = Number(form.min_sdk) || 24;
            body.target_sdk = Number(form.target_sdk) || 34;
            body.keystore = keystore;
            body.ks_pass = form.ks_pass;
            body.key_alias = form.key_alias;
            body.key_pass = form.key_pass || form.ks_pass;
            body.allow_cleartext = form.allow_cleartext;
        }

        if (mode === 'html') {
            body.html = form.html;
            body.css = form.css;
            body.js = form.js;
        } else if (mode === 'url') {
            body.url = form.url.trim();
            body.block_ads = form.block_ads;
        } else {
            const index = files.find((f) => /(^|\/)index\.html$/i.test(f.name));
            body.html = index?.text || '';
            const assets = {};
            let flat = true;
            files.forEach((f) => {
                if (f.name.includes('/')) flat = false;
            });
            if (!flat || files.some((f) => f.binary)) {
                files.forEach((f) => {
                    if (f === index) return;
                    const key = f.name.replace(/^\.?\//, '');
                    assets[key] = f.binary || btoa(unescape(encodeURIComponent(f.text || '')));
                });
                body.asset_files = assets;
            } else {
                body.css = files.filter((f) => f.name.toLowerCase().endsWith('.css')).map((f) => f.text).join('\n');
                body.js = files.filter((f) => f.name.toLowerCase().endsWith('.js')).map((f) => f.text).join('\n');
            }
        }

        try {
            const info = await startBuild(body);
            if (!info.success || !info.build_id) {
                setBuilding(false);
                setPhase('failed');
                setStatusText(info.error || 'Build did not start.');
                return;
            }
            const id = info.build_id;
            setBuildId(id);
            abortRef.current?.();
            abortRef.current = streamBuildLog(id, {
                onLine: (line) => setLogs((prev) => [...prev, line]),
                onDone: (payload) => {
                    setBuilding(false);
                    setPhase('done');
                    setStatusText('Build complete!');
                    let parsed = null;
                    try { parsed = JSON.parse(payload); } catch { parsed = null; }
                    if (Array.isArray(parsed) && parsed.length) setArtifacts(parsed);
                    else if (payload) setArtifacts([{ name: payload, kind: 'apk', legacy: true }]);
                },
                onFailed: (msg) => {
                    setBuilding(false);
                    setPhase('failed');
                    setStatusText(msg || 'Build failed');
                },
                onError: () => finishFromStatus(id),
            });
        } catch (err) {
            setBuilding(false);
            setPhase('failed');
            setStatusText(err?.message || 'Build failed.');
        }
    };

    const saveArtifact = async (artifact) => {
        try {
            if (artifact.legacy || !artifact.name) {
                await downloadBuild(buildId, `${form.app_name || 'app'}.apk`);
            } else {
                await downloadNamed(buildId, artifact.name);
            }
        } catch (err) {
            toast.error(err?.message || 'Download failed.');
        }
    };

    return (
        <section className="h2apk mb-12">
            <div className="h2-hero">
                <h2>H2APK</h2>
                <p>Convert HTML or a website URL into an Android APK in seconds.</p>
                <p className="h2-links">
                    <a href="https://github.com/HashShin/H2APK" target="_blank" rel="noreferrer">
                        <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M10 0C4.477 0 0 4.59 0 10.253c0 4.529 2.865 8.374 6.839 9.728.5.096.682-.223.682-.494 0-.244-.009-.89-.014-1.747-2.782.62-3.369-1.37-3.369-1.37-.455-1.183-1.11-1.498-1.11-1.498-.908-.636.069-.623.069-.623 1.004.072 1.532 1.056 1.532 1.056.892 1.566 2.341 1.114 2.91.852.092-.662.35-1.114.636-1.37-2.22-.259-4.555-1.138-4.555-5.066 0-1.12.39-2.034 1.03-2.752-.103-.26-.447-1.303.098-2.717 0 0 .84-.276 2.75 1.05A9.34 9.34 0 0 1 10 4.84a9.3 9.3 0 0 1 2.504.345c1.909-1.326 2.747-1.05 2.747-1.05.547 1.414.203 2.457.1 2.717.64.718 1.028 1.632 1.028 2.752 0 3.938-2.339 4.804-4.566 5.058.359.318.678.944.678 1.903 0 1.374-.012 2.482-.012 2.82 0 .273.18.594.688.493C17.14 18.623 20 14.78 20 10.253 20 4.59 15.523 0 10 0Z" /></svg>
                        GitHub
                    </a>
                    <button type="button" onClick={() => setSupportOpen(true)}>
                        <svg width="14" height="14" viewBox="0 0 64 64" fill="currentColor" aria-hidden="true"><path d="M4 60c0 2.2 1.8 4 4 4h20V36H4v24zm32 4h20c2.2 0 4-1.8 4-4V36H36v28zM60 12h-8C52 5.4 46.6 0 40 0c-3.1 0-5.9 1.2-8 3.1C29.9 1.2 27.1 0 24 0 17.4 0 12 5.4 12 12H4c-2.2 0-4 1.8-4 4v8c0 2.2 1.8 4 4 4h24V12h-8c0-2.2 1.8-4 4-4s4 1.8 4 4h8c0-2.2 1.8-4 4-4s4 1.8 4 4h-8v16h24c2.2 0 4-1.8 4-4v-8c0-2.2-1.8-4-4-4z" /></svg>
                        Support
                    </button>
                </p>
            </div>

            {checking && <p className="h2-note">Checking builder status…</p>}

            {!checking && !configured?.configured && (
                <div className="h2-warn">
                    <p>H2APK server not configured yet</p>
                    <p>
                        This panel talks to a self-hosted H2APK server. Set <code>H2APK_URL</code> on the API server
                        (for example <code>https://h2apk.hashcode.win</code> or <code>http://localhost:8011</code>) and reload.
                    </p>
                    <button type="button" onClick={checkStatus}>Re-check status</button>
                </div>
            )}

            {!checking && configured?.configured && (
                <>
                    <div className="h2-switch">
                        <button type="button" className={buildMode === 'debug' ? 'on' : ''} onClick={() => setBuildMode('debug')}>Debug / Test</button>
                        <button type="button" className={buildMode === 'release' ? 'on' : ''} onClick={() => setBuildMode('release')}>Play Store Release</button>
                    </div>

                    <div className="h2-tabs">
                        {[
                            ['html', 'HTML'],
                            ['url', 'Website URL'],
                            ['upload', 'Upload'],
                        ].map(([id, label]) => (
                            <button key={id} type="button" className={mode === id ? 'on' : ''} onClick={() => setMode(id)}>{label}</button>
                        ))}
                    </div>

                    <div className="h2-card">
                        <div className="h2-kicker">App Details</div>
                        <div className="h2-grid">
                            <label>App Name<input value={form.app_name} placeholder="My App" onChange={(e) => update({ app_name: e.target.value })} /></label>
                            <label>Package ID<input value={form.package_name} placeholder="com.example.app" onChange={(e) => update({ package_name: e.target.value })} /></label>
                            <label className="h2-ver">Version<input value={form.version} placeholder="1.0" onChange={(e) => update({ version: e.target.value })} /></label>
                            <div className="h2-icon">
                                <span>App Icon</span>
                                <div>
                                    <div className="h2-icon-preview">{iconData ? <img src={`data:image/png;base64,${iconData}`} alt="" /> : <span>icon</span>}</div>
                                    <label className="h2-ghost">
                                        Choose PNG
                                        <input type="file" accept="image/png" hidden onChange={(e) => readIcon(e.target.files?.[0])} />
                                    </label>
                                </div>
                            </div>
                        </div>

                        {buildMode === 'release' && (
                            <div className="h2-release">
                                <div className="h2-kicker">Play Store Release Settings</div>
                                <p className="h2-note">Release builds produce a signed <b>.aab</b> for Play Console upload + a <b>-release.apk</b> for sideload testing.</p>
                                <div className="h2-row">
                                    <label>Version Code *<input type="number" min={1} value={form.version_code} onChange={(e) => update({ version_code: e.target.value })} /></label>
                                    <label>Min SDK<input type="number" min={16} value={form.min_sdk} onChange={(e) => update({ min_sdk: e.target.value })} /></label>
                                    <label>Target SDK<input type="number" min={16} value={form.target_sdk} onChange={(e) => update({ target_sdk: e.target.value })} /></label>
                                </div>
                                <label>Keystore (.jks/.keystore file or base64) *</label>
                                <div className="h2-mini">
                                    <button type="button" className={ksMode === 'file' ? 'on' : ''} onClick={() => setKsMode('file')}>File</button>
                                    <button type="button" className={ksMode === 'paste' ? 'on' : ''} onClick={() => setKsMode('paste')}>Paste base64</button>
                                </div>
                                {ksMode === 'file' ? (
                                    <label className="h2-file">
                                        {keystoreName || 'Choose .jks / .keystore'}
                                        <input type="file" accept=".jks,.keystore" hidden onChange={(e) => readKeystoreFile(e.target.files?.[0])} />
                                    </label>
                                ) : (
                                    <textarea value={keystore} placeholder="Paste base64-encoded keystore here..." onChange={(e) => setKeystore(e.target.value.trim())} />
                                )}
                                <div className="h2-row">
                                    <label>Keystore password *<input type="password" value={form.ks_pass} placeholder="required" onChange={(e) => update({ ks_pass: e.target.value })} /></label>
                                    <label>Key alias *<input value={form.key_alias} placeholder="required" onChange={(e) => update({ key_alias: e.target.value })} /></label>
                                    <label>Key password<input type="password" value={form.key_pass} placeholder="same as keystore" onChange={(e) => update({ key_pass: e.target.value })} /></label>
                                </div>
                                <Check id="allowHttp" checked={form.allow_cleartext} onChange={(v) => update({ allow_cleartext: v })} label="Allow HTTP (cleartext) — off by default for Play Store" />
                            </div>
                        )}

                        <button type="button" className="h2-plus" onClick={() => setAdvanced((v) => !v)}>{advanced ? '– Advanced' : '+ Advanced'}</button>
                        {advanced && (
                            <div className="h2-advanced">
                                <div className="h2-color">
                                    <span>Theme Color</span>
                                    <input type="color" value={form.theme_color} onChange={(e) => update({ theme_color: e.target.value })} />
                                    <input value={form.theme_color} onChange={(e) => update({ theme_color: e.target.value })} />
                                </div>
                                <Check id="pullRefresh" checked={form.pull_refresh} onChange={(v) => update({ pull_refresh: v })} label="Pull-Down Refresh" />
                                <Check id="hideScrollbars" checked={form.hide_scrollbars} onChange={(v) => update({ hide_scrollbars: v })} label="Hide scrollbars" />
                                <Check id="transparentNav" checked={form.transparent_nav} onChange={(v) => update({ transparent_nav: v })} label="Transparent navigation bar" />
                                <Check id="pinchZoom" checked={form.zoom_enabled} onChange={(v) => update({ zoom_enabled: v })} label="Pinch to zoom" />
                                <Check id="disableCopy" checked={form.disable_copy_text} onChange={(v) => update({ disable_copy_text: v })} label="Disable copy text" />
                                <Check id="splashEnabled" checked={form.splash_enabled} onChange={(v) => update({ splash_enabled: v })} label="Splash screen" />
                                {form.splash_enabled && (
                                    <div className="h2-splash">
                                        <label>Duration (s)<input type="number" min={1} max={10} step={0.5} value={form.splash_duration} onChange={(e) => update({ splash_duration: e.target.value })} /></label>
                                        <div className="h2-color">
                                            <span>Background</span>
                                            <input type="color" value={form.splash_color} onChange={(e) => update({ splash_color: e.target.value })} />
                                            <input value={form.splash_color} onChange={(e) => update({ splash_color: e.target.value })} />
                                        </div>
                                        <label>Animation
                                            <select value={form.splash_animation} onChange={(e) => update({ splash_animation: e.target.value })}>
                                                <option value="fade">Fade in</option>
                                                <option value="slide">Slide up</option>
                                                <option value="none">None</option>
                                            </select>
                                        </label>
                                        <label>Image size <b>{form.splash_image_size}%</b>
                                            <input type="range" min={0} max={100} value={form.splash_image_size} onChange={(e) => update({ splash_image_size: e.target.value })} />
                                        </label>
                                        <div className="h2-radios">
                                            <span>Image</span>
                                            <label><input type="radio" checked={form.splash_use_icon} onChange={() => update({ splash_use_icon: true })} /> App icon</label>
                                            <label><input type="radio" checked={!form.splash_use_icon} onChange={() => update({ splash_use_icon: false })} /> Custom</label>
                                        </div>
                                        {!form.splash_use_icon && (
                                            <label className="h2-file">
                                                Splash PNG
                                                <input type="file" accept="image/png" hidden onChange={async (e) => {
                                                    const file = e.target.files?.[0];
                                                    if (!file) return;
                                                    const data = await fileToBase64(file);
                                                    setSplashData(String(data).split(',')[1] || '');
                                                }} />
                                            </label>
                                        )}
                                    </div>
                                )}
                            </div>
                        )}
                    </div>

                    {mode === 'html' && (
                        <div className="h2-card">
                            <div className="h2-head">
                                <span className="h2-kicker">HTML Content</span>
                                <button type="button" className={`h2-preview${form.html.trim() ? ' on' : ''}`} onClick={openPreview}>Preview</button>
                            </div>
                            <textarea value={form.html} spellCheck={false} placeholder={'<h1>Hello World</h1>\n<p>Your HTML content here...</p>'} onChange={(e) => update({ html: e.target.value })} />
                            <button type="button" className="h2-plus" onClick={() => setExtra((v) => !v)}>{extra ? '– CSS/JS' : '+ CSS/JS'}</button>
                            {extra && (
                                <>
                                    <label>CSS (optional)<textarea className="short" value={form.css} spellCheck={false} placeholder="body { background: #111; color: #fff; }" onChange={(e) => update({ css: e.target.value })} /></label>
                                    <label>JavaScript (optional)<textarea className="short" value={form.js} spellCheck={false} placeholder="console.log('loaded');" onChange={(e) => update({ js: e.target.value })} /></label>
                                </>
                            )}
                        </div>
                    )}

                    {mode === 'url' && (
                        <div className="h2-card">
                            <div className="h2-kicker">Website URL</div>
                            <input type="url" value={form.url} placeholder="https://example.com" onChange={(e) => update({ url: e.target.value })} />
                            <Check id="blockAds" checked={form.block_ads} onChange={(v) => update({ block_ads: v })} label="Block ads & prevent app redirects" />
                            <Check id="adguardDns" checked={form.adguard_dns} onChange={(v) => update({ adguard_dns: v })} label="AdGuard DNS (blocks ads & trackers)" />
                        </div>
                    )}

                    {mode === 'upload' && (
                        <div className="h2-card">
                            <div className="h2-kicker">Upload Project Files</div>
                            <p className="h2-note">Requires <b>index.html</b>. Upload individual files or a <b>.zip</b> with your project structure.</p>
                            <label
                                className={`h2-drop${dragOver ? ' over' : ''}`}
                                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                                onDragLeave={() => setDragOver(false)}
                                onDrop={(e) => { e.preventDefault(); setDragOver(false); ingestFiles(e.dataTransfer.files); }}
                            >
                                <span>+</span>
                                <span>Select files or drop here</span>
                                <span>.html .css .js .json .txt images .zip</span>
                                <input type="file" multiple hidden onChange={(e) => ingestFiles(e.target.files)} />
                            </label>
                            {files.length > 0 && (
                                <ul className="h2-files">
                                    {files.map((f) => (
                                        <li key={f.name}>
                                            <span>{f.name}</span>
                                            <button type="button" onClick={() => setFiles((prev) => prev.filter((x) => x.name !== f.name))} aria-label={`Remove ${f.name}`}>×</button>
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    )}

                    <button type="button" className="h2-build" disabled={building} onClick={handleBuild}>
                        {building ? 'Building…' : 'Build APK'}
                    </button>

                    {phase !== 'idle' && (
                        <div className={`h2-status ${phase}`}>
                            <span className="dot" />
                            {statusText}
                        </div>
                    )}

                    {(logs.length > 0 || building) && (
                        <>
                            <div className="h2-term-bar"><span /><span /><span /></div>
                            <pre ref={logRef} className="h2-log">{logs.join('\n') || ' '}</pre>
                        </>
                    )}

                    {phase === 'done' && artifacts.length > 0 && (
                        <div className="h2-dl">
                            {artifacts.map((a) => {
                                const isAab = a.kind === 'aab';
                                return (
                                    <button key={a.name} type="button" onClick={() => saveArtifact(a)}>
                                        {isAab ? 'Upload to Play Console' : 'Test install (APK)'} — {a.name}
                                        <em className={isAab ? 'aab' : 'apk'}>{isAab ? 'AAB' : 'APK'}</em>
                                    </button>
                                );
                            })}
                        </div>
                    )}
                </>
            )}

            {supportOpen && (
                <div className="h2-overlay" role="dialog" aria-modal="true" aria-label="Support H2APK" onClick={(e) => { if (e.target === e.currentTarget) setSupportOpen(false); }}>
                    <div className="h2-donate">
                        <div className="h2-donate-hero">
                            <button type="button" className="h2-x" onClick={() => setSupportOpen(false)} aria-label="Close">×</button>
                            <div className="h2-brand">Buy HASH a Beer</div>
                            <div className="h2-sub">Fuel more late-night builds</div>
                        </div>
                        <div className="h2-donate-body">
                            <p>If this builder helped you out, buy HASH a beer — no pressure.</p>
                            <div className="h2-dtabs">
                                {[['instapay', 'InstaPay'], ['binance', 'Binance'], ['github', 'GitHub']].map(([id, label]) => (
                                    <button key={id} type="button" className={supportTab === id ? 'on' : ''} onClick={() => setSupportTab(id)}>{label}</button>
                                ))}
                            </div>
                            {supportTab === 'instapay' && (
                                <div className="h2-pay">
                                    <img src="https://h2apk.hashcode.win/instapay.png" alt="GCash QR" />
                                    <div>
                                        <strong>Instapay</strong>
                                        <a href="https://h2apk.hashcode.win/instapay.png" download>Download QR</a>
                                        <p>Download the QR image first, then open your e-wallet app to scan it.</p>
                                    </div>
                                </div>
                            )}
                            {supportTab === 'binance' && (
                                <div className="h2-pay">
                                    <img src="https://h2apk.hashcode.win/binance.png" alt="Binance QR" />
                                    <div>
                                        <strong>Binance Pay</strong>
                                        <p>Pay ID: <b>60362410</b></p>
                                        <a href="https://h2apk.hashcode.win/binance.png" download>Download QR</a>
                                        <p>Scan the QR or search the Pay ID in the Binance app.</p>
                                    </div>
                                </div>
                            )}
                            {supportTab === 'github' && (
                                <div className="h2-pay center">
                                    <strong>GitHub Sponsors</strong>
                                    <p>Support this project directly through GitHub Sponsors.</p>
                                    <a href="https://github.com/sponsors/HashShin" target="_blank" rel="noreferrer">Sponsor on GitHub</a>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {previewOpen && (
                <div className="h2-preview-pane" id="h2-preview-pane">
                    <div className="h2-preview-bar">
                        <span>Preview</span>
                        <div>
                            <button type="button" onClick={() => document.getElementById('h2-preview-pane')?.requestFullscreen?.()} aria-label="Fullscreen">⛶</button>
                            <button type="button" onClick={closePreview} aria-label="Close">✕</button>
                        </div>
                    </div>
                    <iframe title="HTML preview" src={previewUrl} />
                </div>
            )}
        </section>
    );
};

export default H2apkBuilder;
