import React, { useEffect, useRef, useState } from 'react';
import { Gift, X, ExternalLink } from 'lucide-react';

/**
 * Promotional Hostinger offer.
 *
 * Pops up automatically every 30 minutes while the visitor is on the site,
 * showing a blinking "Claim" button that links to the Hostinger referral URL.
 * Easy to dismiss: the X button hides it until the next 30-minute cycle.
 *
 * Timing is driven by a real timestamp so it stays reliable across tab
 * switches, sleep/wake, and visibility changes — it does not depend on a
 * naive setInterval that drifts when the browser throttles background tabs.
 */

const REFERRAL_URL = 'https://hostinger.com/reach/referrals?REFERRALCODE=DDLGAIDDAM91';
const INTERVAL_MS = 30 * 60 * 1000; // 30 minutes
const STORAGE_KEY = 'apx-promo-offer';

const readState = () => {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return null;
        const parsed = JSON.parse(raw);
        return typeof parsed === 'object' && parsed ? parsed : null;
    } catch {
        return null;
    }
};

const writeState = (data) => {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
        /* ignore */
    }
};

const PromotionalOffer = () => {
    const [visible, setVisible] = useState(false);
    const [armed, setArmed] = useState(false);
    const timerRef = useRef(null);

    // Arm the first popup 8 seconds after load so it doesn't fight the
    // broadcast dialog or the initial page paint. Subsequent popups follow
    // the 30-minute cadence.
    useEffect(() => {
        const existing = readState();
        const now = Date.now();

        if (existing && existing.dismissedAt) {
            const elapsed = now - existing.dismissedAt;
            if (elapsed >= INTERVAL_MS) {
                // Enough time has passed since last dismiss — show soon.
                const t = setTimeout(() => setVisible(true), 6000);
                return () => clearTimeout(t);
            }
            // Schedule the next popup for the remainder of the 30-min window.
            const remaining = INTERVAL_MS - elapsed;
            timerRef.current = setTimeout(() => setVisible(true), Math.min(remaining, INTERVAL_MS));
            return () => {
                if (timerRef.current) clearTimeout(timerRef.current);
            };
        }

        // No prior dismissal — first visit. Show after a short delay.
        const t = setTimeout(() => setVisible(true), 8000);
        return () => clearTimeout(t);
    }, []);

    // Schedule the next popup whenever the current one is dismissed.
    useEffect(() => {
        if (visible || armed) return;
        setArmed(true);
        timerRef.current = setTimeout(() => {
            setVisible(true);
            setArmed(false);
        }, INTERVAL_MS);
        return () => {
            if (timerRef.current) clearTimeout(timerRef.current);
        };
    }, [visible, armed]);

    // Re-check on tab focus: if 30+ minutes passed while away, show now.
    useEffect(() => {
        const onFocus = () => {
            const existing = readState();
            if (!existing || !existing.dismissedAt) return;
            if (Date.now() - existing.dismissedAt >= INTERVAL_MS) {
                setVisible(true);
            }
        };
        window.addEventListener('focus', onFocus);
        return () => window.removeEventListener('focus', onFocus);
    }, []);

    const handleDismiss = () => {
        setVisible(false);
        writeState({ dismissedAt: Date.now() });
    };

    if (!visible) return null;

    return (
        <div
            className="fixed inset-0 z-[90] flex items-end justify-center bg-black/60 p-4 backdrop-blur-sm sm:items-center"
            role="dialog"
            aria-modal="true"
            aria-label="Special offer"
        >
            <div className="ring-grad relative w-full max-w-md overflow-hidden rounded-2xl border border-white/10 bg-card p-6 shadow-2xl">
                <button
                    type="button"
                    onClick={handleDismiss}
                    className="focus-glow absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-white/5 text-muted-foreground hover:bg-white/10 hover:text-foreground"
                    aria-label="Dismiss offer"
                >
                    <X className="h-4 w-4" />
                </button>

                <div className="mb-4 flex items-center gap-3">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl grad-ax-warm shadow-[0_0_18px_hsl(28_95%_58%/0.4)]">
                        <Gift className="h-5 w-5 text-primary-foreground" strokeWidth={2.4} />
                    </span>
                    <div className="min-w-0">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">
                            Special Offer
                        </p>
                        <h2 className="font-display text-lg font-bold leading-tight">
                            20% off Hostinger
                        </h2>
                    </div>
                </div>

                <p className="text-sm leading-relaxed text-foreground/90">
                    Hey, get 20% off when you sign up to Hostinger using my link.
                </p>

                <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <button
                        type="button"
                        onClick={handleDismiss}
                        className="focus-glow inline-flex min-h-[44px] items-center justify-center rounded-full border border-white/10 bg-white/5 px-6 text-sm font-medium text-muted-foreground transition-colors hover:border-white/20 hover:text-foreground"
                    >
                        No thanks
                    </button>
                    <a
                        href={REFERRAL_URL}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={handleDismiss}
                        className="focus-glow apx-promo-claim inline-flex min-h-[44px] items-center justify-center gap-2 rounded-full grad-ax-warm px-8 text-sm font-bold text-primary-foreground shadow-[0_0_18px_hsl(28_95%_58%/0.45)] transition-transform hover:scale-[1.03] active:scale-[0.98]"
                    >
                        Claim
                        <ExternalLink className="h-4 w-4" aria-hidden="true" />
                    </a>
                </div>
            </div>
        </div>
    );
};

export default PromotionalOffer;
