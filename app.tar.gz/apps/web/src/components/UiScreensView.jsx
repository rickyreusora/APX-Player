import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
    ChevronLeft,
    ChevronRight,
    Disc3,
    Music2,
    Search as SearchIcon,
    Settings,
    Star,
    Trophy,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { TAG_COLOR_HEX } from '@/lib/uiScreens';

/* ------------------------------------------------------------------ */
/*  Tag badge — color-coded by type (MegaOke convention)              */
/* ------------------------------------------------------------------ */
const TagBadge = ({ tag, className }) => {
    const color = TAG_COLOR_HEX[tag] || TAG_COLOR_HEX.MTV;
    return (
        <span
            className={cn(
                'shrink-0 rounded px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide',
                className,
            )}
            style={{ backgroundColor: `${color}22`, color }}
        >
            {tag || 'MTV'}
        </span>
    );
};

/* ------------------------------------------------------------------ */
/*  Idle screen — SELECT / LOGO / NEW_SONGS / COMMERCIAL              */
/* ------------------------------------------------------------------ */
const IdleSelect = ({ data }) => {
    const { code, title, artist, tag } = data;
    return (
        <div className="flex min-h-[180px] flex-col items-center justify-center gap-3 px-4 py-8 text-center sm:min-h-[240px]">
            <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-cyan-400/70">Now Selected</p>
            {code ? (
                <span className="display text-5xl font-black leading-none tracking-[0.15em] text-cyan-300 sm:text-7xl">
                    {code}
                </span>
            ) : (
                <span className="display text-4xl font-black leading-none tracking-[0.1em] text-zinc-500 sm:text-6xl">
                    ------
                </span>
            )}
            {title ? (
                <h3 className="display max-w-2xl text-2xl leading-tight text-white sm:text-4xl">{title}</h3>
            ) : (
                <h3 className="text-base text-zinc-500">Select a song to begin</h3>
            )}
            {artist && <p className="text-sm text-zinc-300 sm:text-base">{artist}</p>}
            {tag && (
                <div className="mt-1">
                    <TagBadge tag={tag} />
                </div>
            )}
        </div>
    );
};

const IdleLogo = () => (
    <div className="flex min-h-[180px] flex-col items-center justify-center gap-3 px-4 py-8 text-center sm:min-h-[240px]">
        <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
            className="grid h-16 w-16 place-items-center rounded-2xl border border-cyan-400/40 bg-cyan-400/10 text-cyan-300 sm:h-20 sm:w-20"
        >
            <Disc3 className="h-9 w-9 animate-spin sm:h-11 sm:w-11" style={{ animationDuration: '6s' }} aria-hidden="true" />
        </motion.div>
        <h2 className="display text-5xl font-black leading-none tracking-wide text-white sm:text-7xl">
            Mega<span className="text-cyan-300">Oke</span>
        </h2>
        <p className="text-sm font-semibold uppercase tracking-[0.4em] text-zinc-400 sm:text-base">Web Edition</p>
        <p className="mt-2 text-[11px] uppercase tracking-[0.25em] text-zinc-600">ApX Karaoke · MaruyaTVPH</p>
    </div>
);

const IdleNewSongs = ({ items, page, pageCount, onPage }) => {
    return (
        <div className="flex min-h-[180px] flex-col px-3 py-4 sm:min-h-[240px]">
            <div className="mb-2 flex items-center justify-between px-1">
                <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-cyan-400/80">New Songs</p>
                <p className="font-mono text-[10px] text-zinc-500">
                    {page + 1}/{pageCount}
                </p>
            </div>
            <ul className="flex-1 space-y-px overflow-hidden">
                {items.length === 0 && (
                    <li className="py-6 text-center text-xs text-zinc-600">No new songs available</li>
                )}
                {items.map((s, i) => (
                    <li
                        key={`${s.code}-${i}`}
                        className={cn(
                            'flex items-center gap-2 border-b border-white/5 px-2 py-1.5',
                            i % 2 === 0 ? 'bg-white/[0.03]' : 'bg-transparent',
                        )}
                    >
                        <span className="w-16 shrink-0 font-mono text-xs font-bold text-cyan-400">{s.code}</span>
                        <div className="min-w-0 flex-1">
                            <p className="truncate text-xs font-bold text-zinc-200 sm:text-sm">{s.title}</p>
                            <p className="truncate text-[10px] text-zinc-500 sm:text-xs">{s.artist}</p>
                        </div>
                        <TagBadge tag={s.tag} />
                    </li>
                ))}
            </ul>
            {pageCount > 1 && (
                <div className="mt-2 flex items-center justify-center gap-3">
                    <button
                        type="button"
                        data-focusable
                        onClick={() => onPage(page - 1)}
                        className="grid h-7 w-7 place-items-center rounded bg-white/10 text-zinc-300 active:scale-95"
                        aria-label="Previous page"
                    >
                        <ChevronLeft className="h-4 w-4" />
                    </button>
                    <button
                        type="button"
                        data-focusable
                        onClick={() => onPage(page + 1)}
                        className="grid h-7 w-7 place-items-center rounded bg-white/10 text-zinc-300 active:scale-95"
                        aria-label="Next page"
                    >
                        <ChevronRight className="h-4 w-4" />
                    </button>
                </div>
            )}
        </div>
    );
};

const IdleCommercial = () => (
    <div className="flex min-h-[180px] flex-col items-center justify-center gap-3 px-4 py-8 text-center sm:min-h-[240px]">
        <div className="grid h-14 w-14 place-items-center rounded-2xl border border-amber-500/40 bg-amber-500/10 text-amber-300">
            <Music2 className="h-7 w-7" aria-hidden="true" />
        </div>
        <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-amber-400/70">Commercial Break</p>
        <p className="max-w-sm text-sm text-zinc-400">Your karaoke experience is sponsored by ApX Player.</p>
        <p className="text-[11px] uppercase tracking-[0.2em] text-zinc-600">Resuming shortly…</p>
    </div>
);

const IdleScreen = ({ state, newSongsItems, newSongsPageCount, onPage }) => {
    switch (state.idleMode) {
        case 'LOGO': return <IdleLogo />;
        case 'NEW_SONGS':
            return (
                <IdleNewSongs
                    items={newSongsItems}
                    page={state.newSongsPage}
                    pageCount={newSongsPageCount}
                    onPage={onPage}
                />
            );
        case 'COMMERCIAL': return <IdleCommercial />;
        default: return <IdleSelect data={state.idleData} />;
    }
};

/* ------------------------------------------------------------------ */
/*  Search screen — query + results with selection highlight          */
/* ------------------------------------------------------------------ */
const SearchScreen = ({ state }) => {
    const { query, results, selectedIndex, scrollOffset, total, maxRows } = state.search;
    const visible = results.slice(scrollOffset, scrollOffset + maxRows);
    return (
        <div className="flex min-h-[180px] flex-col px-3 py-4 sm:min-h-[240px]">
            <div className="mb-3 flex items-center gap-2 rounded-lg border border-cyan-400/30 bg-black/50 px-3 py-2">
                <SearchIcon className="h-4 w-4 shrink-0 text-cyan-300" aria-hidden="true" />
                <span className="min-w-0 flex-1 truncate font-mono text-base text-white sm:text-lg">
                    {query || ''}
                    <motion.span
                        animate={{ opacity: [1, 0, 1] }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'easeInOut' }}
                        className="ml-0.5 inline-block text-cyan-300"
                    >
                        ▋
                    </motion.span>
                </span>
            </div>
            <p className="mb-1 px-1 text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500">
                Results · {total}
            </p>
            <ul className="flex-1 space-y-px overflow-hidden">
                {visible.length === 0 && (
                    <li className="py-6 text-center text-xs text-zinc-600">
                        {query ? 'No matches found' : 'Type to search the songbook'}
                    </li>
                )}
                {visible.map((s, i) => {
                    const absIdx = scrollOffset + i;
                    const selected = absIdx === selectedIndex;
                    return (
                        <li
                            key={`${s.code}-${absIdx}`}
                            className={cn(
                                'flex items-center gap-2 border-l-[3px] px-2 py-1.5 transition-colors',
                                selected
                                    ? 'border-l-cyan-400 bg-cyan-400/15'
                                    : 'border-l-transparent bg-white/[0.02]',
                            )}
                        >
                            <span className="w-16 shrink-0 font-mono text-xs font-bold text-cyan-400">{s.code}</span>
                            <div className="min-w-0 flex-1">
                                <p className={cn('truncate text-xs font-bold sm:text-sm', selected ? 'text-cyan-200' : 'text-zinc-200')}>
                                    {s.title}
                                </p>
                                <p className="truncate text-[10px] text-zinc-500 sm:text-xs">{s.artist}</p>
                            </div>
                            {s.tag && <TagBadge tag={s.tag} />}
                        </li>
                    );
                })}
            </ul>
        </div>
    );
};

/* ------------------------------------------------------------------ */
/*  Ranking screen — top performances from history                    */
/* ------------------------------------------------------------------ */
const RankingScreen = ({ state }) => (
    <div className="flex min-h-[180px] flex-col px-3 py-4 sm:min-h-[240px]">
        <div className="mb-2 flex items-center gap-2 px-1">
            <Trophy className="h-4 w-4 text-amber-300" aria-hidden="true" />
            <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-amber-400/80">Top Performances</p>
        </div>
        <ul className="flex-1 space-y-px overflow-hidden">
            {state.ranking.length === 0 && (
                <li className="py-8 text-center text-xs text-zinc-600">No performances yet — sing a song to rank up!</li>
            )}
            {state.ranking.map((r, i) => (
                <li
                    key={`${r.title}-${r.date}`}
                    className={cn(
                        'flex items-center gap-2 border-b border-white/5 px-2 py-1.5',
                        i % 2 === 0 ? 'bg-white/[0.03]' : 'bg-transparent',
                    )}
                >
                    <span className={cn(
                        'grid h-6 w-6 shrink-0 place-items-center rounded-full text-[10px] font-black',
                        i === 0 ? 'bg-amber-400 text-black' : i === 1 ? 'bg-zinc-300 text-black' : i === 2 ? 'bg-amber-700 text-white' : 'bg-white/10 text-zinc-300',
                    )}>
                        {i + 1}
                    </span>
                    <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-bold text-zinc-200">{r.title}</p>
                        <p className="truncate text-[10px] text-zinc-500">{r.artist}</p>
                    </div>
                    <span className="inline-flex items-center gap-1 font-mono text-sm font-bold text-cyan-300">
                        <Star className="h-3 w-3 fill-current" aria-hidden="true" />
                        {r.score}
                    </span>
                </li>
            ))}
        </ul>
    </div>
);

/* ------------------------------------------------------------------ */
/*  Setup menu — two-pane renderer                                    */
/* ------------------------------------------------------------------ */
const SetupControl = ({ setting, selected, onActivate, onSetColor }) => {
    const rowCls = cn('flex items-center justify-between rounded px-3 py-2 cursor-pointer transition-colors', selected && 'bg-yellow-400/15');
    if (setting.type === 'toggle') {
        return (
            <div className={rowCls} onClick={onActivate} role="button" tabIndex={0} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onActivate(); } }}>
                <span className={cn('text-xs font-semibold', selected ? 'text-yellow-300' : 'text-zinc-300')}>{setting.label}</span>
                <span
                    className={cn(
                        'relative h-5 w-9 rounded-full transition-colors',
                        setting.value ? 'bg-cyan-400' : 'bg-zinc-600',
                    )}
                >
                    <span
                        className={cn(
                            'absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform',
                            setting.value ? 'translate-x-4' : 'translate-x-0.5',
                        )}
                    />
                </span>
            </div>
        );
    }
    if (setting.type === 'selector') {
        return (
            <div className={rowCls} onClick={onActivate} role="button" tabIndex={0} onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onActivate(); } }}>
                <span className={cn('text-xs font-semibold', selected ? 'text-yellow-300' : 'text-zinc-300')}>{setting.label}</span>
                <span className="inline-flex items-center gap-1 rounded bg-white/10 px-2 py-0.5 font-mono text-[11px] font-bold text-cyan-300">
                    {setting.value}
                </span>
            </div>
        );
    }
    if (setting.type === 'color') {
        return (
            <div className={cn('rounded px-3 py-2', selected && 'bg-yellow-400/15')}>
                <p className={cn('mb-1.5 text-xs font-semibold', selected ? 'text-yellow-300' : 'text-zinc-300')}>{setting.label}</p>
                <div className="flex flex-wrap gap-1.5">
                    {setting.options.map((c) => (
                        <button
                            key={c}
                            type="button"
                            data-focusable
                            onClick={() => onSetColor(c)}
                            className={cn(
                                'h-6 w-6 rounded-full border-2 transition-transform active:scale-90',
                                setting.value === c ? 'border-white' : 'border-transparent',
                            )}
                            style={{ backgroundColor: c }}
                            aria-label={`Select ${c}`}
                        />
                    ))}
                </div>
            </div>
        );
    }
    // action
    return (
        <button
            type="button"
            data-focusable
            onClick={onActivate}
            className={cn(
                'w-full rounded px-3 py-2 text-left text-xs font-bold transition-colors',
                selected ? 'bg-yellow-400/20 text-yellow-300' : 'bg-white/5 text-zinc-300 hover:bg-white/10',
            )}
        >
            {setting.label}
        </button>
    );
};

const SetupScreen = ({ state, currentCategory, onActivate, onSetColor }) => {
    const catRef = useRef(null);
    const selCatRef = useRef(null);
    const settingsRef = useRef(null);
    const selSetRef = useRef(null);
    const cat = currentCategory;

    // Auto-scroll to the selected category / setting.
    useEffect(() => {
        selCatRef.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }, [state.setupSelectedCategory]);
    useEffect(() => {
        selSetRef.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }, [state.setupSelectedSetting]);

    return (
        <div className="flex min-h-[180px] flex-col px-3 py-3 sm:min-h-[240px]">
            <div className="mb-2 flex items-center gap-2 px-1">
                <Settings className="h-4 w-4 text-yellow-300" aria-hidden="true" />
                <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-yellow-400/80">Setup Menu</p>
            </div>
            <div className="grid flex-1 grid-cols-[7rem_1fr] gap-2 overflow-hidden sm:grid-cols-[9rem_1fr]">
                {/* Categories pane */}
                <ul
                    ref={catRef}
                    className="overflow-y-auto bg-black/40"
                    style={{ WebkitOverflowScrolling: 'touch' }}
                >
                    {state.setupCategories.map((c, i) => {
                        const selected = i === state.setupSelectedCategory && state.setupPane === 'categories';
                        const active = i === state.setupSelectedCategory;
                        return (
                            <li
                                key={c.id}
                                ref={active ? selCatRef : null}
                                className={cn(
                                    'border-l-[3px] px-2 py-2 text-[11px] font-bold transition-colors sm:text-xs',
                                    selected
                                        ? 'border-l-yellow-400 bg-yellow-400/15 text-yellow-300'
                                        : active
                                          ? 'border-l-cyan-400/60 bg-cyan-400/5 text-cyan-200'
                                          : 'border-l-transparent text-zinc-400',
                                )}
                            >
                                {c.label}
                            </li>
                        );
                    })}
                </ul>

                {/* Settings pane */}
                <div
                    ref={settingsRef}
                    className="space-y-1 overflow-y-auto bg-black/40"
                    style={{ WebkitOverflowScrolling: 'touch' }}
                >
                    {cat?.settings.map((s, i) => {
                        const selected = i === state.setupSelectedSetting && state.setupPane === 'settings';
                        return (
                            <div key={s.id} ref={selected ? selSetRef : null}>
                                <SetupControl
                                    setting={s}
                                    selected={selected}
                                    onActivate={() => onActivate(s)}
                                    onSetColor={onSetColor}
                                />
                            </div>
                        );
                    })}
                </div>
            </div>
            <p className="mt-2 px-1 text-[10px] text-zinc-600">
                Use the remote D-pad to navigate · OK to toggle / cycle · Back to exit
            </p>
        </div>
    );
};

/* ------------------------------------------------------------------ */
/*  UiScreensView — stage screen switcher                             */
/* ------------------------------------------------------------------ */
/**
 * UiScreensView — renders the current UiScreens screen inside the karaoke
 * stage. Driven by a UiScreens instance's reactive state.
 */
const UiScreensView = ({ uiScreens, state, onNewSongsPage, onSetupActivate, onSetupSetColor }) => {
    const screen = state.screen;
    // Derive instance-method data here (state is a plain snapshot).
    const newSongsItems = uiScreens.newSongsPageItems();
    const newSongsPageCount = uiScreens.newSongsPageCount();
    const setupCurrentCategory = uiScreens.setupCurrentCategory();
    return (
        <div className="relative z-10 flex flex-1 flex-col items-center justify-center p-3 text-center">
            <div className="w-full max-w-md rounded-xl border border-white/10 bg-[#141414]/90 shadow-xl sm:max-w-lg">
                <div className="border-b border-white/10 px-4 py-2 text-left text-xs font-bold uppercase tracking-[0.25em] text-zinc-500">
                    ApX Karaoke
                </div>
                <AnimatePresence mode="wait">
                    <motion.div
                        key={screen}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                        transition={{ duration: 0.2, ease: 'easeOut' }}
                    >
                        {screen === 'SEARCH' && <SearchScreen state={state} />}
                        {screen === 'RANKING' && <RankingScreen state={state} />}
                        {screen === 'SETUP' && (
                            <SetupScreen
                                state={state}
                                currentCategory={setupCurrentCategory}
                                onActivate={onSetupActivate}
                                onSetColor={onSetupSetColor}
                            />
                        )}
                        {screen === 'IDLE' && (
                            <IdleScreen
                                state={state}
                                newSongsItems={newSongsItems}
                                newSongsPageCount={newSongsPageCount}
                                onPage={onNewSongsPage}
                            />
                        )}
                        {screen === 'SCORE' && <IdleSelect data={state.idleData} />}
                    </motion.div>
                </AnimatePresence>
                <div className="border-t border-white/10 px-4 py-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-zinc-600">
                    {screen === 'SETUP' ? 'Setup · press Back to exit' : 'ApX Karaoke · MaruyaTVPH'}
                </div>
            </div>
        </div>
    );
};

export default UiScreensView;
