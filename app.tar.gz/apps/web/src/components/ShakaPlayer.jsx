import React, { useEffect, useRef, useState } from 'react';
import shaka from 'shaka-player';
import { AlertCircle, Loader2, Maximize, Radio } from 'lucide-react';

/**
 * Shaka Player wrapper for DASH/MPD live streams with optional ClearKey DRM.
 *
 * Props:
 *  - url:        MPD manifest URL
 *  - clearkey:   { kid, key } hex strings, or null
 *  - title:      channel name (for a11y / overlay)
 *  - logo:       channel logo URL (overlay)
 */
const ShakaPlayer = ({ url, clearkey, title, logo }) => {
    const videoRef = useRef(null);
    const containerRef = useRef(null);
    const playerRef = useRef(null);
    const [status, setStatus] = useState('loading'); // loading | ready | error
    const [errorMsg, setErrorMsg] = useState('');

    useEffect(() => {
        let cancelled = false;
        const video = videoRef.current;

        // Shaka polyfills must be installed before use.
        shaka.polyfill.installAll();

        const init = async () => {
            if (!shaka.Player.isBrowserSupported()) {
                setStatus('error');
                setErrorMsg('This browser does not support Shaka Player playback.');
                return;
            }
            const player = new shaka.Player();
            playerRef.current = player;
            await player.attach(video);

            const config = {
                streaming: { bufferingGoal: 30, rebufferingGoal: 4 },
            };
            if (clearkey?.kid && clearkey?.key) {
                config.drm = { clearKeys: { [clearkey.kid]: clearkey.key } };
            }
            player.configure(config);

            player.addEventListener('error', (e) => {
                if (cancelled) return;
                setStatus('error');
                setErrorMsg(e?.detail?.message || 'Playback error.');
            });

            try {
                await player.load(url);
                if (cancelled) return;
                setStatus('ready');
                video.play().catch(() => {});
            } catch (err) {
                if (cancelled) return;
                setStatus('error');
                setErrorMsg(err?.message || 'Could not load this live stream.');
            }
        };

        init();

        return () => {
            cancelled = true;
            const p = playerRef.current;
            if (p) {
                p.destroy().catch(() => {});
                playerRef.current = null;
            }
        };
    }, [url, clearkey?.kid, clearkey?.key]);

    const enterFullscreen = async () => {
        const el = containerRef.current;
        if (!el) return;
        if (document.fullscreenElement) {
            await document.exitFullscreen().catch(() => {});
        } else if (el.requestFullscreen) {
            await el.requestFullscreen().catch(() => {});
        }
    };

    return (
        <div
            ref={containerRef}
            className="group relative aspect-video w-full overflow-hidden rounded-sm border border-white/10 bg-black"
        >
            <video
                ref={videoRef}
                className="absolute inset-0 h-full w-full bg-black"
                playsInline
                controls
            />

            {/* Live badge */}
            <div className="pointer-events-none absolute left-3 top-3 z-10 flex items-center gap-1.5 rounded-sm bg-black/70 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.2em] text-white">
                <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
                </span>
                Live
            </div>

            {/* Channel logo overlay (top-right) */}
            {logo && (
                <div className="pointer-events-none absolute right-3 top-3 z-10 max-w-[40%]">
                    <img
                        src={logo}
                        alt=""
                        className="max-h-10 w-auto rounded-sm bg-black/40 object-contain"
                        onError={(e) => { e.currentTarget.style.display = 'none'; }}
                    />
                </div>
            )}

            {/* Fullscreen button */}
            <button
                type="button"
                onClick={enterFullscreen}
                className="absolute bottom-3 right-3 z-10 grid h-10 w-10 place-items-center rounded-sm bg-black/70 text-white opacity-0 transition-opacity hover:bg-black/90 group-hover:opacity-100"
                aria-label="Fullscreen"
            >
                <Maximize className="h-5 w-5" aria-hidden="true" />
            </button>

            {status === 'loading' && (
                <div className="absolute inset-0 z-20 grid place-items-center bg-black/80">
                    <div className="flex flex-col items-center gap-3 text-muted-foreground">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" aria-hidden="true" />
                        <p className="text-sm">Loading live stream…</p>
                    </div>
                </div>
            )}

            {status === 'error' && (
                <div className="absolute inset-0 z-20 grid place-items-center bg-black/85 p-6 text-center">
                    <div className="flex max-w-md flex-col items-center gap-3">
                        <AlertCircle className="h-8 w-8 text-destructive" aria-hidden="true" />
                        <p className="text-sm text-foreground">{errorMsg}</p>
                        <p className="text-xs text-muted-foreground">
                            This channel may be temporarily unavailable or geo-restricted.
                        </p>
                    </div>
                </div>
            )}

            {title && status === 'ready' && (
                <div className="pointer-events-none absolute bottom-3 left-3 z-10 flex items-center gap-2 rounded-sm bg-black/60 px-2.5 py-1 text-xs font-medium text-white opacity-0 transition-opacity group-hover:opacity-100">
                    <Radio className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
                    {title}
                </div>
            )}
        </div>
    );
};

export default ShakaPlayer;
