import { useEffect, useRef, useState } from 'react';
import { UiPainter } from '@/lib/uiPainter';

/**
 * React binding for the UiPainter class. Creates a single UiPainter instance
 * (which owns UiSystem, UiScreens, UiScore, UiLyrics, UiHud) for the
 * component's lifetime and mirrors its aggregated state into React state so
 * every sub-module view updates reactively through one subscription.
 *
 * @param {object} [options] forwarded to the UiPainter constructor
 * @returns {[UiPainter, object]} the UiPainter instance + aggregated state
 */
export function useUiPainter(options) {
    const ref = useRef(null);
    if (!ref.current) ref.current = new UiPainter(options);
    const [state, setState] = useState(() => ref.current.getState());

    useEffect(() => {
        const painter = ref.current;
        painter.bindResize();
        const unsub = painter.subscribe(setState);
        return () => {
            unsub();
            painter.destroy();
        };
    }, []);

    return [ref.current, state];
}

export default useUiPainter;
