import { useEffect, useRef, useState } from 'react';
import { UiScore } from '@/lib/uiScore';

/**
 * React binding for the UiScore class. Creates a single UiScore instance for
 * the component's lifetime and mirrors its state into React state so the
 * animated score number, greeting, and dynamic icons update reactively.
 *
 * @param {object} [options] forwarded to the UiScore constructor
 * @returns {[UiScore, object]} the UiScore instance + current state snapshot
 */
export function useUiScore(options) {
    const ref = useRef(null);
    if (!ref.current) ref.current = new UiScore(options);
    const [state, setState] = useState(() => ref.current.getState());

    useEffect(() => {
        const sys = ref.current;
        const unsub = sys.subscribe(setState);
        return () => {
            unsub();
            sys.destroy();
        };
    }, []);

    return [ref.current, state];
}

export default useUiScore;
