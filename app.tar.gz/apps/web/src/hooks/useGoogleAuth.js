import { useEffect, useState } from 'react';
import pb from '@/lib/pocketbaseClient';

// Reports whether Google OAuth sign-in is available on the `users` collection.
// PocketBase's listAuthMethods() reflects the providers configured on the
// collection, so when GOOGLE_CLIENT_ID/SECRET are unset the google provider
// is absent (removed by the google-oauth-sync hook) and this returns false —
// letting the UI hide the Google button instead of showing one that errors.
export function useGoogleAuth() {
    const [available, setAvailable] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let active = true;
        pb.collection('users')
            .listAuthMethods()
            .then((res) => {
                if (!active) return;
                const providers =
                    (res.oauth2 && res.oauth2.providers) || res.authProviders || [];
                setAvailable(providers.some((p) => p.name === 'google'));
            })
            .catch(() => {
                if (active) setAvailable(false);
            })
            .finally(() => {
                if (active) setLoading(false);
            });
        return () => {
            active = false;
        };
    }, []);

    return { available, loading };
}

export default useGoogleAuth;
