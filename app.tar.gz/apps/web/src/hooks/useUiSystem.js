import { useEffect, useRef, useState } from 'react';
import { UiSystem } from '@/lib/uiSystem';

/**
 * React binding for the UiSystem class. Creates a single UiSystem instance
 * for the component's lifetime and mirrors its state into React state so
 * modals, boot status, and the video bridge update reactively.
 *
 * @param {object} [options] forwarded to the UiSystem constructor
 * @returns {[UiSystem, object]} the UiSystem instance + current state snapshot
 */
export function useUiSystem(options) {
    const ref = useRef(null);
    if (!ref.current) ref.current = new UiSystem(options);
    const [state, setState] = useState(() => ref.current.getState());

    useEffect(() => {
        const sys = ref.current;
        const unsub = sys.subscribe(setState);
        return () => {
            unsub();
            sys.destroy();
        };
    }, []);

    return [ref.current, state];
}

export default useUiSystem;
