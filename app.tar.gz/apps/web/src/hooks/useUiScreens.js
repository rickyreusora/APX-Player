import { useEffect, useRef, useState } from 'react';
import { UiScreens } from '@/lib/uiScreens';

/**
 * React binding for the UiScreens class. Creates a single UiScreens instance
 * for the component's lifetime and mirrors its state into React state so the
 * idle / search / setup / ranking / score screens update reactively.
 *
 * @param {object} [options] forwarded to the UiScreens constructor
 * @returns {[UiScreens, object]} the UiScreens instance + current state snapshot
 */
export function useUiScreens(options) {
    const ref = useRef(null);
    if (!ref.current) ref.current = new UiScreens(options);
    const [state, setState] = useState(() => ref.current.getState());

    useEffect(() => {
        const sys = ref.current;
        const unsub = sys.subscribe(setState);
        return () => {
            unsub();
            sys.destroy();
        };
    }, []);

    return [ref.current, state];
}

export default useUiScreens;
