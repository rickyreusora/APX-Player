import React from 'react';
import { Helmet } from 'react-helmet';
import { ExternalLink, Globe, Mail, MapPin, Phone, Send } from 'lucide-react';
import Layout from '@/components/Layout';

const ContactPage = () => (
    <Layout>
        <Helmet>
            <title>Contact ApX Player | Support and Rights Enquiries</title>
            <meta name="description" content="Contact the ApX Player team at MaruyaTVPH for support, licensing questions, or content-rights and takedown enquiries." />
        </Helmet>
        <div className="mx-auto max-w-[56rem] px-4 py-16 sm:px-6">
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">Contact</p>
            <h1 className="display text-5xl sm:text-6xl">Get in touch</h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-foreground/80">
                For support, licensing enquiries, or content-rights notices, contact the MaruyaTVPH team using the details below.
            </p>

            <div className="mt-12 grid gap-4 sm:grid-cols-3">
                <div className="rounded-sm border border-border bg-card/40 p-5">
                    <Mail className="mb-3 h-5 w-5 text-primary" aria-hidden="true" />
                    <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground">Email</p>
                    <div className="mt-2 flex flex-col gap-2 text-sm font-medium">
                        <a className="break-all hover:text-primary" href="mailto:support@moviepinas.com">support@moviepinas.com</a>
                        <a className="break-all hover:text-primary" href="mailto:admin@maruyatvph.com">admin@maruyatvph.com</a>
                    </div>
                </div>
                <div className="rounded-sm border border-border bg-card/40 p-5">
                    <Phone className="mb-3 h-5 w-5 text-primary" aria-hidden="true" />
                    <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground">Phone</p>
                    <a className="mt-2 inline-block text-sm font-medium hover:text-primary" href="tel:09943729761">09943729761</a>
                </div>
                <div className="rounded-sm border border-border bg-card/40 p-5">
                    <MapPin className="mb-3 h-5 w-5 text-primary" aria-hidden="true" />
                    <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground">Address</p>
                    <a className="mt-2 inline-flex items-center gap-2 text-sm font-medium hover:text-primary" href="https://maps.app.goo.gl/ZabCmwmhjtNADsHGA" target="_blank" rel="noreferrer">
                        View location <ExternalLink className="h-4 w-4" aria-hidden="true" />
                    </a>
                </div>
            </div>

            <section className="mt-12" aria-labelledby="follow-heading">
                <h2 id="follow-heading" className="text-lg font-semibold">Follow and connect</h2>
                <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    <a className="flex min-h-12 items-center justify-between gap-3 rounded-sm border border-border bg-card/40 px-4 py-3 text-sm font-medium transition-colors hover:border-primary/50 hover:text-primary" href="https://www.facebook.com/share/1CWdrxizEq/" target="_blank" rel="noreferrer">
                        Follow Facebook <ExternalLink className="h-4 w-4 shrink-0" aria-hidden="true" />
                    </a>
                    <a className="flex min-h-12 items-center justify-between gap-3 rounded-sm border border-border bg-card/40 px-4 py-3 text-sm font-medium transition-colors hover:border-primary/50 hover:text-primary" href="https://youtube.com/channel/UCBrYLVpcrD2tllQtETy52tA?si=F69vh1VjPbVtihLI" target="_blank" rel="noreferrer">
                        Subscribe on YouTube <ExternalLink className="h-4 w-4 shrink-0" aria-hidden="true" />
                    </a>
                    <a className="flex min-h-12 items-center justify-between gap-3 rounded-sm border border-border bg-card/40 px-4 py-3 text-sm font-medium transition-colors hover:border-primary/50 hover:text-primary" href="https://open.spotify.com/artist/6jw2xFq5VMVhfnh3iqqEsu?si=zDFudFmyT1iT33Oh1IJ8dw&utm_source=copy-link" target="_blank" rel="noreferrer">
                        Follow on Spotify <ExternalLink className="h-4 w-4 shrink-0" aria-hidden="true" />
                    </a>
                </div>
            </section>

            <section className="mt-10 grid gap-10 border-t border-border pt-8 md:grid-cols-2" aria-label="Official websites and Telegram assistant">
                <div>
                    <h2 className="flex items-center gap-2 text-lg font-semibold"><Globe className="h-5 w-5 text-primary" aria-hidden="true" /> Official websites</h2>
                    <ul className="mt-4 space-y-2 text-sm">
                        {['https://moviepinas.com', 'https://maruyatvph.com', 'https://maruyatvph.org'].map((website) => (
                            <li key={website}>
                                <a className="inline-flex items-center gap-2 text-foreground/80 hover:text-primary" href={website} target="_blank" rel="noreferrer">
                                    {website.replace('https://', '')} <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                                </a>
                            </li>
                        ))}
                    </ul>
                </div>
                <div>
                    <h2 className="flex items-center gap-2 text-lg font-semibold"><Send className="h-5 w-5 text-primary" aria-hidden="true" /> Telegram assistant</h2>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                        The official automated assistant for MaruyaTVPH. Download the app, check server status, and get support 24/7. 📺✨
                    </p>
                    <a className="mt-3 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-primary hover:underline" href="https://t.me/maruyatvph_bot" target="_blank" rel="noreferrer">
                        Open @maruyatvph_bot <ExternalLink className="h-4 w-4" aria-hidden="true" />
                    </a>
                </div>
            </section>

            <div className="mt-12 rounded-sm border border-primary/30 bg-primary/5 p-6">
                <h2 className="text-lg font-semibold">Rights and takedown notices</h2>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    If you believe a title on this platform is published without authorization, send the title name, the URL,
                    your relationship to the rights holder, and your contact details to either email address above. We remove disputed
                    content while the claim is reviewed.
                </p>
            </div>
        </div>
    </Layout>
);

export default ContactPage;
