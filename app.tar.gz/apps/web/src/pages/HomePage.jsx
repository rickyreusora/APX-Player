import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { Info, Play, Search, ShieldCheck, Star, Sparkles, Radio, Film, Apple, Smartphone, Monitor, Tv, Download } from 'lucide-react';
import Layout from '@/components/Layout';
import TitleRow from '@/components/TitleRow';
import Reveal from '@/components/Reveal';
import { ErrorState } from '@/components/StateBlocks';
import { getHomeRows, listGenres } from '@/lib/catalog';

const MARQUEE_WORDS = ['LICENSED', 'CINEMATIC', 'AD-FREE', 'YOUR LIBRARY', 'ANY DEVICE', 'KARAOKE READY'];

const CATEGORY_PILLS = [
    { label: 'Trending', to: '/browse?category=trending', grad: 'grad-ax-cool' },
    { label: 'Movies', to: '/browse?kind=movie', grad: 'grad-ax-warm' },
    { label: 'Series', to: '/browse?kind=series', grad: 'grad-ax-cool' },
    { label: 'Vivamax', to: '/browse?category=vivamax', grad: 'grad-ax-warm' },
    { label: 'Viva One', to: '/browse?category=vivaone', grad: 'grad-ax-cool' },
    { label: 'Live TV', to: '/livetv', grad: 'grad-ax' },
    { label: 'Karaoke', to: '/karaoke-library', grad: 'grad-ax-warm' },
    { label: 'Pro Reels', to: '/pro-reels', grad: 'grad-ax' },
];

const HomePage = () => {
    const [hero, setHero] = useState(null);
    const [rows, setRows] = useState({ featured: [], recent: [], popular: [], series: [] });
    const [genres, setGenres] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [q, setQ] = useState('');
    const navigate = useNavigate();

    const load = async () => {
        setLoading(true);
        setError('');
        try {
            const [home, gs] = await Promise.all([getHomeRows(), listGenres()]);
            setRows({
                featured: home?.featured || [],
                recent: home?.recent || [],
                popular: home?.popular || [],
                series: home?.series || [],
            });
            setGenres(Array.isArray(gs) ? gs : []);
            setHero(home?.featured?.[0] || home?.popular?.[0] || home?.recent?.[0] || null);
        } catch (err) {
            setError(err?.notConfigured ? 'TMDB is not configured yet.' : err?.message || 'Could not load the catalogue.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
    }, []);

    const onSearch = (e) => {
        e.preventDefault();
        navigate(`/browse?q=${encodeURIComponent(q)}`);
    };

    return (
        <Layout>
            <Helmet>
                <title>ApX Player — All-in-One Streaming &amp; Karaoke by MaruyaTVPH</title>
                <meta
                    name="description"
                    content="ApX Player is an all-in-one streaming and karaoke platform by MaruyaTVPH. Browse movies, TV shows, live channels and a full karaoke stage in one immersive app."
                />
            </Helmet>

            <section className="relative min-h-[100dvh] w-full overflow-hidden">
                {hero?.backdrop && (
                    <img
                        src={hero.backdrop}
                        alt={`Backdrop still from ${hero.title}`}
                        className="absolute inset-0 h-full w-full object-cover"
                    />
                )}
                <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-background/30" />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />

                {/* Floating gradient orbs */}
                <div className="pointer-events-none absolute -left-32 top-1/3 h-96 w-96 rounded-full bg-primary/20 blur-[120px]" aria-hidden="true" />
                <div className="pointer-events-none absolute right-0 top-20 h-80 w-80 rounded-full bg-accent/20 blur-[120px]" aria-hidden="true" />

                <div className="relative mx-auto flex min-h-[100dvh] max-w-[90rem] flex-col justify-center px-4 pb-28 pt-28 sm:px-6">
                    <Reveal>
                        <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">
                            <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" /> Stream · Sing · Stage
                        </p>
                    </Reveal>
                    <Reveal delay={0.05}>
                        <h1 className="font-display max-w-4xl text-5xl font-extrabold leading-[0.95] sm:text-7xl lg:text-8xl">
                            Your stage for <span className="text-grad">movies</span>,<br />
                            <span className="text-grad-warm">shows</span> &amp; karaoke.
                        </h1>
                    </Reveal>
                    <Reveal delay={0.1}>
                        <p className="mt-6 max-w-xl text-base leading-relaxed text-foreground/80 sm:text-lg">
                            Browse a huge catalogue, tune into live TV, or grab the mic and own the karaoke stage — all in one immersive app.
                        </p>
                    </Reveal>

                    {/* Prominent centered search bar */}
                    <Reveal delay={0.15}>
                        <form onSubmit={onSearch} className="mt-8 max-w-2xl" role="search">
                            <label htmlFor="hero-search" className="sr-only">
                                Search songs, movies and shows
                            </label>
                            <div className="group relative flex items-center">
                                <Search className="pointer-events-none absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-primary" aria-hidden="true" />
                                <input
                                    id="hero-search"
                                    value={q}
                                    onChange={(e) => setQ(e.target.value)}
                                    placeholder="Search songs, movies, shows…"
                                    className="focus-glow h-14 w-full rounded-full border border-white/10 bg-white/5 pl-14 pr-32 text-base text-foreground placeholder:text-muted-foreground backdrop-blur-xl transition-colors focus:border-primary/50"
                                />
                                <button
                                    type="submit"
                                    className="focus-glow absolute right-2 inline-flex h-10 items-center gap-1.5 rounded-full grad-ax px-5 text-sm font-semibold text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.4)] transition-transform hover:scale-[1.03] active:scale-[0.98]"
                                >
                                    <Sparkles className="h-4 w-4" aria-hidden="true" /> Search
                                </button>
                            </div>
                        </form>
                    </Reveal>

                    {/* Quick-access category pills */}
                    <Reveal delay={0.2}>
                        <div className="mt-6 flex flex-wrap gap-2.5">
                            {CATEGORY_PILLS.map((p) => (
                                <Link
                                    key={p.label}
                                    to={p.to}
                                    className="focus-glow inline-flex items-center rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-foreground/90 backdrop-blur transition-all hover:scale-[1.04] hover:border-white/20"
                                >
                                    <span className={`mr-2 h-2 w-2 rounded-full ${p.grad}`} aria-hidden="true" />
                                    {p.label}
                                </Link>
                            ))}
                        </div>
                    </Reveal>

                    {hero && (
                        <Reveal delay={0.25}>
                            <div className="mt-12 flex flex-wrap items-center gap-4">
                                <Link
                                    to={`/watch/${hero.slug}`}
                                    className="focus-glow inline-flex min-h-[52px] items-center gap-2.5 rounded-full grad-ax px-8 text-base font-semibold text-primary-foreground shadow-[0_0_24px_hsl(187_95%_55%/0.45)] transition-transform hover:scale-[1.03] active:scale-[0.98]"
                                >
                                    <Play className="h-5 w-5 fill-current" aria-hidden="true" /> Play featured
                                </Link>
                                <Link
                                    to="/browse"
                                    className="focus-glow inline-flex min-h-[52px] items-center gap-2.5 rounded-full border border-white/20 bg-white/10 px-8 text-base font-semibold backdrop-blur transition-colors hover:bg-white/20 active:scale-[0.98]"
                                >
                                    <Info className="h-5 w-5" aria-hidden="true" /> Browse catalogue
                                </Link>
                                <div className="hidden items-center gap-3 rounded-full border border-white/10 bg-black/30 px-5 py-2.5 backdrop-blur sm:flex">
                                    <span className="font-semibold text-foreground">{hero.year || '—'}</span>
                                    <span aria-hidden="true" className="text-muted-foreground">·</span>
                                    <span className="text-sm text-muted-foreground">{hero.kind === 'series' ? 'Series' : 'Movie'}</span>
                                    {!!hero.rating && (
                                        <span className="inline-flex items-center gap-1 text-sm">
                                            <Star className="h-3.5 w-3.5 fill-primary text-primary" aria-hidden="true" />
                                            {hero.rating}
                                        </span>
                                    )}
                                </div>
                            </div>
                        </Reveal>
                    )}
                </div>
            </section>

            <div className="relative overflow-hidden border-y border-white/5">
                <div className="grad-ax py-3">
                    <div className="flex w-max animate-[marquee_28s_linear_infinite] gap-10 whitespace-nowrap">
                        {Array.from({ length: 4 }).flatMap((_, r) =>
                            MARQUEE_WORDS.map((w) => (
                                <span key={`${r}-${w}`} className="display text-xl tracking-[0.2em] text-primary-foreground">
                                    {w} <span className="opacity-50">/</span>
                                </span>
                            )),
                        )}
                    </div>
                </div>
            </div>

            {error ? (
                <div className="py-20">
                    <ErrorState message={error} onRetry={load} />
                </div>
            ) : (
                <>
                    <TitleRow heading="Trending" kicker="This week" items={rows.featured} loading={loading} />
                    <TitleRow heading="Popular Movies" kicker="Fresh in the library" items={rows.recent} loading={loading} />
                    <TitleRow heading="Top Rated" kicker="Highest scored" items={rows.popular} loading={loading} />
                    <TitleRow heading="Popular Series" kicker="Binge-ready" items={rows.series} loading={loading} />
                </>
            )}

            <section className="mx-auto max-w-[72rem] px-4 py-16 sm:px-6">
                <h2 className="font-display mb-6 text-3xl font-bold">Browse by genre</h2>
                <div className="flex flex-wrap gap-2.5">
                    {(Array.isArray(genres) ? genres : []).map((g) => (
                        <Link
                            key={g.id}
                            to={`/browse?category=${g.id}`}
                            className="focus-glow rounded-full border border-border bg-white/5 px-4 py-2 text-sm font-medium transition-all hover:scale-[1.04] hover:border-primary hover:text-primary"
                        >
                            {g.name}
                        </Link>
                    ))}
                    {!loading && genres.length === 0 && (
                        <p className="text-sm text-muted-foreground">No genres could be loaded.</p>
                    )}
                </div>
            </section>

            {/* Feature cards */}
            <section className="mx-auto max-w-[90rem] px-4 py-16 sm:px-6">
                <h2 className="font-display mb-8 text-3xl font-bold sm:text-4xl">One app, every stage</h2>
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                    <Link
                        to="/karaoke-library"
                        className="ring-grad focus-glow group relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-primary/20 via-card to-card p-8 transition-transform hover:scale-[1.02]"
                    >
                        <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-primary/20 blur-3xl" aria-hidden="true" />
                        <div className="relative z-10">
                            <p className="mb-3 inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">
                                <span className="relative flex h-2 w-2">
                                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
                                    <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
                                </span>
                                Live stage
                            </p>
                            <h3 className="font-display text-2xl font-bold">Karaoke Library</h3>
                            <p className="mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">
                                Search the YouTube karaoke database, reserve tracks, sing along with mic input, pitch scoring and recording.
                            </p>
                            <span className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-primary">
                                Open karaoke <span className="transition-transform group-hover:translate-x-1" aria-hidden="true">→</span>
                            </span>
                        </div>
                    </Link>

                    <Link
                        to="/livetv"
                        className="ring-grad focus-glow group relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-accent/20 via-card to-card p-8 transition-transform hover:scale-[1.02]"
                    >
                        <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-accent/20 blur-3xl" aria-hidden="true" />
                        <div className="relative z-10">
                            <p className="mb-3 inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-accent-foreground">
                                <Radio className="h-3.5 w-3.5 text-accent" aria-hidden="true" /> Live now
                            </p>
                            <h3 className="font-display text-2xl font-bold">Live TV Channels</h3>
                            <p className="mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">
                                Stream Cignal &amp; Converge live channels in the built-in player. Search, filter by group, tune in instantly.
                            </p>
                            <span className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-accent">
                                Open Live TV <span className="transition-transform group-hover:translate-x-1" aria-hidden="true">→</span>
                            </span>
                        </div>
                    </Link>

                    <div className="ring-grad relative overflow-hidden rounded-3xl border border-white/10 bg-card p-8">
                        <div className="relative z-10">
                            <p className="mb-3 inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">
                                <Film className="h-3.5 w-3.5 text-primary" aria-hidden="true" /> Cinematic player
                            </p>
                            <h3 className="font-display text-2xl font-bold">A clean, cinematic player</h3>
                            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-foreground/80">
                                ApX Player streams titles from TMDB through the Videasy player. Browse the catalogue, click any title,
                                and start watching. Read the{' '}
                                <Link to="/content-rights" className="text-primary underline underline-offset-4">
                                    Content Rights notice
                                </Link>{' '}
                                for takedown contacts.
                            </p>
                        </div>
                    </div>
                </div>
            </section>

            {/* Cross-device install */}
            <section className="mx-auto max-w-[90rem] px-4 py-16 sm:px-6">
                <div className="ring-grad relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-card via-card to-secondary p-8 sm:p-12">
                    <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-accent/15 blur-3xl" aria-hidden="true" />
                    <div className="pointer-events-none absolute -left-20 bottom-0 h-64 w-64 rounded-full bg-primary/15 blur-3xl" aria-hidden="true" />
                    <div className="relative z-10 grid items-center gap-8 lg:grid-cols-2">
                        <div>
                            <Reveal>
                                <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">
                                    <Sparkles className="h-3.5 w-3.5" aria-hidden="true" /> Every screen
                                </p>
                            </Reveal>
                            <Reveal delay={0.05}>
                                <h2 className="font-display text-3xl font-bold sm:text-4xl">
                                    Install ApX Player on <span className="text-grad">any device</span>.
                                </h2>
                            </Reveal>
                            <Reveal delay={0.1}>
                                <p className="mt-4 max-w-xl text-base leading-relaxed text-foreground/80">
                                    Add ApX Player to your Home Screen or app drawer and it opens full-screen like a native app —
                                    iPhone, iPad, Android phones &amp; tablets, desktop browsers, and Android TV with remote navigation.
                                </p>
                            </Reveal>
                            <Reveal delay={0.15}>
                                <div className="mt-6 flex flex-wrap gap-3">
                                    <button
                                        type="button"
                                        onClick={() => window.dispatchEvent(new CustomEvent('apx-open-install'))}
                                        className="focus-glow inline-flex min-h-[52px] items-center gap-2.5 rounded-full grad-ax px-7 text-base font-semibold text-primary-foreground shadow-[0_0_24px_hsl(187_95%_55%/0.45)] transition-transform hover:scale-[1.03] active:scale-[0.98]"
                                    >
                                        <Download className="h-5 w-5" aria-hidden="true" /> Install ApX Player
                                    </button>
                                    <a
                                        href="https://maruyatvph.com/apx/ApX.apk"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="focus-glow inline-flex min-h-[52px] items-center gap-2.5 rounded-full border border-white/20 bg-white/10 px-7 text-base font-semibold backdrop-blur transition-colors hover:bg-white/20 active:scale-[0.98]"
                                    >
                                        <Smartphone className="h-5 w-5" aria-hidden="true" /> Android APK
                                    </a>
                                </div>
                            </Reveal>
                        </div>
                        <Reveal delay={0.2}>
                            <ul className="grid gap-3 sm:grid-cols-2">
                                {[
                                    { icon: Apple, label: 'iPhone & iPad', detail: 'Add to Home Screen from Safari' },
                                    { icon: Smartphone, label: 'Android', detail: 'APK or browser install' },
                                    { icon: Monitor, label: 'Desktop', detail: 'Install from Chrome or Edge' },
                                    { icon: Tv, label: 'Android TV', detail: 'Remote & D-pad navigation' },
                                ].map((d) => (
                                    <li key={d.label} className="flex items-start gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
                                        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary">
                                            <d.icon className="h-5 w-5" aria-hidden="true" />
                                        </span>
                                        <div className="min-w-0">
                                            <p className="text-sm font-semibold text-foreground">{d.label}</p>
                                            <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{d.detail}</p>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        </Reveal>
                    </div>
                </div>
            </section>

            <style>{`@keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }`}</style>
        </Layout>
    );
};

export default HomePage;
