import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { ArrowLeft, Radio, Search, Tv, X } from 'lucide-react';
import Layout from '@/components/Layout';
import ShakaPlayer from '@/components/ShakaPlayer';
import { ErrorState, LoadingState } from '@/components/StateBlocks';
import { getLiveChannels, getConvergeChannels } from '@/lib/livetv';
import { cn } from '@/lib/utils';

const SOURCES = ['all', 'Cignal', 'Converge'];

const LiveTVPage = () => {
    const [channels, setChannels] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [errors, setErrors] = useState([]); // per-source soft failures

    const [query, setQuery] = useState('');
    const [source, setSource] = useState('all');
    const [group, setGroup] = useState('all');
    const [active, setActive] = useState(null); // selected channel

    const load = async () => {
        setLoading(true);
        setError('');
        setErrors([]);
        try {
            // Load both providers in parallel; a single provider failing
            // should not blank out the whole grid.
            const results = await Promise.allSettled([
                getLiveChannels(),
                getConvergeChannels(),
            ]);

            const merged = [];
            const softErrors = [];

            results.forEach((r, i) => {
                const name = i === 0 ? 'Cignal' : 'Converge';
                if (r.status === 'fulfilled') {
                    merged.push(...r.value.channels);
                } else {
                    softErrors.push(
                        `${name} channels could not be loaded (${r.reason?.message || 'unknown error'}).`,
                    );
                }
            });

            setChannels(merged);
            setErrors(softErrors);

            if (merged.length === 0 && softErrors.length > 0) {
                setError('Could not load any Live TV channels right now.');
            }
        } catch (err) {
            setError(err?.message || 'Could not load the Live TV channel list.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
    }, []);

    // Groups available within the currently selected source.
    const groups = useMemo(() => {
        const set = new Set();
        for (const c of channels) {
            if (source !== 'all' && c.source !== source) continue;
            set.add(c.group || 'Other');
        }
        return Array.from(set).sort((a, b) => a.localeCompare(b));
    }, [channels, source]);

    // Reset group if it's no longer valid for the current source.
    useEffect(() => {
        if (group !== 'all' && !groups.includes(group)) {
            setGroup('all');
        }
    }, [groups, group]);

    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase();
        return channels.filter((c) => {
            if (source !== 'all' && c.source !== source) return false;
            if (group !== 'all' && (c.group || 'Other') !== group) return false;
            if (q && !c.name.toLowerCase().includes(q)) return false;
            return true;
        });
    }, [channels, query, source, group]);

    return (
        <Layout>
            <Helmet>
                <title>Live TV — ApX Player</title>
                <meta
                    name="description"
                    content="Watch live TV channels on ApX Player by MaruyaTVPH. Browse Cignal and Converge channels in one grid, filter by provider or group, and play any channel in the built-in Shaka player."
                />
            </Helmet>

            <div className="mx-auto max-w-[95rem] px-4 py-8 sm:px-6">
                <header className="mb-8">
                    <p className="mb-3 inline-flex items-center gap-2 rounded-sm border border-primary/40 bg-primary/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">
                        <Radio className="h-3.5 w-3.5" aria-hidden="true" /> Live TV
                    </p>
                    <h1 className="display text-5xl sm:text-6xl">Live TV Channels</h1>
                    <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">
                        Stream live channels from Cignal and Converge in the built-in Shaka player.
                        Search by name, filter by provider or group, then click any channel to start watching.
                    </p>
                </header>

                {/* Active player */}
                {active && (
                    <section className="mb-10">
                        <div className="mb-3 flex items-center justify-between gap-4">
                            <button
                                type="button"
                                onClick={() => setActive(null)}
                                className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
                            >
                                <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back to channels
                            </button>
                            <h2 className="display truncate text-2xl">{active.name}</h2>
                        </div>
                        <ShakaPlayer
                            key={active.url}
                            url={active.url}
                            clearkey={active.clearkey}
                            title={active.name}
                            logo={active.logo}
                        />
                        <p className="mt-3 text-xs text-muted-foreground">
                            Now playing: <span className="text-foreground">{active.name}</span>
                            {active.source ? ` · ${active.source}` : ''}
                            {active.group ? ` · ${active.group}` : ''}
                        </p>
                    </section>
                )}

                {/* Controls */}
                <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                    <div className="relative max-w-md flex-1">
                        <Search
                            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
                            aria-hidden="true"
                        />
                        <input
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            placeholder="Search channels"
                            className="h-11 w-full rounded-sm border border-border bg-secondary/60 pl-9 pr-9 text-sm placeholder:text-muted-foreground"
                        />
                        {query && (
                            <button
                                type="button"
                                onClick={() => setQuery('')}
                                className="absolute right-2 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-sm text-muted-foreground hover:text-foreground"
                                aria-label="Clear search"
                            >
                                <X className="h-4 w-4" aria-hidden="true" />
                            </button>
                        )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                        {SOURCES.map((s) => (
                            <FilterChip
                                key={s}
                                label={s === 'all' ? 'All providers' : s}
                                active={source === s}
                                onClick={() => {
                                    setSource(s);
                                    setGroup('all');
                                }}
                            />
                        ))}
                    </div>
                </div>

                {/* Group filter */}
                {groups.length > 0 && (
                    <div className="mb-6 flex flex-wrap gap-2">
                        <FilterChip label="All groups" active={group === 'all'} onClick={() => setGroup('all')} />
                        {groups.map((g) => (
                            <FilterChip
                                key={g}
                                label={g}
                                active={group === g}
                                onClick={() => setGroup(g)}
                            />
                        ))}
                    </div>
                )}

                {/* Soft per-source errors */}
                {errors.length > 0 && !loading && (
                    <div className="mb-6 rounded-sm border border-border bg-secondary/40 p-3 text-xs text-muted-foreground">
                        {errors.map((e, i) => (
                            <p key={i}>{e}</p>
                        ))}
                    </div>
                )}

                {/* Channel grid */}
                {loading ? (
                    <LoadingState label="Loading channels…" />
                ) : error ? (
                    <ErrorState message={error} onRetry={load} />
                ) : filtered.length === 0 ? (
                    <div className="grid place-items-center py-24 text-center">
                        <Tv className="mb-3 h-10 w-10 text-muted-foreground" aria-hidden="true" />
                        <p className="text-sm text-muted-foreground">
                            No channels match your search. Try a different name, provider, or group.
                        </p>
                    </div>
                ) : (
                    <>
                        <p className="mb-4 text-xs text-muted-foreground">
                            {filtered.length} channel{filtered.length === 1 ? '' : 's'}
                        </p>
                        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                            {filtered.map((c, idx) => (
                                <ChannelCard
                                    key={`${c.source}-${c.tvgId || c.name}-${idx}`}
                                    channel={c}
                                    active={active?.url === c.url}
                                    onSelect={() => {
                                        setActive(c);
                                        window.scrollTo({ top: 0, behavior: 'smooth' });
                                    }}
                                />
                            ))}
                        </div>
                    </>
                )}
            </div>
        </Layout>
    );
};

const FilterChip = ({ label, active, onClick }) => (
    <button
        type="button"
        onClick={onClick}
        className={cn(
            'rounded-sm border px-3 py-1.5 text-xs font-medium transition-colors',
            active
                ? 'border-primary bg-primary/15 text-primary'
                : 'border-border text-muted-foreground hover:border-primary/50 hover:text-foreground',
        )}
    >
        {label}
    </button>
);

const ChannelCard = ({ channel, active, onSelect }) => (
    <button
        type="button"
        onClick={onSelect}
        className={cn(
            'group flex flex-col overflow-hidden rounded-sm border bg-card text-left transition-colors',
            active ? 'border-primary' : 'border-border hover:border-primary/60',
        )}
    >
        <div className="relative aspect-video w-full overflow-hidden bg-black/60">
            {channel.logo ? (
                <img
                    src={channel.logo}
                    alt=""
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-contain p-3 transition-transform group-hover:scale-105"
                    onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.parentElement.classList.add('no-logo');
                    }}
                />
            ) : null}
            <div className="absolute inset-0 grid place-items-center">
                {!channel.logo && <Tv className="h-8 w-8 text-muted-foreground/40" aria-hidden="true" />}
            </div>
            <div className="absolute left-2 top-2 flex items-center gap-1 rounded-sm bg-black/70 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-primary">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" /> Live
            </div>
            {channel.source && (
                <div className="absolute right-2 top-2 rounded-sm bg-black/70 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-foreground/80">
                    {channel.source}
                </div>
            )}
        </div>
        <div className="p-2.5">
            <p className="truncate text-sm font-semibold">{channel.name}</p>
            {channel.group && (
                <p className="mt-0.5 truncate text-[11px] text-muted-foreground">{channel.group}</p>
            )}
        </div>
    </button>
);

export default LiveTVPage;
