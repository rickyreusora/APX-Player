import React, { useCallback, useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal } from 'lucide-react';
import Layout from '@/components/Layout';
import TitleCard from '@/components/TitleCard';
import { EmptyState, ErrorState, SkeletonGrid } from '@/components/StateBlocks';
import { useAuth } from '@/contexts/AuthContext';
import {
    SORT_OPTIONS,
    CATEGORIES,
    COMPANY_CATEGORIES,
    getCategoryById,
    isCompanyCategory,
    isGenreCategory,
    isUserListCategory,
    listCategoryTitles,
} from '@/lib/catalog';

const PER_PAGE = 20;

// Pills render in the order defined by CATEGORIES, with an implicit "All" first.
const PILL_LIST = [{ id: 'all', label: 'All' }, ...CATEGORIES];

const HEADING_LABELS = {
    all: 'everything',
    trending: 'trending',
    favorites: 'your favourites',
    last_watched: 'last watched',
    tv: 'TV series',
    livetv: 'live TV',
};

const BrowsePage = () => {
    const [params, setParams] = useSearchParams();
    const navigate = useNavigate();
    const { user } = useAuth();

    const [items, setItems] = useState([]);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalItems, setTotalItems] = useState(0);
    const [loading, setLoading] = useState(true);
    const [loadingMore, setLoadingMore] = useState(false);
    const [error, setError] = useState('');

    const q = params.get('q') || '';
    const kind = params.get('kind') || 'all';
    const sort = params.get('sort') || 'popular';
    // Prefer ?category=; accept legacy ?genre= (home genre chips / old links).
    const category = params.get('category') || params.get('genre') || 'all';

    const cat = getCategoryById(category);
    const isCompany = isCompanyCategory(category);
    const isGenre = isGenreCategory(category);
    const isUserList = isUserListCategory(category);
    const isTvOnly = category === 'tv';
    const isLivetv = category === 'livetv';

    // Live TV lives on its own page — redirect when its pill is selected.
    useEffect(() => {
        if (isLivetv) navigate('/livetv', { replace: true });
    }, [isLivetv, navigate]);

    const setParam = (key, value) => {
        const next = new URLSearchParams(params);
        if (!value || value === 'all' || value === '') next.delete(key);
        else next.set(key, value);
        setParams(next, { replace: true });
    };

    const setCategory = (value) => {
        const next = new URLSearchParams(params);
        if (!value || value === 'all') next.delete('category');
        else next.set('category', value);
        // Company / genre / special categories drive their own fetch; clear
        // incompatible filters so the result set stays coherent.
        if (value !== 'all') {
            next.delete('q');
        }
        // TV Series category forces series kind.
        if (value === 'tv') {
            next.set('kind', 'series');
        } else if (next.get('kind') === 'series' && value === 'all') {
            next.delete('kind');
        }
        setParams(next, { replace: true });
    };

    const fetchPage = useCallback(
        async (targetPage, append) => {
            append ? setLoadingMore(true) : setLoading(true);
            setError('');
            try {
                const res = await listCategoryTitles(category, user?.id, {
                    search: q,
                    kind,
                    sort,
                    page: targetPage,
                    perPage: PER_PAGE,
                });
                setItems((prev) => (append ? [...prev, ...res.items] : res.items));
                setPage(res.page);
                setTotalPages(res.totalPages);
                setTotalItems(res.totalItems);
            } catch (err) {
                if (err?.status !== 0) setError(err?.notConfigured ? 'TMDB is not configured yet.' : err?.message || 'Could not load titles.');
            } finally {
                setLoadingMore(false);
                setLoading(false);
            }
        },
        [q, kind, sort, category, user?.id],
    );

    useEffect(() => {
        if (isLivetv) return;
        fetchPage(1, false);
    }, [fetchPage, isLivetv]);

    // User lists and company/genre categories refine via Type + Sort; search is
    // only meaningful for the catalogue-backed categories.
    const searchDisabled = isCompany || isGenre || isUserList || isTvOnly;
    const heading =
        HEADING_LABELS[category] ||
        (cat ? cat.label : isGenre ? `genre ${category}` : 'everything');

    if (isLivetv) {
        return (
            <Layout>
                <div className="py-24 text-center text-sm text-muted-foreground">Opening Live TV…</div>
            </Layout>
        );
    }

    return (
        <Layout>
            <Helmet>
                <title>Browse the Catalogue | ApX Player</title>
                <meta
                    name="description"
                    content="Search and filter the full ApX Player catalogue of movies and TV series powered by TMDB."
                />
            </Helmet>

            <div className="mx-auto max-w-[90rem] px-4 pb-20 pt-12 sm:px-6">
                <header className="mb-8">
                    <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">Catalogue</p>
                    <h1 className="font-display text-5xl font-extrabold sm:text-6xl">Browse <span className="text-grad">{heading}</span></h1>
                    <p className="mt-3 max-w-2xl text-sm text-muted-foreground">
                        {totalItems} {totalItems === 1 ? 'title' : 'titles'} found.
                    </p>
                </header>

                {/* Category pills */}
                <div className="mb-6 flex flex-wrap gap-2.5">
                    {PILL_LIST.map((p) => {
                        const active = category === p.id;
                        const label = p.label;
                        return (
                            <button
                                key={p.id}
                                type="button"
                                onClick={() => setCategory(p.id)}
                                className={
                                    'focus-glow inline-flex items-center rounded-full border px-4 py-2 text-sm font-medium transition-all hover:scale-[1.04] ' +
                                    (active
                                        ? 'border-transparent grad-ax text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.35)]'
                                        : 'border-white/10 bg-white/5 text-foreground/90 hover:border-white/20')
                                }
                            >
                                {label}
                            </button>
                        );
                    })}
                </div>

                {/* Refinement bar — hidden for user lists (no server filters apply). */}
                {!isUserList && (
                    <div className="mb-8 rounded-sm border border-border bg-card/50 p-4">
                        <div className="flex flex-col gap-4 lg:flex-row lg:items-end">
                            <div className="flex-1">
                                <label htmlFor="browse-search" className="mb-1.5 block text-xs font-medium text-muted-foreground">
                                    Search
                                </label>
                                <div className="relative">
                                    <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                                    <input
                                        id="browse-search"
                                        type="search"
                                        value={q}
                                        onChange={(e) => setParam('q', e.target.value)}
                                        disabled={searchDisabled}
                                        placeholder={searchDisabled ? 'Search disabled for this category' : 'Search movies and series'}
                                        className="h-11 w-full rounded-sm border border-border bg-secondary/60 pl-9 pr-3 text-sm disabled:opacity-50"
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                                <div>
                                    <label htmlFor="f-kind" className="mb-1.5 block text-xs font-medium text-muted-foreground">
                                        Type
                                    </label>
                                    <select
                                        id="f-kind"
                                        value={isTvOnly ? 'series' : kind}
                                        onChange={(e) => setParam('kind', e.target.value)}
                                        disabled={isTvOnly}
                                        className="h-11 w-full rounded-sm border border-border bg-secondary/60 px-2 text-sm disabled:opacity-50"
                                    >
                                        <option value="all">All types</option>
                                        <option value="movie">Movies</option>
                                        <option value="series">Series</option>
                                    </select>
                                </div>
                                <div className="col-span-2 sm:col-span-1">
                                    <label htmlFor="f-sort" className="mb-1.5 block text-xs font-medium text-muted-foreground">
                                        Sort
                                    </label>
                                    <select
                                        id="f-sort"
                                        value={sort}
                                        onChange={(e) => setParam('sort', e.target.value)}
                                        className="h-11 w-full rounded-sm border border-border bg-secondary/60 px-2 text-sm"
                                    >
                                        {SORT_OPTIONS.map((o) => (
                                            <option key={o.value} value={o.value}>
                                                {o.label}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                        </div>
                        {(q || kind !== 'all' || category !== 'all') && (
                            <button
                                type="button"
                                onClick={() => setParams(new URLSearchParams(), { replace: true })}
                                className="mt-4 inline-flex items-center gap-1.5 text-xs font-medium text-primary hover:underline"
                            >
                                <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" /> Clear all filters
                            </button>
                        )}
                        {isCompany ? (
                            <p className="mt-3 text-[11px] text-muted-foreground">
                                Showing {COMPANY_CATEGORIES[category].label} titles from TMDB production company {COMPANY_CATEGORIES[category].companyId}. Use Type and Sort to refine. Premium access required to play.
                            </p>
                        ) : isGenre ? (
                            <p className="mt-3 text-[11px] text-muted-foreground">
                                Showing {cat.label} titles. Use Type and Sort to refine.
                            </p>
                        ) : isTvOnly ? (
                            <p className="mt-3 text-[11px] text-muted-foreground">
                                Showing TV series. Use Sort to reorder.
                            </p>
                        ) : null}
                    </div>
                )}

                {loading && <SkeletonGrid />}

                {!loading && error && <ErrorState message={error} onRetry={() => fetchPage(1, false)} />}

                {!loading && !error && items.length === 0 && (
                    <EmptyState
                        title={isUserList ? 'Nothing here yet' : 'No titles match your filters'}
                        description={
                            isUserList
                                ? category === 'favorites'
                                    ? 'Titles you favourite will appear here. Browse the catalogue and tap the heart on any title.'
                                    : 'Titles you start watching will show up here so you can jump back in.'
                                : 'Try a different search term, or clear the filters to see the whole catalogue.'
                        }
                        action={
                            <Link
                                to="/browse"
                                onClick={() => setParams(new URLSearchParams(), { replace: true })}
                                className="focus-glow inline-block rounded-full grad-ax px-5 py-2.5 text-sm font-semibold text-primary-foreground"
                            >
                                Reset filters
                            </Link>
                        }
                    />
                )}

                {!loading && !error && items.length > 0 && (
                    <>
                        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
                            {items.map((t) => (
                                <TitleCard
                                    key={`${t.kind || 'movie'}-${t.tmdb_id || t.id}`}
                                    title={t}
                                    premium={isCompany}
                                    progressPercent={t.progressPercent ?? null}
                                />
                            ))}
                        </div>
                        {page < totalPages && (
                            <div className="mt-12 text-center">
                                <button
                                    type="button"
                                    disabled={loadingMore}
                                    onClick={() => fetchPage(page + 1, true)}
                                    className="min-h-[48px] rounded-sm border border-primary px-8 text-sm font-semibold text-primary transition-colors hover:bg-primary hover:text-primary-foreground disabled:opacity-60"
                                >
                                    {loadingMore ? 'Loading…' : `Load more (page ${page + 1} of ${totalPages})`}
                                </button>
                            </div>
                        )}
                    </>
                )}
            </div>
        </Layout>
    );
};

export default BrowsePage;
