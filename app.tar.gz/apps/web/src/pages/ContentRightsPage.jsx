import React from 'react';
import { Helmet } from 'react-helmet';
import Layout from '@/components/Layout';
import DocPage from '@/components/DocPage';

const ContentRightsPage = () => (
    <Layout>
        <Helmet>
            <title>Content Rights and DMCA Notice | ApX Player</title>
            <meta name="description" content="ApX Player by MaruyaTVPH content rights policy, publication requirements, and DMCA notice and takedown procedure for reporting unauthorized content." />
        </Helmet>
        <DocPage
            kicker="Legal"
            heading="Content Rights & DMCA"
            lastUpdated="October 7, 2026"
            intro="ApX Player, operated by MaruyaTVPH, respects the intellectual property rights of others and expects users and administrators to do the same. This page explains our content rights policy and the Digital Millennium Copyright Act (DMCA) notice and takedown process for reporting content you believe infringes your rights."
            sections={[
                {
                    title: 'Our content policy',
                    body: [
                        'ApX Player only streams or provides access to content that the site operator is legally authorized to distribute. We do not host pirated content, and we include no scraping, no third-party stream importing, no torrent integration, and no tooling that circumvents technical protection measures. Media sources must be uploaded or supplied by the rights holder or made available through authorized services.',
                    ],
                },
                {
                    title: 'Publication requirements',
                    body: [
                        'Before a title can be published, an administrator must record the rights holder, a licence or agreement reference, and confirm that valid distribution rights are held for the title and every media source attached to it. Titles without that confirmation remain in draft and are never visible to viewers.',
                    ],
                },
                {
                    title: 'Third-party and embedded content',
                    body: [
                        'Some content on the Service is embedded from or delivered through authorized third-party providers (such as YouTube). We do not host or control this content; it remains subject to the terms and policies of the originating provider. If embedded content is removed at its source, it will no longer be available on the Service.',
                    ],
                },
                {
                    title: 'DMCA notice of infringement',
                    body: [
                        'If you believe that content available on the Service infringes a copyright you own or control, you may submit a DMCA takedown notice. To be effective under the DMCA, your notice must include the following in writing:',
                    ],
                    list: [
                        'A physical or electronic signature of the copyright owner or a person authorized to act on their behalf.',
                        'Identification of the copyrighted work claimed to have been infringed (or a representative list if multiple works are involved).',
                        'Identification of the specific material that is claimed to be infringing, including the exact URL or location on the Service so we can locate it.',
                        'Your contact information, including your full name, address, telephone number, and email address.',
                        'A statement that you have a good-faith belief that the disputed use is not authorized by the copyright owner, its agent, or the law.',
                        'A statement, made under penalty of perjury, that the information in your notice is accurate and that you are the copyright owner or authorized to act on the owner’s behalf.',
                    ],
                },
                {
                    title: 'Where to send a notice',
                    body: [
                        'Send your DMCA notice to the contact details on our Contact page, or by email to support@moviepinas.com or admin@maruyatvph.com, with the subject line “DMCA Takedown Notice.” We will review and respond to valid notices in accordance with applicable law.',
                    ],
                },
                {
                    title: 'Our response process',
                    body: [
                        'Upon receiving a valid notice, we will remove or disable access to the disputed material and make a good-faith effort to notify the party who posted or authorized it. Disputed titles are unpublished while the claim is reviewed. Repeat infringers may have their access terminated.',
                    ],
                },
                {
                    title: 'Counter-notice',
                    body: [
                        'If you believe your content was removed or disabled in error or misidentification, you may submit a counter-notice that includes:',
                    ],
                    list: [
                        'Your physical or electronic signature.',
                        'Identification of the material that was removed and the location at which it appeared before removal.',
                        'A statement under penalty of perjury that you have a good-faith belief the material was removed or disabled as a result of mistake or misidentification.',
                        'Your name, address, telephone number, and email address, and a statement that you consent to the jurisdiction of the federal courts located in the relevant district (or, if outside the United States, the appropriate jurisdiction) and that you will accept service of process from the person who submitted the original notice.',
                    ],
                },
                {
                    title: 'Repeat infringers',
                    body: [
                        'In accordance with the DMCA, we maintain a policy of terminating, in appropriate circumstances, the accounts of users who are determined to be repeat infringers.',
                    ],
                },
                {
                    title: 'False or fraudulent notices',
                    body: [
                        'Filing a false or fraudulent DMCA notice may result in liability for damages under applicable law, including any damages incurred by the alleged infringer or by us. We may reject notices that are incomplete, abusive, or fraudulent.',
                    ],
                },
                {
                    title: 'Contact',
                    body: [
                        'Questions about this policy or a specific notice can be sent to support@moviepinas.com or admin@maruyatvph.com, or through the details on our Contact page.',
                    ],
                },
            ]}
        />
    </Layout>
);

export default ContentRightsPage;
