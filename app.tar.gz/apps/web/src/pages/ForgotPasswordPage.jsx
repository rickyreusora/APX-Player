import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { useAuth } from '@/contexts/AuthContext';

const ForgotPasswordPage = () => {
    const { requestPasswordReset } = useAuth();
    const [email, setEmail] = useState('');
    const [busy, setBusy] = useState(false);
    const [sent, setSent] = useState(false);
    const [error, setError] = useState('');

    const onSubmit = async (e) => {
        e.preventDefault();
        setError('');
        if (!email) return setError('Enter the email address on your account.');
        setBusy(true);
        try {
            await requestPasswordReset(email);
            setSent(true);
        } catch (err) {
            setError(err?.message || 'Could not send the reset email.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <Layout>
            <Helmet>
                <title>Reset Your Password | ApX Player</title>
                <meta name="description" content="Request a password reset link for your ApX Player account." />
            </Helmet>
            <div className="mx-auto max-w-md px-4 py-20 sm:px-6">
                <h1 className="display text-5xl">Reset password</h1>
                {sent ? (
                    <div className="mt-6 rounded-sm border border-primary/40 bg-primary/10 p-5 text-sm" role="status">
                        If an account exists for <strong>{email}</strong>, a reset link is on its way. Open the link from
                        your inbox to choose a new password.
                    </div>
                ) : (
                    <>
                        <p className="mt-2 text-sm text-muted-foreground">
                            We will email you a secure link to set a new password.
                        </p>
                        <form onSubmit={onSubmit} className="mt-8 space-y-5" noValidate>
                            <div className="flex flex-col gap-2">
                                <label htmlFor="email" className="text-sm font-medium">
                                    Email
                                </label>
                                <input
                                    id="email"
                                    type="email"
                                    autoComplete="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    className="h-12 rounded-sm border border-border bg-secondary/50 px-3 text-sm"
                                    required
                                />
                            </div>
                            {error && (
                                <p role="alert" className="rounded-sm border border-destructive/40 bg-destructive/10 p-3 text-sm">
                                    {error}
                                </p>
                            )}
                            <button type="submit" disabled={busy} className="min-h-[48px] w-full rounded-sm bg-primary text-sm font-semibold text-primary-foreground active:scale-[0.99] disabled:opacity-60">
                                {busy ? 'Sending…' : 'Send reset link'}
                            </button>
                        </form>
                    </>
                )}
                <p className="mt-6 text-sm text-muted-foreground">
                    <Link to="/login" className="text-primary underline underline-offset-4">
                        Back to sign in
                    </Link>
                </p>
            </div>
        </Layout>
    );
};

export default ForgotPasswordPage;
