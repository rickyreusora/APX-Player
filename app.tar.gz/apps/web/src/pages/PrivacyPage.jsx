import React from 'react';
import { Helmet } from 'react-helmet';
import Layout from '@/components/Layout';
import DocPage from '@/components/DocPage';

const PrivacyPage = () => (
    <Layout>
        <Helmet>
            <title>Privacy Policy | ApX Player</title>
            <meta name="description" content="Privacy Policy for ApX Player by MaruyaTVPH — how we collect, use, store, and protect your personal information, including advertising and third-party services like Google AdSense." />
        </Helmet>
        <DocPage
            kicker="Legal"
            heading="Privacy Policy"
            lastUpdated="October 7, 2026"
            intro="This Privacy Policy explains how ApX Player, operated by MaruyaTVPH (“we,” “us,” or “our”), collects, uses, discloses, and safeguards your information when you use our website and services at moviepinas.com and related domains (maruyatvph.com, maruyatvph.org) (the “Service”). We are committed to protecting your privacy and being transparent about how your data is handled."
            sections={[
                {
                    title: 'Information we collect',
                    body: [
                        'We collect information you provide directly to us and information collected automatically when you use the Service.',
                    ],
                    list: [
                        'Account information: When you create an account, we collect your email address, display name, and a hashed password. If you sign in with Google, we receive the name and email address associated with your Google account.',
                        'Usage data: We may collect information about how you interact with the Service, such as the titles you view, your watch history and playback progress, favorites, playlists, search queries, and the device, browser, and operating system you use.',
                        'Transaction data: When you make a payment (such as a credit top-up or premium donation), we collect the payment details you submit (for example, sender name and reference number) and proof-of-payment images. We do not store full payment card numbers.',
                        'Technical data: We may automatically collect your IP address, device identifiers, and similar information through cookies and similar technologies (see “Cookies and tracking technologies” below).',
                    ],
                },
                {
                    title: 'How we use your information',
                    body: ['We use the information we collect for the following purposes:'],
                    list: [
                        'To provide, operate, and maintain the Service, including account access, playback, and karaoke features.',
                        'To process payments, verify transactions, and grant premium access after approval.',
                        'To personalize content, remember your preferences, and improve your experience.',
                        'To monitor and analyze usage so we can improve the Service and detect, prevent, and address technical issues, fraud, or abuse.',
                        'To communicate with you about your account, updates, security alerts, and support requests.',
                        'To display advertising and measure ad performance (see “Advertising and Google AdSense” below).',
                    ],
                },
                {
                    title: 'Cookies and tracking technologies',
                    body: [
                        'We and our service providers use cookies, web beacons, and similar technologies to operate the Service, remember your preferences, measure traffic, and serve and analyze advertising. Cookies are small text files stored on your device.',
                        'You can control or delete cookies through your browser settings. Disabling cookies may affect some features of the Service, such as keeping you signed in.',
                    ],
                },
                {
                    title: 'Advertising and Google AdSense',
                    body: [
                        'We use third-party advertising vendors, including Google AdSense, to display ads on the Service. Google and its partners use cookies to serve ads based on your prior visits to this and other websites.',
                        'Google’s use of advertising cookies enables it and its partners to serve ads to you based on your visit to our site and/or other sites on the internet. You may opt out of personalized advertising by visiting Google’s Ads Settings page (adssettings.google.com) or by opting out of third-party vendor cookies through www.aboutads.info.',
                        'Third-party advertising vendors and ad networks may also use cookies to serve ads. We do not control these third-party cookies and their use is subject to the respective providers’ privacy policies.',
                    ],
                },
                {
                    title: 'Third-party services',
                    body: [
                        'The Service integrates with third-party services that may collect information governed by their own privacy policies. These include, but are not limited to:',
                    ],
                    list: [
                        'Google AdSense and related Google advertising products for ad delivery and measurement.',
                        'Google OAuth for account sign-in.',
                        'YouTube and other content providers for media playback and karaoke content.',
                        'Payment providers (such as GCash) for processing payments; payment card data is handled by the provider, not stored by us.',
                        'Email-marketing and analytics services that help us operate and improve the Service.',
                    ],
                },
                {
                    title: 'How we share your information',
                    body: [
                        'We do not sell your personal information. We may share information with: (a) service providers who perform services on our behalf (such as hosting, payments, analytics, and email delivery); (b) advertising partners as described above; (c) authorities or third parties when required by law, court order, or to protect our rights, safety, or property; and (d) successors in the event of a merger, acquisition, or asset transfer.',
                        'When you sign up, your email address and name may be added to our email-marketing audience so we can send you updates. You can unsubscribe from marketing emails at any time using the link in each email.',
                    ],
                },
                {
                    title: 'How we protect your information',
                    body: [
                        'We use reasonable administrative, technical, and physical safeguards designed to protect your personal information. Personal records (such as watch history, favorites, and playlists) are readable and writable only by the account that owns them, enforced at the database access-rule level. Administrators can manage catalogue content but do not have access to individual viewing records.',
                        'No method of transmission over the internet or electronic storage is completely secure. While we strive to protect your information, we cannot guarantee absolute security.',
                    ],
                },
                {
                    title: 'Data retention',
                    body: [
                        'We retain your information for as long as your account is active or as needed to provide the Service. We also retain and use information as necessary to comply with legal obligations, resolve disputes, and enforce our agreements. You may request deletion of your account and associated data at any time (see “Your privacy rights” below).',
                    ],
                },
                {
                    title: 'Your privacy rights',
                    body: [
                        'Depending on your location, you may have rights regarding your personal information, including the right to access, correct, or delete it, and to object to or restrict certain processing. You can edit your profile, delete individual history entries, favorites, and playlists at any time, and submit an account deletion request from your account page or by contacting us.',
                    ],
                },
                {
                    title: "Children's privacy",
                    body: [
                        'The Service is not directed to children under 13 (or the minimum age required in your jurisdiction), and we do not knowingly collect personal information from children. If you believe a child has provided us with personal information, please contact us so we can delete it.',
                    ],
                },
                {
                    title: 'International data transfers',
                    body: [
                        'Your information may be transferred to and processed in countries other than your own, including countries that may have different data protection laws. Where required, we take steps to ensure such transfers comply with applicable law.',
                    ],
                },
                {
                    title: 'Changes to this policy',
                    body: [
                        'We may update this Privacy Policy from time to time. When we do, we will revise the “Last updated” date at the top of this page. We encourage you to review this page periodically. Material changes will be communicated through the Service or by other means where appropriate.',
                    ],
                },
                {
                    title: 'Contact us',
                    body: [
                        'If you have questions about this Privacy Policy or our data practices, contact us at support@moviepinas.com or admin@maruyatvph.com, or use the details on our Contact page.',
                    ],
                },
            ]}
        />
    </Layout>
);

export default PrivacyPage;
