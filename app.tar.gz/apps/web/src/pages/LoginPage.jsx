import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { toast } from 'sonner';
import Layout from '@/components/Layout';
import GoogleSignInButton from '@/components/GoogleSignInButton';
import { useGoogleAuth } from '@/hooks/useGoogleAuth';
import { useAuth } from '@/contexts/AuthContext';

const LoginPage = () => {
    const { login, loginWithGoogle, isAuthed } = useAuth();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const { available: googleAvailable } = useGoogleAuth();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [busy, setBusy] = useState(false);
    const [googleBusy, setGoogleBusy] = useState(false);
    const [error, setError] = useState('');

    if (isAuthed) return <Navigate to="/dashboard" replace />;

    const onSubmit = async (e) => {
        e.preventDefault();
        setError('');
        if (!email || !password) {
            setError('Enter your email and password.');
            return;
        }
        setBusy(true);
        try {
            await login(email, password);
            toast.success('Welcome back');
            const returnTo = searchParams.get('return_to');
            navigate(returnTo && returnTo.startsWith('/') ? returnTo : '/dashboard');
        } catch (err) {
            setError(err?.status === 400 ? 'Incorrect email or password.' : err?.message || 'Sign in failed.');
        } finally {
            setBusy(false);
        }
    };

    const onGoogle = async () => {
        setGoogleBusy(true);
        setError('');
        try {
            await loginWithGoogle();
            toast.success('Welcome back');
            const returnTo = searchParams.get('return_to');
            navigate(returnTo && returnTo.startsWith('/') ? returnTo : '/dashboard');
        } catch (err) {
            setError(err?.message || 'Google sign-in was cancelled or failed.');
        } finally {
            setGoogleBusy(false);
        }
    };

    return (
        <Layout>
            <Helmet>
                <title>Sign In | ApX Player</title>
                <meta name="description" content="Sign in to your ApX Player account to resume watching, manage favourites and playlists." />
            </Helmet>
            <div className="mx-auto max-w-md px-4 py-20 sm:px-6">
                <div className="mb-2 h-1.5 w-16 rounded-full grad-ax" aria-hidden="true" />
                <h1 className="font-display text-5xl font-extrabold">Sign <span className="text-grad">in</span></h1>
                <p className="mt-2 text-sm text-muted-foreground">Resume watching where you left off.</p>

                {googleAvailable && (
                    <div className="mt-8">
                        <GoogleSignInButton label="Continue with Google" onClick={onGoogle} busy={googleBusy} />
                        <div className="relative my-6">
                            <div className="absolute inset-0 flex items-center">
                                <div className="w-full border-t border-white/10" />
                            </div>
                            <div className="relative flex justify-center">
                                <span className="bg-background px-3 text-xs uppercase tracking-wider text-muted-foreground">or</span>
                            </div>
                        </div>
                    </div>
                )}

                <form onSubmit={onSubmit} className="space-y-5" noValidate>
                    <div className="flex flex-col gap-2">
                        <label htmlFor="email" className="text-sm font-medium">
                            Email
                        </label>
                        <input
                            id="email"
                            type="email"
                            autoComplete="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="focus-glow h-12 rounded-xl border border-white/10 bg-white/5 px-4 text-sm"
                            required
                        />
                    </div>
                    <div className="flex flex-col gap-2">
                        <label htmlFor="password" className="text-sm font-medium">
                            Password
                        </label>
                        <input
                            id="password"
                            type="password"
                            autoComplete="current-password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="focus-glow h-12 rounded-xl border border-white/10 bg-white/5 px-4 text-sm"
                            required
                        />
                    </div>
                    {error && (
                        <p role="alert" className="rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-sm">
                            {error}
                        </p>
                    )}
                    <button
                        type="submit"
                        disabled={busy}
                        className="focus-glow min-h-[48px] w-full rounded-full grad-ax text-sm font-semibold text-primary-foreground shadow-[0_0_20px_hsl(187_95%_55%/0.4)] transition-transform hover:scale-[1.02] active:scale-[0.98] disabled:opacity-60"
                    >
                        {busy ? 'Signing in…' : 'Sign in'}
                    </button>
                </form>

                <div className="mt-6 flex flex-col gap-2 text-sm text-muted-foreground">
                    <Link to="/forgot-password" className="hover:text-primary">
                        Forgot your password?
                    </Link>
                    <span>
                        New here?{' '}
                        <Link to="/signup" className="text-primary underline underline-offset-4">
                            Create an account
                        </Link>
                    </span>
                </div>
            </div>
        </Layout>
    );
};

export default LoginPage;
