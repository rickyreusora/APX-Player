import React, { useCallback, useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useSearchParams } from 'react-router-dom';
import { Clock, Crown, Heart, History, ListMusic, Play, Plus, Trash2, UserCog, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import Layout from '@/components/Layout';
import TitleCard from '@/components/TitleCard';
import TopUpModal from '@/components/TopUpModal';
import DonationModal from '@/components/DonationModal';
import { EmptyState, ErrorState, LoadingState } from '@/components/StateBlocks';
import { useAuth } from '@/contexts/AuthContext';
import pb from '@/lib/pocketbaseClient';
import { buildSlug, listFavorites, listPlaylistItems, listPlaylists, listProgress } from '@/lib/catalog';
import { getCredits, listCreditTransactions, notifyAndroidPaymentSuccess, TOPUP_AMOUNT } from '@/lib/credits';
import { isPremium as userIsPremium, listDonations, PREMIUM_MIN_DONATION, proofImageUrl } from '@/lib/premium';

const TABS = [
    { id: 'continue', label: 'Continue Watching', icon: Play },
    { id: 'history', label: 'Watch History', icon: History },
    { id: 'favorites', label: 'Favourites', icon: Heart },
    { id: 'playlists', label: 'Playlists', icon: ListMusic },
    { id: 'credits', label: 'Credits', icon: Wallet },
    { id: 'premium', label: 'Premium', icon: Crown },
    { id: 'profile', label: 'Profile & Account', icon: UserCog },
];

const TX_LABEL = {
    topup: { text: 'Top-up', tone: 'text-primary' },
    usage: { text: 'Karaoke session', tone: 'text-muted-foreground' },
    refund: { text: 'Refund', tone: 'text-primary' },
    adjustment: { text: 'Adjustment', tone: 'text-muted-foreground' },
};

const TX_STATUS = {
    pending_approval: { text: 'Pending approval', tone: 'text-amber-500' },
    completed: { text: 'Completed', tone: 'text-primary' },
    rejected: { text: 'Rejected', tone: 'text-destructive' },
    pending: { text: 'Pending', tone: 'text-muted-foreground' },
    failed: { text: 'Failed', tone: 'text-destructive' },
    reversed: { text: 'Reversed', tone: 'text-muted-foreground' },
};

// Convert a stored user record (favorite / playlist_item / progress) into the
// title shape TitleCard expects.
const recToTitle = (r) => ({
    id: r.tmdb_id,
    tmdb_id: r.tmdb_id,
    kind: r.kind,
    title: r.title_text || 'Untitled',
    slug: buildSlug(r.kind, r.tmdb_id),
    poster: r.poster || '',
    year: r.year || null,
    rating: null,
    duration_minutes: null,
});

const watchLink = (r) => {
    const base = `/watch/${buildSlug(r.kind, r.tmdb_id)}`;
    if (r.kind === 'series' && r.season) return `${base}?s=${r.season}&e=${r.episode || 1}`;
    return base;
};

const DashboardPage = () => {
    const { user, refreshUser, logout } = useAuth();
    const [tab, setTab] = useState('continue');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [progress, setProgress] = useState([]);
    const [favorites, setFavorites] = useState([]);
    const [playlists, setPlaylists] = useState([]);
    const [playlistItems, setPlaylistItems] = useState([]);
    const [newPlaylist, setNewPlaylist] = useState({ name: '', description: '' });
    const [profile, setProfile] = useState({ name: '' });
    const [confirmDelete, setConfirmDelete] = useState(false);
    const [transactions, setTransactions] = useState([]);
    const [donations, setDonations] = useState([]);
    const [topUpOpen, setTopUpOpen] = useState(false);
    const [donationOpen, setDonationOpen] = useState(false);
    const [searchParams] = useSearchParams();

    const creditBalance = getCredits(user);

    // Deep link from Android app: /dashboard?topup=1 auto-opens the top-up modal.
    useEffect(() => {
        if (searchParams.get('topup') === '1') {
            setTab('credits');
            setTopUpOpen(true);
        }
    }, [searchParams]);

    const load = useCallback(async () => {
        if (!user?.id) return;
        setLoading(true);
        setError('');
        try {
            const [p, f, pl, pi, tx, dn] = await Promise.all([
                listProgress(user.id),
                listFavorites(user.id),
                listPlaylists(user.id),
                listPlaylistItems(user.id),
                listCreditTransactions(user.id).catch(() => []),
                listDonations(user.id).catch(() => []),
            ]);
            setProgress(p);
            setFavorites(f);
            setPlaylists(pl);
            setPlaylistItems(pi);
            setTransactions(tx);
            setDonations(dn);
            setProfile({ name: user.name || '' });

            // Android app unlock: only fire onPaymentSuccess AFTER an admin
            // has approved a top-up. Track reported approvals in localStorage
            // so we don't re-unlock on every dashboard load.
            try {
                const reported = JSON.parse(localStorage.getItem('apx-android-reported-approvals') || '[]');
                const newlyApproved = tx.filter(
                    (t) => t.type === 'topup' && t.status === 'completed' && t.approval_by && !reported.includes(t.id),
                );
                if (newlyApproved.length > 0) {
                    notifyAndroidPaymentSuccess(TOPUP_AMOUNT);
                    localStorage.setItem(
                        'apx-android-reported-approvals',
                        JSON.stringify([...reported, ...newlyApproved.map((t) => t.id)]),
                    );
                }
            } catch (_) {
                /* non-fatal */
            }
        } catch (err) {
            setError(err?.message || 'Could not load your account data.');
        } finally {
            setLoading(false);
        }
    }, [user?.id, user?.name]);

    useEffect(() => {
        load();
    }, [load]);

    const continueWatching = progress.filter((p) => !p.completed);
    const history = progress;

    const createPlaylist = async (e) => {
        e.preventDefault();
        if (!newPlaylist.name.trim()) return toast.error('Give the playlist a name.');
        try {
            await pb.collection('playlists').create({ owner: user.id, ...newPlaylist });
            setNewPlaylist({ name: '', description: '' });
            toast.success('Playlist created');
            load();
        } catch (err) {
            toast.error(err?.message || 'Could not create the playlist.');
        }
    };

    const removeItem = async (collection, id) => {
        try {
            await pb.collection(collection).delete(id);
            toast.success('Removed');
            load();
        } catch (err) {
            toast.error(err?.message || 'Could not remove that item.');
        }
    };

    const saveProfile = async (e) => {
        e.preventDefault();
        try {
            await pb.collection('users').update(user.id, { name: profile.name });
            await refreshUser();
            toast.success('Profile updated');
        } catch (err) {
            toast.error(err?.message || 'Could not update your profile.');
        }
    };

    const requestDeletion = async () => {
        try {
            await pb.collection('users').update(user.id, { deletion_requested: true });
            toast.success('Deletion request submitted. An administrator will review it.');
            setConfirmDelete(false);
            await refreshUser();
        } catch (err) {
            toast.error(err?.message || 'Could not submit the request.');
        }
    };

    return (
        <Layout>
            <Helmet>
                <title>My Account | ApX Player</title>
                <meta name="description" content="Your ApX Player dashboard: continue watching, watch history, favourites, playlists and profile settings." />
            </Helmet>

            <div className="mx-auto max-w-[85rem] px-4 py-14 sm:px-6">
                <header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
                    <div>
                        <div className="mb-2 h-1.5 w-16 rounded-full grad-ax" aria-hidden="true" />
                        <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">Your account</p>
                        <h1 className="font-display text-5xl font-extrabold sm:text-6xl">Hello, <span className="text-grad">{user?.name || 'viewer'}</span></h1>
                    </div>
                    <div className="glass flex items-center gap-4 rounded-2xl px-5 py-3">
                        <div className="flex items-center gap-3">
                            <span className="grid h-10 w-10 place-items-center rounded-full grad-ax">
                                <Wallet className="h-5 w-5 text-primary-foreground" />
                            </span>
                            <div>
                                <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Credit balance</p>
                                <p className="text-2xl font-bold leading-none text-grad">₱{creditBalance}</p>
                            </div>
                        </div>
                        <button
                            type="button"
                            onClick={() => setTopUpOpen(true)}
                            className="focus-glow inline-flex min-h-[44px] items-center gap-1.5 rounded-full grad-ax px-4 text-sm font-semibold text-primary-foreground active:scale-[0.98]"
                        >
                            <Plus className="h-4 w-4" /> Add Credit
                        </button>
                        {userIsPremium(user) && (
                            <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-3 py-1.5 text-xs font-semibold text-primary">
                                <Crown className="h-3.5 w-3.5" aria-hidden="true" /> Premium
                            </span>
                        )}
                    </div>
                </header>

                <div className="mb-10 flex gap-2 overflow-x-auto border-b border-border pb-px" role="tablist">
                    {TABS.map((t) => (
                        <button
                            key={t.id}
                            role="tab"
                            aria-selected={tab === t.id}
                            onClick={() => setTab(t.id)}
                            className={`focus-glow inline-flex shrink-0 items-center gap-2 border-b-2 px-4 py-3 text-sm font-medium transition-colors ${
                                tab === t.id ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'
                            }`}
                        >
                            <t.icon className="h-4 w-4" aria-hidden="true" />
                            {t.label}
                        </button>
                    ))}
                </div>

                {loading && <LoadingState />}
                {!loading && error && <ErrorState message={error} onRetry={load} />}

                {!loading && !error && tab === 'continue' && (
                    continueWatching.length === 0 ? (
                        <EmptyState
                            title="Nothing in progress"
                            description="Start any title and it will appear here so you can pick up where you stopped."
                            action={<Link to="/browse" className="focus-glow inline-block rounded-full grad-ax px-5 py-2.5 text-sm font-semibold text-primary-foreground">Browse the catalogue</Link>}
                        />
                    ) : (
                        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
                            {continueWatching.map((p) => (
                                <div key={p.id}>
                                    <TitleCard title={recToTitle(p)} />
                                    <p className="mt-2 text-xs text-muted-foreground">
                                        {p.kind === 'series' ? `S${p.season} · E${p.episode}` : 'Started'}
                                    </p>
                                </div>
                            ))}
                        </div>
                    )
                )}

                {!loading && !error && tab === 'history' && (
                    history.length === 0 ? (
                        <EmptyState title="No watch history yet" description="Titles you play will be logged here." />
                    ) : (
                        <ul className="divide-y divide-border overflow-hidden rounded-sm border border-border">
                            {history.map((p) => (
                                <li key={p.id} className="flex items-center gap-4 bg-card/40 p-4">
                                    <img src={p.poster} alt="" className="h-20 w-14 rounded-sm object-cover" />
                                    <div className="flex-1">
                                        <Link to={watchLink(p)} className="text-sm font-semibold hover:text-primary">
                                            {p.title_text}
                                        </Link>
                                        {p.kind === 'series' && (
                                            <p className="text-xs text-primary">S{p.season} · E{p.episode}</p>
                                        )}
                                        <p className="mt-1 text-xs text-muted-foreground">
                                            {p.completed ? 'Completed' : 'Started'}
                                        </p>
                                    </div>
                                    <button
                                        type="button"
                                        onClick={() => removeItem('progress', p.id)}
                                        className="grid h-10 w-10 place-items-center rounded-sm text-muted-foreground hover:bg-destructive/20 hover:text-destructive"
                                        aria-label={`Remove ${p.title_text} from history`}
                                    >
                                        <Trash2 className="h-4 w-4" />
                                    </button>
                                </li>
                            ))}
                        </ul>
                    )
                )}

                {!loading && !error && tab === 'favorites' && (
                    favorites.length === 0 ? (
                        <EmptyState
                            title="No favourites yet"
                            description="Tap the heart on any title to keep it here."
                            action={<Link to="/browse" className="focus-glow inline-block rounded-full grad-ax px-5 py-2.5 text-sm font-semibold text-primary-foreground">Find something to watch</Link>}
                        />
                    ) : (
                        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
                            {favorites.map((f) => (
                                <div key={f.id}>
                                    <TitleCard title={recToTitle(f)} />
                                    <button
                                        type="button"
                                        onClick={() => removeItem('favorites', f.id)}
                                        className="mt-2 text-xs text-muted-foreground hover:text-destructive"
                                    >
                                        Remove
                                    </button>
                                </div>
                            ))}
                        </div>
                    )
                )}

                {!loading && !error && tab === 'playlists' && (
                    <div className="grid gap-10 lg:grid-cols-[320px_1fr]">
                        <form onSubmit={createPlaylist} className="h-fit rounded-sm border border-border bg-card/40 p-5">
                            <h2 className="text-sm font-semibold">New playlist</h2>
                            <div className="mt-4 flex flex-col gap-2">
                                <label htmlFor="pl-name" className="text-xs text-muted-foreground">Name</label>
                                <input id="pl-name" value={newPlaylist.name} onChange={(e) => setNewPlaylist((v) => ({ ...v, name: e.target.value }))} className="h-11 rounded-sm border border-border bg-secondary/50 px-3 text-sm" />
                            </div>
                            <div className="mt-3 flex flex-col gap-2">
                                <label htmlFor="pl-desc" className="text-xs text-muted-foreground">Description</label>
                                <textarea id="pl-desc" rows={3} value={newPlaylist.description} onChange={(e) => setNewPlaylist((v) => ({ ...v, description: e.target.value }))} className="rounded-sm border border-border bg-secondary/50 p-3 text-sm" />
                            </div>
                            <button type="submit" className="focus-glow mt-4 min-h-[44px] w-full rounded-full grad-ax text-sm font-semibold text-primary-foreground active:scale-[0.99]">
                                Create playlist
                            </button>
                        </form>

                        <div>
                            {playlists.length === 0 ? (
                                <EmptyState title="No playlists yet" description="Create one on the left, then add titles from any detail page." />
                            ) : (
                                <div className="space-y-8">
                                    {playlists.map((pl) => {
                                        const items = playlistItems.filter((i) => i.playlist === pl.id);
                                        return (
                                            <section key={pl.id} className="rounded-sm border border-border bg-card/30 p-5">
                                                <div className="flex items-start justify-between gap-4">
                                                    <div>
                                                        <h3 className="font-display text-2xl font-bold">{pl.name}</h3>
                                                        {pl.description && <p className="mt-1 text-sm text-muted-foreground">{pl.description}</p>}
                                                    </div>
                                                    <button
                                                        type="button"
                                                        onClick={() => {
                                                            if (window.confirm(`Delete the playlist "${pl.name}"? This cannot be undone.`)) {
                                                                removeItem('playlists', pl.id);
                                                            }
                                                        }}
                                                        className="rounded-sm border border-border px-3 py-2 text-xs text-muted-foreground hover:border-destructive hover:text-destructive"
                                                    >
                                                        Delete
                                                    </button>
                                                </div>
                                                {items.length === 0 ? (
                                                    <p className="mt-4 text-sm text-muted-foreground">This playlist is empty.</p>
                                                ) : (
                                                    <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-6">
                                                        {items.map((i) => (
                                                            <div key={i.id}>
                                                                <TitleCard title={recToTitle(i)} />
                                                                <button
                                                                    type="button"
                                                                    onClick={() => removeItem('playlist_items', i.id)}
                                                                    className="mt-2 text-xs text-muted-foreground hover:text-destructive"
                                                                >
                                                                    Remove
                                                                </button>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}
                                            </section>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {!loading && !error && tab === 'credits' && (
                    <div className="grid gap-8 lg:grid-cols-[340px_1fr]">
                        {/* balance + top-up card */}
                        <div className="h-fit rounded-sm border border-border bg-card/40 p-6">
                            <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Current balance</p>
                            <p className="mt-1 text-5xl font-bold text-primary">₱{creditBalance}</p>
                            <p className="mt-2 text-sm text-muted-foreground">
                                Credits are spent on karaoke sessions and unlock app features.
                            </p>
                            <button
                                type="button"
                                onClick={() => setTopUpOpen(true)}
                                className="focus-glow mt-5 inline-flex min-h-[48px] w-full items-center justify-center gap-1.5 rounded-full grad-ax text-sm font-semibold text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.35)] active:scale-[0.99]"
                            >
                                <Plus className="h-4 w-4" /> Add ₱{TOPUP_AMOUNT} via GCash
                            </button>
                            <dl className="mt-6 space-y-2 border-t border-border pt-4 text-sm">
                                <div className="flex justify-between">
                                    <dt className="text-muted-foreground">Top-up amount</dt>
                                    <dd>₱{TOPUP_AMOUNT}.00</dd>
                                </div>
                                <div className="flex justify-between">
                                    <dt className="text-muted-foreground">Payment method</dt>
                                    <dd>GCash</dd>
                                </div>
                                <div className="flex justify-between">
                                    <dt className="text-muted-foreground">Transactions</dt>
                                    <dd>{transactions.length}</dd>
                                </div>
                            </dl>
                        </div>

                        {/* transaction history */}
                        <div>
                            <h2 className="font-display text-2xl font-bold">Transaction history</h2>
                            {transactions.length === 0 ? (
                                <EmptyState
                                    title="No transactions yet"
                                    description="Top up with GCash to start building your credit balance."
                                    action={
                                        <button
                                            type="button"
                                            onClick={() => setTopUpOpen(true)}
                                            className="focus-glow inline-block rounded-full grad-ax px-5 py-2.5 text-sm font-semibold text-primary-foreground"
                                        >
                                            Add credit
                                        </button>
                                    }
                                />
                            ) : (
                                <ul className="mt-4 divide-y divide-border overflow-hidden rounded-sm border border-border">
                                    {transactions.map((t) => {
                                        const label = TX_LABEL[t.type] || TX_LABEL.adjustment;
                                        const positive = Number(t.amount) >= 0;
                                        return (
                                            <li key={t.id} className="flex items-center gap-4 bg-card/40 p-4">
                                                <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-full ${positive ? 'bg-primary/15' : 'bg-secondary'}`}>
                                                    <Wallet className={`h-5 w-5 ${positive ? 'text-primary' : 'text-muted-foreground'}`} />
                                                </span>
                                                <div className="flex-1">
                                                    <p className={`text-sm font-semibold ${label.tone}`}>{label.text}</p>
                                                    <p className="text-xs text-muted-foreground">
                                                        {new Date(t.created).toLocaleString()}
                                                        {t.reference ? ` · Ref ${t.reference}` : ''}
                                                    </p>
                                                    {(() => {
                                                        const st = TX_STATUS[t.status] || TX_STATUS.pending;
                                                        return (
                                                            <p className={`mt-0.5 text-[11px] font-medium ${st.tone}`}>
                                                                {st.text}
                                                                {t.status === 'rejected' && t.rejection_reason ? ` · ${t.rejection_reason}` : ''}
                                                            </p>
                                                        );
                                                    })()}
                                                </div>
                                                <div className="text-right">
                                                    <p className={`text-sm font-bold ${positive ? 'text-primary' : 'text-foreground'}`}>
                                                        {positive ? '+' : ''}₱{Math.abs(Number(t.amount))}
                                                    </p>
                                                    {t.balance_after != null && (
                                                        <p className="text-[11px] text-muted-foreground">Bal ₱{t.balance_after}</p>
                                                    )}
                                                </div>
                                            </li>
                                        );
                                    })}
                                </ul>
                            )}
                        </div>
                    </div>
                )}

                {!loading && !error && tab === 'premium' && (
                    <div className="grid gap-8 lg:grid-cols-[340px_1fr]">
                        {/* Waiting-for-approval banner — shown when a donation is pending */}
                        {!userIsPremium(user) && donations.some((d) => d.status === 'pending') && (
                            <div className="lg:col-span-2 flex items-center gap-3 rounded-xl border border-amber-500/40 bg-amber-500/10 p-4">
                                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-amber-500/20">
                                    <Clock className="h-5 w-5 text-amber-500" />
                                </span>
                                <div className="flex-1">
                                    <p className="text-sm font-semibold text-amber-500">Waiting for admin approval</p>
                                    <p className="text-xs text-muted-foreground">
                                        Your donation has been submitted. Premium access will be activated once an
                                        administrator approves it.
                                    </p>
                                </div>
                            </div>
                        )}

                        {/* status + get premium card */}
                        <div className="h-fit rounded-sm border border-border bg-card/40 p-6">
                            <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Premium status</p>
                            {userIsPremium(user) ? (
                                <>
                                    <p className="mt-2 inline-flex items-center gap-2 text-2xl font-bold text-primary">
                                        <Crown className="h-6 w-6" aria-hidden="true" /> Active
                                    </p>
                                    <p className="mt-2 text-sm text-muted-foreground">
                                        You have premium access to all Vivamax and Viva One content. Enjoy!
                                    </p>
                                </>
                            ) : donations.some((d) => d.status === 'pending') ? (
                                <>
                                    <p className="mt-2 inline-flex items-center gap-2 text-2xl font-bold text-amber-500">
                                        <Clock className="h-6 w-6" aria-hidden="true" /> Pending
                                    </p>
                                    <p className="mt-2 text-sm text-muted-foreground">
                                        Your donation is <span className="font-semibold text-amber-500">waiting for
                                        admin approval</span>. Premium access to Vivamax and Viva One will be unlocked
                                        once an administrator verifies your payment.
                                    </p>
                                </>
                            ) : (
                                <>
                                    <p className="mt-2 text-2xl font-bold text-foreground">Not active</p>
                                    <p className="mt-2 text-sm text-muted-foreground">
                                        Send a one-time donation of at least ₱{PREMIUM_MIN_DONATION} to unlock every
                                        Vivamax and Viva One title.
                                    </p>
                                    <button
                                        type="button"
                                        onClick={() => setDonationOpen(true)}
                                        className="focus-glow mt-5 inline-flex min-h-[48px] w-full items-center justify-center gap-1.5 rounded-full grad-ax text-sm font-semibold text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.35)] active:scale-[0.99]"
                                    >
                                        <Crown className="h-4 w-4" /> Get Premium Access
                                    </button>
                                </>
                            )}
                            <dl className="mt-6 space-y-2 border-t border-border pt-4 text-sm">
                                <div className="flex justify-between">
                                    <dt className="text-muted-foreground">Donations submitted</dt>
                                    <dd>{donations.length}</dd>
                                </div>
                                <div className="flex justify-between">
                                    <dt className="text-muted-foreground">Minimum donation</dt>
                                    <dd>₱{PREMIUM_MIN_DONATION}.00</dd>
                                </div>
                            </dl>
                        </div>

                        {/* donation history */}
                        <div>
                            <h2 className="font-display text-2xl font-bold">Donation history</h2>
                            {donations.length === 0 ? (
                                <EmptyState
                                    title="No donations yet"
                                    description="Submit a GCash donation to unlock Vivamax and Viva One premium content."
                                    action={
                                        <button
                                            type="button"
                                            onClick={() => setDonationOpen(true)}
                                            className="focus-glow inline-block rounded-full grad-ax px-5 py-2.5 text-sm font-semibold text-primary-foreground"
                                        >
                                            Get Premium Access
                                        </button>
                                    }
                                />
                            ) : (
                                <ul className="mt-4 divide-y divide-border overflow-hidden rounded-sm border border-border">
                                    {donations.map((d) => {
                                        const tone =
                                            d.status === 'approved' ? 'text-primary' :
                                            d.status === 'rejected' ? 'text-destructive' : 'text-amber-500';
                                        const label =
                                            d.status === 'approved' ? 'Approved — premium granted' :
                                            d.status === 'rejected' ? 'Rejected' : 'Pending admin review';
                                        return (
                                            <li key={d.id} className="flex items-center gap-4 bg-card/40 p-4">
                                                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary/15">
                                                    <Crown className="h-5 w-5 text-primary" />
                                                </span>
                                                <div className="flex-1">
                                                    <p className="text-sm font-semibold">₱{Number(d.amount)} donation</p>
                                                    <p className="text-xs text-muted-foreground">
                                                        {new Date(d.created).toLocaleString()}
                                                        {d.gcash_reference ? ` · Ref ${d.gcash_reference}` : ''}
                                                    </p>
                                                    <p className={`mt-0.5 text-[11px] font-medium ${tone}`}>
                                                        {label}
                                                        {d.status === 'approved' && d.approval_date ? ` · ${new Date(d.approval_date).toLocaleDateString()}` : ''}
                                                        {d.status === 'rejected' && d.rejection_reason ? ` · ${d.rejection_reason}` : ''}
                                                    </p>
                                                </div>
                                                {d.proof_image && (
                                                    <a
                                                        href={proofImageUrl(d, d.proof_image)}
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        className="shrink-0"
                                                        aria-label="View proof of payment"
                                                    >
                                                        <img
                                                            src={proofImageUrl(d, d.proof_image)}
                                                            alt="Proof of payment"
                                                            className="h-12 w-12 rounded-sm object-cover"
                                                        />
                                                    </a>
                                                )}
                                            </li>
                                        );
                                    })}
                                </ul>
                            )}
                        </div>
                    </div>
                )}

                {!loading && !error && tab === 'profile' && (
                    <div className="grid max-w-3xl gap-10">
                        <form onSubmit={saveProfile} className="rounded-sm border border-border bg-card/40 p-6">
                            <h2 className="text-sm font-semibold">Profile settings</h2>
                            <div className="mt-4 flex flex-col gap-2">
                                <label htmlFor="p-name" className="text-xs text-muted-foreground">Display name</label>
                                <input id="p-name" value={profile.name} onChange={(e) => setProfile({ name: e.target.value })} className="h-11 rounded-sm border border-border bg-secondary/50 px-3 text-sm" />
                            </div>
                            <div className="mt-4 flex flex-col gap-2">
                                <label htmlFor="p-email" className="text-xs text-muted-foreground">Email</label>
                                <input id="p-email" value={user?.email || ''} readOnly className="h-11 rounded-sm border border-border bg-secondary/30 px-3 text-sm text-muted-foreground" />
                            </div>
                            <button type="submit" className="focus-glow mt-5 min-h-[44px] rounded-full grad-ax px-6 text-sm font-semibold text-primary-foreground active:scale-[0.99]">
                                Save changes
                            </button>
                        </form>

                        <div className="rounded-sm border border-destructive/40 bg-destructive/5 p-6">
                            <h2 className="text-sm font-semibold text-destructive">Delete my account</h2>
                            <p className="mt-2 text-sm text-muted-foreground">
                                {user?.deletion_requested
                                    ? 'A deletion request is already on file. An administrator will process it shortly.'
                                    : 'Submitting a request flags your account for permanent deletion by an administrator. Your history, favourites and playlists will be removed.'}
                            </p>
                            {!user?.deletion_requested && !confirmDelete && (
                                <button type="button" onClick={() => setConfirmDelete(true)} className="mt-4 min-h-[44px] rounded-sm border border-destructive px-5 text-sm font-semibold text-destructive hover:bg-destructive hover:text-destructive-foreground">
                                    Request account deletion
                                </button>
                            )}
                            {confirmDelete && (
                                <div className="mt-4 flex flex-wrap gap-3" role="alertdialog" aria-label="Confirm deletion request">
                                    <p className="w-full text-sm">Are you sure? This cannot be undone once processed.</p>
                                    <button type="button" onClick={requestDeletion} className="min-h-[44px] rounded-sm bg-destructive px-5 text-sm font-semibold text-destructive-foreground">
                                        Yes, submit request
                                    </button>
                                    <button type="button" onClick={() => setConfirmDelete(false)} className="min-h-[44px] rounded-sm border border-border px-5 text-sm font-semibold">
                                        Cancel
                                    </button>
                                </div>
                            )}
                        </div>

                        <button type="button" onClick={logout} className="w-fit rounded-sm border border-border px-5 py-3 text-sm font-semibold hover:border-primary hover:text-primary">
                            Sign out
                        </button>
                    </div>
                )}
            </div>

            <TopUpModal
                open={topUpOpen}
                onClose={() => setTopUpOpen(false)}
                user={user}
                onSuccess={() => {
                    refreshUser();
                    load();
                }}
            />

            <DonationModal
                open={donationOpen}
                onClose={() => setDonationOpen(false)}
                user={user}
                onSuccess={() => {
                    refreshUser();
                    load();
                }}
            />
        </Layout>
    );
};

export default DashboardPage;
