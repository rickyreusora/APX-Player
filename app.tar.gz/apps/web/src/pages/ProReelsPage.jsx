import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { ChevronLeft, ChevronRight, Maximize, Minimize, Search, X } from 'lucide-react';
import Layout from '@/components/Layout';
import { cn } from '@/lib/utils';
import catalog from '@/data/proReels.json';

const PAGE_SIZE = 20;
const PROVIDER_ORDER = [
    'reelshort', 'moboreels', 'rapidtv', 'joyreels', 'dramabox', 'melolo', 'anamana',
    'pinedrama', 'raptdrama', 'moviebox', 'blinkdrama', 'filmbox', 'wetv', 'storyreel',
    'kalostv', 'shorten', 'flextv2', 'cubetv', 'vibeshort', 'dramawave', 'movieboxshorts',
    'bonustv', 'freereels', 'dramanova', 'mydrama', 'candyjar', 'flextv', 'shortmax',
    'happyshort', 'sereal', 'netshort', 'iqiyi', 'reelife', 'vigloo', 'flareflow', 'rapidtv2',
];

const labelOf = (id) => (id ? id.charAt(0).toUpperCase() + id.slice(1) : id);

const isVertical = (provider) => {
    const p = String(provider || '').toLowerCase();
    return p.includes('short') || p.includes('reel') || p.includes('vibeshort');
};

const proxyUrl = (show, ep) =>
    `https://maruyatvph.com/proxy.php?provider=${encodeURIComponent(show.p)}&id=${encodeURIComponent(show.id)}&ep=${encodeURIComponent(String(ep))}&lang=en`;

const ProReelsPage = () => {
    const [provider, setProvider] = useState('reelshort');
    const [query, setQuery] = useState('');
    const [shown, setShown] = useState(PAGE_SIZE);
    const [active, setActive] = useState(null);
    const [ep, setEp] = useState(1);
    const [isFs, setIsFs] = useState(false);
    const tabsRef = useRef(null);
    const touch = useRef(null);
    const fsRef = useRef(null);

    const providers = useMemo(() => {
        const present = new Set(catalog.map((m) => m.p));
        const ordered = PROVIDER_ORDER.filter((p) => present.has(p));
        catalog.forEach((m) => {
            if (!ordered.includes(m.p)) ordered.push(m.p);
        });
        return ordered;
    }, []);

    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase();
        return catalog.filter((m) => {
            if (provider !== 'all' && m.p !== provider) return false;
            if (q && !String(m.t).toLowerCase().includes(q)) return false;
            return true;
        });
    }, [provider, query]);

    const visible = filtered.slice(0, shown);
    const remaining = Math.max(0, filtered.length - visible.length);

    useEffect(() => {
        setShown(PAGE_SIZE);
    }, [provider, query]);

    useEffect(() => {
        if (!active) return undefined;
        const prev = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        const onKey = (e) => {
            if (e.key === 'Escape') setActive(null);
            if (e.key === 'ArrowRight') setEp((n) => Math.min(Math.max(active.e || 1, 1), n + 1));
            if (e.key === 'ArrowLeft') setEp((n) => Math.max(1, n - 1));
        };
        window.addEventListener('keydown', onKey);
        return () => {
            document.body.style.overflow = prev;
            window.removeEventListener('keydown', onKey);
        };
    }, [active]);

    // Track fullscreen state so the toggle button reflects reality, and exit
    // fullscreen cleanly when the player modal closes.
    useEffect(() => {
        const onChange = () => {
            setIsFs(Boolean(document.fullscreenElement || document.webkitFullscreenElement));
        };
        document.addEventListener('fullscreenchange', onChange);
        document.addEventListener('webkitfullscreenchange', onChange);
        return () => {
            document.removeEventListener('fullscreenchange', onChange);
            document.removeEventListener('webkitfullscreenchange', onChange);
        };
    }, []);

    useEffect(() => {
        if (!active && (document.fullscreenElement || document.webkitFullscreenElement)) {
            exitFullscreen();
        }
    }, [active]);

    const enterFullscreen = (el) => {
        const node = el || fsRef.current;
        if (!node) return;
        const req = node.requestFullscreen || node.webkitRequestFullscreen || node.webkitEnterFullscreen;
        if (!req) return;
        try {
            const ret = req.call(node);
            if (ret && typeof ret.catch === 'function') ret.catch(() => {});
        } catch {
            /* fullscreen not allowed on this device/browser */
        }
    };

    const exitFullscreen = () => {
        const exit = document.exitFullscreen || document.webkitExitFullscreen;
        if (!exit) return;
        try {
            const ret = exit.call(document);
            if (ret && typeof ret.catch === 'function') ret.catch(() => {});
        } catch {
            /* ignore */
        }
    };

    const toggleFullscreen = () => {
        if (document.fullscreenElement || document.webkitFullscreenElement) {
            exitFullscreen();
        } else {
            enterFullscreen();
        }
    };

    const openShow = (show) => {
        setActive(show);
        setEp(1);
        // Auto-enter fullscreen on the user gesture that opened the reel.
        // rAF runs after React commits the player DOM but before paint, so the
        // element exists and the transient user activation is still valid.
        requestAnimationFrame(() => enterFullscreen());
    };

    const onTouchStart = (e) => {
        if (!active || !isVertical(active.p)) return;
        const t = e.changedTouches[0];
        touch.current = { y: t.clientY, x: t.clientX };
    };
    const onTouchEnd = (e) => {
        if (!touch.current || !active) return;
        const t = e.changedTouches[0];
        const dy = t.clientY - touch.current.y;
        const dx = Math.abs(t.clientX - touch.current.x);
        touch.current = null;
        if (Math.abs(dy) < 70 || dx > Math.abs(dy)) return;
        const max = Math.max(active.e || 1, 1);
        if (dy < 0) setEp((n) => Math.min(max, n + 1));
        else setEp((n) => Math.max(1, n - 1));
    };

    const episodeCount = active ? Math.max(active.e || 1, 1) : 1;

    return (
        <Layout>
            <Helmet>
                <title>Pro Reels — Short Dramas | ApX Player</title>
                <meta
                    name="description"
                    content="Pro Reels on ApX Player: browse short dramas from Reelshort, Dramabox, Wetv, Filmbox and more, then play episodes in the built-in player."
                />
            </Helmet>

            <div className="min-h-[100dvh] bg-[#0c0c0e] text-white">
                <div className="sticky top-16 z-20 border-b border-white/5 bg-[#0c0c0e]/95 backdrop-blur">
                    <div className="mx-auto flex max-w-[96rem] items-center gap-4 px-3 py-3 sm:px-5">
                        <h1 className="shrink-0 text-lg font-semibold tracking-tight sm:text-xl">
                            MaruyaTVPH <span className="text-[#e50914]">Reels</span>
                        </h1>
                        <form
                            className="ml-auto w-full max-w-xs"
                            role="search"
                            onSubmit={(e) => e.preventDefault()}
                        >
                            <label htmlFor="pro-reels-search" className="sr-only">Search movies</label>
                            <div className="relative">
                                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" aria-hidden="true" />
                                <input
                                    id="pro-reels-search"
                                    value={query}
                                    onChange={(e) => setQuery(e.target.value)}
                                    placeholder="Search movies..."
                                    className="h-10 w-full rounded-full border border-white/10 bg-[#1a1a1d] pl-9 pr-3 text-sm text-white placeholder:text-zinc-500 focus:border-[#e50914]/60"
                                />
                            </div>
                        </form>
                    </div>
                    <div
                        ref={tabsRef}
                        className="no-scrollbar mx-auto flex max-w-[96rem] gap-2 overflow-x-auto px-3 pb-3 sm:px-5"
                    >
                        <button
                            type="button"
                            onClick={() => setProvider('all')}
                            className={cn(
                                'shrink-0 rounded-full px-3.5 py-1.5 text-sm font-medium transition-colors',
                                provider === 'all' ? 'bg-[#e50914] text-white' : 'bg-[#1c1c1f] text-zinc-300 hover:bg-[#2a2a2e]',
                            )}
                        >
                            All
                        </button>
                        {providers.map((p) => (
                            <button
                                key={p}
                                type="button"
                                onClick={() => setProvider(p)}
                                className={cn(
                                    'shrink-0 rounded-full px-3.5 py-1.5 text-sm font-medium capitalize transition-colors',
                                    provider === p ? 'bg-[#e50914] text-white' : 'bg-[#1c1c1f] text-zinc-300 hover:bg-[#2a2a2e]',
                                )}
                            >
                                {labelOf(p)}
                            </button>
                        ))}
                    </div>
                </div>

                <main className="mx-auto max-w-[96rem] px-3 py-4 sm:px-5">
                    {visible.length === 0 ? (
                        <p className="py-24 text-center text-sm text-zinc-500">No movies match that search.</p>
                    ) : (
                        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
                            {visible.map((m) => (
                                <li key={`${m.p}-${m.id}`}>
                                    <button
                                        type="button"
                                        onClick={() => openShow(m)}
                                        className="group w-full overflow-hidden rounded-xl border border-white/5 bg-[#161618] text-left transition-transform hover:scale-[1.015] active:scale-[0.99]"
                                    >
                                        <span className="relative block aspect-[2/3] overflow-hidden bg-zinc-900">
                                            <img
                                                src={m.c}
                                                alt={m.t}
                                                loading="lazy"
                                                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                                            />
                                        </span>
                                        <span className="block px-2.5 py-2">
                                            <span className="line-clamp-2 text-[13px] font-medium leading-snug text-zinc-100">{m.t}</span>
                                            <span className="mt-0.5 block text-[11px] text-zinc-500">
                                                {m.e > 0 ? `${m.e} Episodes` : 'Available'}
                                            </span>
                                        </span>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    )}

                    <div className="flex flex-col items-center gap-2 py-8">
                        {remaining > 0 && (
                            <button
                                type="button"
                                onClick={() => setShown((n) => n + PAGE_SIZE)}
                                className="rounded-full border border-white/10 bg-[#1c1c1f] px-6 py-2.5 text-sm font-medium text-zinc-200 transition-colors hover:bg-[#2a2a2e] active:scale-[0.98]"
                            >
                                Load More
                            </button>
                        )}
                        <p className="text-xs text-zinc-500">
                            Showing {visible.length} of {filtered.length} movies
                            {remaining > 0 ? ` · ${remaining} remaining` : ''}
                        </p>
                    </div>
                </main>
            </div>

            {active && (
                <div
                    className="fixed inset-0 z-[70] flex items-center justify-center bg-black/85 p-2 sm:p-6"
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="pro-reels-player-title"
                    onClick={() => setActive(null)}
                >
                    <div
                        className={cn(
                            'flex max-h-[96dvh] w-full max-w-md flex-col overflow-hidden rounded-2xl border border-white/10 bg-[#111114] shadow-2xl',
                        )}
                        onClick={(e) => e.stopPropagation()}
                        onTouchStart={onTouchStart}
                        onTouchEnd={onTouchEnd}
                    >
                        <div className="flex items-center gap-3 border-b border-white/10 px-3 py-2.5">
                            <div className="min-w-0 flex-1">
                                <p id="pro-reels-player-title" className="truncate text-sm font-semibold">{active.t}</p>
                                <p className="text-[11px] capitalize text-zinc-500">
                                    {labelOf(active.p)} · Episode {ep} of {episodeCount}
                                </p>
                            </div>
                            <button
                                type="button"
                                onClick={toggleFullscreen}
                                className="grid h-10 w-10 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20"
                                aria-label={isFs ? 'Exit fullscreen' : 'Enter fullscreen'}
                                title={isFs ? 'Exit fullscreen' : 'Fullscreen'}
                            >
                                {isFs ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
                            </button>
                            <button
                                type="button"
                                onClick={() => setActive(null)}
                                className="grid h-10 w-10 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20"
                                aria-label="Close player"
                            >
                                <X className="h-4 w-4" />
                            </button>
                        </div>
                        <div
                            ref={fsRef}
                            className="fs-target reels-player-frame relative bg-black"
                        >
                            <iframe
                                key={`${active.id}-${ep}`}
                                title={`${active.t} episode ${ep}`}
                                src={proxyUrl(active, ep)}
                                allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                                allowFullScreen
                                className="h-full w-full"
                            />
                        </div>
                        <div className="flex items-center gap-2 border-t border-white/10 px-3 py-2">
                            <button
                                type="button"
                                disabled={ep <= 1}
                                onClick={() => setEp((n) => Math.max(1, n - 1))}
                                className="inline-flex h-10 items-center gap-1 rounded-full bg-white/10 px-3 text-xs font-semibold disabled:opacity-40"
                            >
                                <ChevronLeft className="h-4 w-4" /> Prev
                            </button>
                            <div className="no-scrollbar flex min-w-0 flex-1 gap-1.5 overflow-x-auto py-1">
                                {Array.from({ length: episodeCount }, (_, i) => i + 1).slice(0, 120).map((n) => (
                                    <button
                                        key={n}
                                        type="button"
                                        onClick={() => setEp(n)}
                                        className={cn(
                                            'h-8 min-w-8 shrink-0 rounded-md px-2 text-xs font-semibold',
                                            n === ep ? 'bg-[#e50914] text-white' : 'bg-[#1c1c1f] text-zinc-400',
                                        )}
                                    >
                                        {n}
                                    </button>
                                ))}
                            </div>
                            <button
                                type="button"
                                disabled={ep >= episodeCount}
                                onClick={() => setEp((n) => Math.min(episodeCount, n + 1))}
                                className="inline-flex h-10 items-center gap-1 rounded-full bg-white/10 px-3 text-xs font-semibold disabled:opacity-40"
                            >
                                Next <ChevronRight className="h-4 w-4" />
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </Layout>
    );
};

export default ProReelsPage;
