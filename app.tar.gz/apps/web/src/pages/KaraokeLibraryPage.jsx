import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
    AlertCircle,
    ArrowLeft,
    ChevronDown,
    ChevronLeft,
    ChevronRight,
    ChevronUp,
    Film,
    Fullscreen,
    ListMusic,
    Loader2,
    Play,
    Search,
    Settings,
    SkipForward,
    Square,
    Trophy,
    Volume2,
    X,
} from 'lucide-react';
import Layout from '@/components/Layout';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import apiServerClient from '@/lib/apiServerClient';
import YoutubeKaraokePlayer from '@/components/YoutubeKaraokePlayer';
import useUiPainter from '@/hooks/useUiPainter';
import UiSystemModals, { BootBadge } from '@/components/UiSystemModals';
import UiScreensView from '@/components/UiScreensView';
import { inferTag } from '@/lib/uiScreens';
import { deepLinks, isAndroidApp } from '@/lib/androidDeepLink';

const SEARCH_LIMIT = 80;
const LANGUAGES = ['All', 'International', 'OPM', 'PHILIPPINES'];
const SORTS = [
    { id: 'code', label: 'Song # ↑' },
    { id: 'title', label: 'Title A–Z' },
    { id: 'artist', label: 'Artist A–Z' },
];


/** Stable 4–6 digit display code from song id (karaoke songbook style). */
function songCode(song, index = 0) {
    if (song?.code) return String(song.code);
    const raw = String(song?.id || song?.slug || song?.title || index);
    let h = 0;
    for (let i = 0; i < raw.length; i += 1) h = (h * 31 + raw.charCodeAt(i)) >>> 0;
    const n = 1000 + (h % 900000);
    return String(n).padStart(4, '0');
}

/* ------------------------------------------------------------------ */
/*  Spatial D-pad navigation                                          */
/* ------------------------------------------------------------------ */
const useSpatialNav = (containerRef, enabled) => {
    const focusByDirection = useCallback(
        (dir) => {
            const root = containerRef.current;
            if (!root) return;
            const els = Array.from(
                root.querySelectorAll(
                    'button:not([disabled]), [href], input:not([disabled]), [data-focusable]:not([disabled]), [role="slider"], [role="combobox"]',
                ),
            ).filter((el) => el.offsetParent !== null);
            if (!els.length) return;
            const active = document.activeElement;
            const cur = els.includes(active) ? active : null;
            if (!cur) {
                els[0].focus();
                return;
            }
            const cr = cur.getBoundingClientRect();
            const cx = cr.left + cr.width / 2;
            const cy = cr.top + cr.height / 2;
            let best = null;
            let bestScore = Infinity;
            els.forEach((el) => {
                if (el === cur) return;
                const r = el.getBoundingClientRect();
                const ex = r.left + r.width / 2;
                const ey = r.top + r.height / 2;
                const dx = ex - cx;
                const dy = ey - cy;
                let primary;
                let secondary;
                if (dir === 'right') {
                    if (dx <= 0) return;
                    primary = dx;
                    secondary = Math.abs(dy) * 2.5;
                } else if (dir === 'left') {
                    if (dx >= 0) return;
                    primary = -dx;
                    secondary = Math.abs(dy) * 2.5;
                } else if (dir === 'down') {
                    if (dy <= 0) return;
                    primary = dy;
                    secondary = Math.abs(dx) * 2.5;
                } else if (dir === 'up') {
                    if (dy >= 0) return;
                    primary = -dy;
                    secondary = Math.abs(dx) * 2.5;
                } else return;
                const score = primary + secondary;
                if (score < bestScore) {
                    bestScore = score;
                    best = el;
                }
            });
            if (best) best.focus();
        },
        [containerRef],
    );

    useEffect(() => {
        if (!enabled) return;
        const onKey = (e) => {
            const root = containerRef.current;
            if (!root) return;
            const tag = (document.activeElement?.tagName || '').toLowerCase();
            const inField = tag === 'input' || tag === 'textarea';
            switch (e.key) {
                case 'ArrowRight':
                case 'ArrowLeft':
                    if (inField) return;
                    e.preventDefault();
                    focusByDirection(e.key === 'ArrowRight' ? 'right' : 'left');
                    break;
                case 'ArrowDown':
                    e.preventDefault();
                    focusByDirection('down');
                    break;
                case 'ArrowUp':
                    if (inField) return;
                    e.preventDefault();
                    focusByDirection('up');
                    break;
                case 'Enter':
                    if (inField) return;
                    e.preventDefault();
                    if (document.activeElement?.click) document.activeElement.click();
                    break;
                default:
                    break;
            }
        };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [enabled, containerRef, focusByDirection]);
};

/* ------------------------------------------------------------------ */
/*  Song action popup (Reserve / Play Now)                            */
/* ------------------------------------------------------------------ */
const SongActionPopup = ({ song, onClose, onPlay, onReserve, onReserveFirst }) => {
    if (!song) return null;
    return (
        <div
            className="fixed inset-0 z-[80] flex items-end justify-center bg-black/50 p-4 sm:items-center"
            role="dialog"
            aria-modal="true"
            aria-labelledby="apx-oke-pop-title"
            onClick={onClose}
        >
            <motion.div
                initial={{ opacity: 0, y: 24, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 16, scale: 0.96 }}
                transition={{ duration: 0.2, ease: 'easeOut' }}
                onClick={(e) => e.stopPropagation()}
                className="w-full max-w-sm rounded-xl border border-cyan-400/50 bg-[#1a1a1a]/[0.98] p-5 shadow-[0_0_40px_rgba(0,0,0,0.85)]"
            >
                <p id="apx-oke-pop-title" className="text-center text-lg font-bold text-white">
                    Song Selection
                </p>
                <p className="mt-1 text-center text-sm text-zinc-400">
                    <span className="font-semibold text-cyan-300">{songCode(song)}</span>
                    {' · '}
                    {song.title}
                    {song.artist ? ` — ${song.artist}` : ''}
                </p>
                <p className="mt-2 text-center text-xs text-zinc-500">What would you like to do?</p>
                <div className="mt-5 space-y-2">
                    <button
                        type="button"
                        data-focusable
                        onClick={() => onReserve(song)}
                        className="block w-full rounded-lg bg-zinc-700 py-3.5 text-base font-bold text-white transition-colors hover:bg-zinc-600 active:scale-[0.98]"
                    >
                        Reserve
                    </button>
                    <button
                        type="button"
                        data-focusable
                        onClick={() => onReserveFirst(song)}
                        className="block w-full rounded-lg bg-amber-600/90 py-3.5 text-base font-bold text-white transition-colors hover:bg-amber-500 active:scale-[0.98]"
                    >
                        1st Reserve
                    </button>
                    <button
                        type="button"
                        data-focusable
                        onClick={() => onPlay(song)}
                        className="block w-full rounded-lg bg-primary py-3.5 text-base font-bold text-primary-foreground transition-colors hover:bg-primary/90 active:scale-[0.98]"
                    >
                        Play Now
                    </button>
                    <button
                        type="button"
                        data-focusable
                        onClick={onClose}
                        className="block w-full rounded-lg border border-white/10 bg-transparent py-3 text-sm font-semibold text-zinc-400 transition-colors hover:bg-white/5 hover:text-white active:scale-[0.98]"
                    >
                        Cancel
                    </button>
                </div>
            </motion.div>
        </div>
    );
};

/* ------------------------------------------------------------------ */
/*  Launch gate                                                       */
/* ------------------------------------------------------------------ */
const LaunchGate = ({ onLaunch, loading, state }) => (
    <div className="relative flex min-h-[calc(100dvh-4rem)] flex-col items-center justify-center overflow-hidden px-4 py-16">
        <div
            className="pointer-events-none absolute inset-0 opacity-40"
            style={{
                backgroundImage:
                    'linear-gradient(rgba(255,255,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.04) 1px, transparent 1px)',
                backgroundSize: '48px 48px',
            }}
            aria-hidden="true"
        />
        <div className="pointer-events-none absolute left-1/2 top-1/3 h-64 w-64 -translate-x-1/2 rounded-full bg-cyan-500/15 blur-3xl" aria-hidden="true" />
        <div className="pointer-events-none absolute left-1/2 top-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-primary/20 blur-3xl" aria-hidden="true" />

        <h1 className="relative z-10 text-center text-4xl font-bold tracking-tight text-white sm:text-5xl">
            Engine <span className="bg-gradient-to-r from-cyan-300 to-sky-400 bg-clip-text text-transparent">Initialization</span>
        </h1>

        <div className="relative z-10 mt-10 w-full max-w-md rounded-2xl border border-white/10 bg-[#121212]/95 p-8 text-center shadow-2xl backdrop-blur-xl">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl border border-cyan-400/30 bg-cyan-400/10 text-cyan-300">
                <Volume2 className="h-8 w-8" aria-hidden="true" />
            </div>
            <h2 className="mt-6 text-xl font-bold text-white">ApX Karaoke</h2>
            <p className="mt-3 text-sm leading-relaxed text-zinc-400">
                Launch the ApX Karaoke songbook powered by the YouTube karaoke database. Search any song, reserve it to
                the queue, then sing along with the YouTube karaoke video — mic input, pitch detection, effects, and
                recording built in.
            </p>
            <button
                type="button"
                data-focusable
                disabled={loading}
                onClick={onLaunch}
                className="mt-8 inline-flex h-12 w-full max-w-xs items-center justify-center gap-2 rounded-full bg-white px-6 text-base font-bold text-black transition-transform hover:bg-cyan-300 active:scale-[0.98] disabled:opacity-60"
            >
                {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <span aria-hidden="true">→</span>}
                {loading ? 'Loading songbook…' : 'Launch Player'}
            </button>
            <BootBadge state={state} />
        </div>
    </div>
);

/* ------------------------------------------------------------------ */
/*  UiPainter HUD overlay — queue parity, input display, transient     */
/* ------------------------------------------------------------------ */
const HudOverlay = ({ hud, playingCode }) => {
    if (!hud) return null;
    const { queue, inputDisplay, overlay, paused } = hud;
    const showQueue = queue.length > 0 || playingCode;
    return (
        <div className="pointer-events-none absolute left-2 top-2 z-20 flex flex-col gap-1.5 sm:left-3 sm:top-3">
            {showQueue && (
                <div className="flex items-center gap-2 rounded-md border border-cyan-400/20 bg-black/55 px-2 py-1 backdrop-blur-sm">
                    <ListMusic className="h-3.5 w-3.5 text-cyan-300" aria-hidden="true" />
                    <span className="font-mono text-[11px] font-bold text-cyan-200">
                        {playingCode || '—'}
                    </span>
                    {queue.length > 0 && (
                        <span className="rounded bg-cyan-400/15 px-1.5 py-0.5 text-[10px] font-bold text-cyan-300">
                            Q {queue.length}
                        </span>
                    )}
                </div>
            )}
            {inputDisplay && (
                <div className="rounded-md border border-white/10 bg-black/55 px-2 py-1 font-mono text-[11px] tracking-[0.2em] text-zinc-300 backdrop-blur-sm">
                    {inputDisplay.padEnd(6, '_').split('').join(' ')}
                </div>
            )}
            {paused && (
                <div className="rounded-md border border-amber-400/30 bg-amber-500/15 px-2 py-1 text-[11px] font-bold uppercase tracking-wide text-amber-300">
                    Paused
                </div>
            )}
            <AnimatePresence>
                {overlay && (
                    <motion.div
                        key={`${overlay.name}-${overlay.expires}`}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.18, ease: 'easeOut' }}
                        className="rounded-md border border-cyan-400/40 bg-cyan-400/20 px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-cyan-100 backdrop-blur-sm"
                    >
                        {overlay.name}
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

/* ------------------------------------------------------------------ */
/*  Page                                                              */
/* ------------------------------------------------------------------ */
const KaraokeLibraryPage = () => {
    const rootRef = useRef(null);
    const listRef = useRef(null);
    const bgVideoRef = useRef(null);
    const bgCanvasRef = useRef(null);
    const onSetupActivateRef = useRef(null);
    const onSetupSetColorRef = useRef(null);
    const [uiPainter, painterState] = useUiPainter();
    const uiSystem = uiPainter.uiSystem;
    const uiScreens = uiPainter.uiScreens;
    const uiState = painterState.system;
    const [launched, setLaunched] = useState(false);
    const [tab, setTab] = useState('songbook'); // remote | songbook | queue
    const [menuOpen, setMenuOpen] = useState(true);

    const [query, setQuery] = useState('');
    const [lang, setLang] = useState('All');
    const [sort, setSort] = useState('code');
    const [songs, setSongs] = useState([]);
    const [languages, setLanguages] = useState(LANGUAGES);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [visibleCount, setVisibleCount] = useState(SEARCH_LIMIT);
    const [loadingMore, setLoadingMore] = useState(false);

    const [codeBuffer, setCodeBuffer] = useState('');
    const [statusText, setStatusText] = useState('READY');
    const [statusTone, setStatusTone] = useState('idle');

    const [popupSong, setPopupSong] = useState(null);
    const [activeVideo, setActiveVideo] = useState(null);
    const [queue, setQueue] = useState([]);
    const [listSelection, setListSelection] = useState(0);
    const [voiceLang, setVoiceLang] = useState('en'); // 'en' | 'tl' — numpad voice announcement language

    // UiScreens — stage screen manager (IDLE / SEARCH / SETUP / RANKING / SCORE),
    // owned by the UiPainter coordinator. Derive the reactive snapshot here.
    const screensState = painterState.screens;

    useSpatialNav(rootRef, launched);

    // ---- UiPainter HUD sync — mirror local queue / code buffer / status into
    // the shared HUD module so the orchestrator and stage stay in parity. ----
    useEffect(() => {
        uiPainter.setQueue(queue.map((s) => ({ code: songCode(s), title: s.title, artist: s.artist || '' })));
    }, [queue, uiPainter]);

    useEffect(() => {
        uiPainter.setPlaybackInputDisplay(codeBuffer);
    }, [codeBuffer, uiPainter]);

    useEffect(() => {
        uiPainter.setStatus(statusText, statusTone);
    }, [statusText, statusTone, uiPainter]);

    // Route setup menu interactions through the UiPainter interaction bridge.
    useEffect(() => {
        uiPainter.setSetupInteractionHandler((action, payload) => {
            if (action === 'activate') onSetupActivateRef.current?.(payload);
            else if (action === 'setColor') onSetupSetColorRef.current?.(payload);
        });
        return () => uiPainter.setSetupInteractionHandler(null);
    }, [uiPainter]);

    // ---- YouTube karaoke database (the only song source) ----
    const searchYouTube = useCallback(async (q) => {
        setLoading(true);
        setError('');
        setSongs([]);
        setVisibleCount(SEARCH_LIMIT);
        setListSelection(0);
        try {
            const r = await apiServerClient.fetch(`/youtube/search?q=${encodeURIComponent(q)}`);
            if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
            const d = await r.json();
            setSongs(d.songs || []);
        } catch {
            setError('Could not search YouTube. Please try again.');
        } finally {
            setLoading(false);
        }
    }, []);

    const fetchTrending = useCallback(async () => {
        setLoading(true);
        setError('');
        setSongs([]);
        setVisibleCount(SEARCH_LIMIT);
        setListSelection(0);
        try {
            const r = await apiServerClient.fetch('/youtube/trending');
            if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
            const d = await r.json();
            setSongs(d.songs || []);
        } catch {
            setError('Could not load trending karaoke songs.');
        } finally {
            setLoading(false);
        }
    }, []);

    // ---- UiSystem boot loader — seed the songbook with trending YouTube
    // karaoke when the user launches the player. ----
    const loadCatalogData = useCallback(async () => {
        await fetchTrending();
    }, [fetchTrending]);

    // Attach the background video + freeze canvas to the UiSystem video bridge.
    // Re-attach once the main shell (and the video element) has mounted.
    useEffect(() => {
        uiSystem.attachVideo(bgVideoRef.current, bgCanvasRef.current);
    }, [uiSystem, launched]);

    // Run the standalone boot sequence (BOOT → LOADING DB → READY) and
    // surface the ready modal. If already ready (cached), just show the modal.
    const bootSystem = useCallback(() => {
        if (uiState.bootStatus === 'READY') {
            uiPainter.showStartOverlay();
        } else if (uiState.bootStatus === 'BOOT') {
            uiPainter.initialize({ loadCatalog: loadCatalogData });
        }
    }, [uiPainter, uiState.bootStatus, loadCatalogData]);

    // Enter the karaoke interface from the SYSTEM READY overlay.
    const enterInterface = useCallback(() => {
        setLaunched(true);
        setTab('songbook');
        setMenuOpen(true);
        uiPainter.setState('IDLE');
        uiPainter.setVideoMode(false);
    }, [uiPainter]);

    // Unfreeze the background once a new stage item has mounted.
    useEffect(() => {
        if (activeVideo) {
            const t = setTimeout(() => uiSystem.unfreezeVideo(), 90);
            return () => clearTimeout(t);
        }
        return undefined;
    }, [activeVideo, uiSystem]);

    // ---- Android deep-link handlers ----
    // Inbound: the native Android app (com.maruya.apx) loads this page in a
    // WebView and forwards intent extras as URL query params. Act on them
    // once the player is launched and the catalogue is ready.
    useEffect(() => {
        if (!launched || !songs.length) return;
        const sp = new URLSearchParams(window.location.search);
        const playCode = sp.get('play');
        const songParam = sp.get('song');
        const studio = sp.get('studio');
        if (playCode) {
            const match = songs.find((s, i) => songCode(s, i) === playCode);
            if (match) openPopup(match);
        } else if (songParam) {
            const match = songs.find((s) => songCode(s) === songParam);
            if (match) openPopup(match);
        }
        if (studio === '1') setTab('remote');
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [launched, songs]);

    const submitSearch = useCallback((e) => {
        if (e) e.preventDefault();
        setVisibleCount(SEARCH_LIMIT);
        setListSelection(0);
        const q = query.trim();
        if (q) searchYouTube(q);
        else fetchTrending();
    }, [query, searchYouTube, fetchTrending]);

    // Reset pagination + selection whenever filters or the remote code
    // buffer change so the top match is always highlighted.
    useEffect(() => {
        setVisibleCount(SEARCH_LIMIT);
        setListSelection(0);
    }, [query, lang, sort, codeBuffer]);

    const loadMore = useCallback(() => {
        if (loadingMore) return;
        setLoadingMore(true);
        setTimeout(() => {
            setVisibleCount((c) => c + SEARCH_LIMIT);
            setLoadingMore(false);
        }, 30);
    }, [loadingMore]);

    const filtered = useMemo(() => {
        let list = songs;
        if (lang !== 'All') list = list.filter((s) => (s.language || 'Other') === lang);
        const q = query.trim().toLowerCase();
        if (q) {
            list = list.filter(
                (s) =>
                    `${s.title} ${s.artist}`.toLowerCase().includes(q) ||
                    String(s.code) === q ||
                    String(s.code).startsWith(q),
            );
        }
        // Live filter by remote code buffer — keeps the songbook in sync
        // with the numpad input regardless of which tab is active.
        if (codeBuffer.length > 0) {
            list = list.filter((s, i) => songCode(s, i).startsWith(codeBuffer));
        }
        if (sort === 'title') {
            list = [...list].sort((a, b) => a.title.localeCompare(b.title));
        } else if (sort === 'artist') {
            list = [...list].sort((a, b) => a.artist.localeCompare(b.artist));
        }
        return list;
    }, [songs, lang, query, sort, codeBuffer, tab]);

    const displayList = useMemo(() => filtered.slice(0, visibleCount), [filtered, visibleCount]);

    const hasMore = visibleCount < filtered.length;

    // Code buffer → status preview
    useEffect(() => {
        if (!codeBuffer) {
            setStatusText('READY');
            setStatusTone('idle');
            return;
        }
        const match = songs.find((s, i) => songCode(s, i) === codeBuffer || songCode(s, i).startsWith(codeBuffer));
        if (match && songCode(match) === codeBuffer) {
            setStatusText((match.title || '').slice(0, 18));
            setStatusTone('hit');
        } else if (match) {
            setStatusText((match.title || '').slice(0, 18));
            setStatusTone('partial');
        } else {
            setStatusText('UNKNOWN');
            setStatusTone('miss');
        }
    }, [codeBuffer, songs]);

    // When the remote code buffer narrows the songbook, jump the songbook
    // selection to the top match and scroll it into view.
    useEffect(() => {
        if (!codeBuffer) return;
        if (displayList.length > 0) {
            setListSelection(0);
            const el = listRef.current?.querySelector('[data-song-idx="0"]');
            el?.scrollIntoView({ block: 'nearest' });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [codeBuffer]);

    const openPopup = useCallback((song) => setPopupSong(song), []);
    const closePopup = useCallback(() => setPopupSong(null), []);

    const startPlayFlow = useCallback(
        (song) => {
            setPopupSong(null);
            if (!song?.videoId) {
                toast.error('No YouTube video available for this song.');
                return;
            }
            uiSystem.freezeVideo();
            uiPainter.setPlayingCode(songCode(song));
            uiPainter.setVideoMode(true);
            uiPainter.setState('PLAYING');
            setActiveVideo({
                videoId: song.videoId,
                title: song.title,
                thumbnail: song.thumbnail,
                duration: song.duration,
                song,
            });
            setMenuOpen(false);
        },
        [uiSystem, uiPainter],
    );

    const reserveSong = useCallback((song) => {
        setQueue((q) => [...q, { ...song, queuedAt: Date.now() }]);
        setPopupSong(null);
        setStatusText('QUEUED');
        setStatusTone('hit');
        uiPainter.triggerOverlay('Reserved');
        setTab('queue');
    }, [uiPainter]);

    const reserveFirst = useCallback((song) => {
        setQueue((q) => [{ ...song, queuedAt: Date.now() }, ...q]);
        setPopupSong(null);
        setStatusText('1ST RES');
        setStatusTone('hit');
        uiPainter.triggerOverlay('1st Reserve');
        setTab('queue');
    }, [uiPainter]);

    const playNextFromQueue = useCallback(() => {
        setQueue((q) => {
            if (!q.length) return q;
            const [next, ...rest] = q;
            if (next?.videoId) {
                uiSystem.freezeVideo();
                uiPainter.setPlayingCode(songCode(next));
                uiPainter.setVideoMode(true);
                uiPainter.setState('PLAYING');
                setActiveVideo({
                    videoId: next.videoId,
                    title: next.title,
                    thumbnail: next.thumbnail,
                    duration: next.duration,
                    song: next,
                });
                setMenuOpen(false);
            } else {
                toast.error('No YouTube video available for this song.');
            }
            return rest;
        });
    }, [uiSystem, uiPainter]);

    // Voice announcement of a digit using the Web Speech API. Falls back
    // silently when speechSynthesis is unavailable. Supports English and
    // Tagalog (tl-PH) per the voiceLang toggle.
    const speakDigit = useCallback((digit) => {
        try {
            if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
            const synth = window.speechSynthesis;
            synth.cancel();
            const u = new SpeechSynthesisUtterance(digit);
            u.lang = voiceLang === 'tl' ? 'tl-PH' : 'en-US';
            u.rate = 0.9;
            u.pitch = 1;
            const voices = synth.getVoices();
            const want = voiceLang === 'tl' ? 'tl' : 'en';
            const v = voices.find((vv) => vv.lang && vv.lang.toLowerCase().startsWith(want));
            if (v) u.voice = v;
            synth.speak(u);
        } catch {
            /* speech unavailable — non-fatal */
        }
    }, [voiceLang]);

    // Numpad 0–9 → announce the digit, enter it into the song-code buffer,
    // and live-filter the songbook to matching codes.
    const pressNum = useCallback((digit) => {
        speakDigit(digit);
        setCodeBuffer((buf) => (buf + digit).slice(0, 6));
        if (navigator.vibrate) navigator.vibrate(15);
    }, [speakDigit]);

    const pressDel = useCallback(() => {
        setCodeBuffer((buf) => buf.slice(0, -1));
    }, []);

    const pressRes = useCallback(() => {
        if (!codeBuffer) return;
        const match = songs.find((s, i) => songCode(s, i) === codeBuffer);
        if (match) {
            openPopup(match);
            setCodeBuffer('');
        } else {
            setStatusText('UNKNOWN');
            setStatusTone('miss');
        }
    }, [codeBuffer, songs, openPopup]);

    const moveSelection = useCallback(
        (delta) => {
            setListSelection((i) => {
                const next = Math.max(0, Math.min(displayList.length - 1, i + delta));
                const el = listRef.current?.querySelector(`[data-song-idx="${next}"]`);
                el?.scrollIntoView({ block: 'nearest' });
                return next;
            });
        },
        [displayList.length],
    );

    const confirmSelection = useCallback(() => {
        const s = displayList[listSelection];
        if (s) openPopup(s);
    }, [displayList, listSelection, openPopup]);

    // ---- UiScreens integration ----
    const stageBusy = !!activeVideo;

    // Sync the search interface + screen to the stage whenever the query,
    // filters, or playback state change.
    useEffect(() => {
        if (stageBusy) return;
        const q = query.trim();
        if (q) {
            const results = filtered.slice(0, 200).map((s) => ({
                code: songCode(s),
                title: s.title,
                artist: s.artist || 'Unknown',
                tag: inferTag(s),
            }));
            uiScreens.updateSearch({
                query: q,
                results,
                selectedIndex: listSelection < results.length ? listSelection : 0,
                playing: false,
            });
            uiScreens.showSearch();
        } else {
            uiScreens.updateSearch({ query: '', results: [], selectedIndex: 0 });
            uiScreens.showIdle();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [query, filtered, stageBusy]);

    // Update SELECT-mode idle data when the highlighted songbook row changes.
    useEffect(() => {
        if (stageBusy) return;
        const s = displayList[listSelection];
        if (s) {
            uiScreens.updateIdleData({
                code: songCode(s),
                title: s.title,
                artist: s.artist || 'Unknown',
                tag: inferTag(s),
            });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [listSelection, displayList, stageBusy]);

    // Feed the YouTube songbook into the NEW_SONGS idle list once loaded.
    useEffect(() => {
        if (!songs.length) return;
        const newest = [...songs]
            .slice(0, 40)
            .map((s) => ({
                code: songCode(s),
                title: s.title,
                artist: s.artist || 'Unknown',
                tag: inferTag(s),
            }));
        uiScreens.setNewSongs(newest);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [songs]);

    // Load ranking (top scores) from the karaoke history in localStorage.
    useEffect(() => {
        try {
            const raw = localStorage.getItem('apx-karaoke-history');
            if (!raw) return;
            const list = JSON.parse(raw);
            if (Array.isArray(list)) uiScreens.setRanking(list);
        } catch {
            /* ignore */
        }
    }, [uiScreens]);

    const onNewSongsPage = useCallback(
        (page) => uiScreens.setNewSongsPage(page),
        [uiScreens],
    );

    const onSetupActivate = useCallback(
        (setting) => {
            if (!setting) return;
            // Move focus to the setting first, then activate.
            const cat = uiScreens.setupCurrentCategory();
            if (cat) {
                const idx = cat.settings.indexOf(setting);
                if (idx >= 0 && idx !== uiScreens.setupSelectedSetting) {
                    uiScreens.setupSelectedSetting = idx;
                    uiScreens.setupPane = 'settings';
                }
            }
            if (setting.type === 'action') {
                if (setting.id === 'reset') {
                    uiScreens.setupReset();
                    toast.success('Setup settings reset to defaults');
                } else if (setting.id === 'clearhistory') {
                    try { localStorage.removeItem('apx-karaoke-history'); } catch { /* ignore */ }
                    uiScreens.setRanking([]);
                    toast.success('Performance history cleared');
                } else if (setting.id === 'about') {
                    toast.info('ApX Karaoke · Web Edition · YouTube karaoke');
                }
                return;
            }
            uiScreens.setupActivate();
        },
        [uiScreens],
    );

    const onSetupSetColor = useCallback(
        (color) => uiScreens.setupSetColor(color),
        [uiScreens],
    );

    // Keep the interaction-bridge refs current so the UiPainter handler (set
    // once on mount) always calls the latest callbacks.
    onSetupActivateRef.current = onSetupActivate;
    onSetupSetColorRef.current = onSetupSetColor;

    // Setup-menu keyboard / remote navigation while the SETUP screen is active.
    useEffect(() => {
        if (screensState.screen !== 'SETUP') return undefined;
        const onKey = (e) => {
            const pane = uiScreens.setupPane;
            if (e.key === 'ArrowLeft') {
                if (pane === 'settings') { uiScreens.setupPane = 'categories'; uiScreens._emit(); e.preventDefault(); }
            } else if (e.key === 'ArrowRight') {
                if (pane === 'categories') { uiScreens.setupEnter(); e.preventDefault(); }
            } else if (e.key === 'ArrowUp') {
                if (pane === 'categories') uiScreens.setupMoveCategory(-1);
                else uiScreens.setupMoveSetting(-1);
                e.preventDefault();
            } else if (e.key === 'ArrowDown') {
                if (pane === 'categories') uiScreens.setupMoveCategory(1);
                else uiScreens.setupMoveSetting(1);
                e.preventDefault();
            } else if (e.key === 'Enter' || e.key === ' ') {
                if (pane === 'categories') uiScreens.setupEnter();
                else uiScreens.setupActivate();
                e.preventDefault();
            } else if (e.key === 'Escape' || e.key === 'Backspace') {
                uiScreens.back();
                e.preventDefault();
            }
        };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [screensState.screen, uiScreens]);

    const codeDisplay = useMemo(() => {
        const padded = codeBuffer.padEnd(6, '_').split('');
        return padded.join(' ');
    }, [codeBuffer]);

    const remoteStatusText = statusText;
    const remoteStatusTone = statusTone;

    const handleLaunch = () => {
        bootSystem();
    };

    /* ---------- LAUNCH GATE ---------- */
    if (!launched) {
        return (
            <Layout bare>
                <Helmet>
                    <title>ApX Karaoke — Songbook &amp; Player | ApX Player</title>
                    <meta
                        name="description"
                        content="ApX Karaoke: professional karaoke songbook powered by the YouTube karaoke database, with mic input, pitch detection, recording, and Smart TV controls."
                    />
                </Helmet>
                <div ref={rootRef}>
                    <LaunchGate
                        onLaunch={handleLaunch}
                        loading={uiState.bootStatus === 'LOADING DB'}
                        state={uiState}
                    />
                </div>
                <UiSystemModals uiSystem={uiSystem} state={uiState} onEnter={enterInterface} />
            </Layout>
        );
    }

    /* ---------- MAIN PLAYER SHELL ---------- */
    return (
        <div ref={rootRef} className="flex h-[100dvh] flex-col overflow-hidden bg-black text-zinc-100">
            <Helmet>
                <title>ApX Karaoke — Songbook &amp; Player | ApX Player</title>
                <meta
                    name="description"
                    content="ApX Karaoke songbook: search the MaruyaTVPH karaoke catalogue, reserve tracks, play YouTube karaoke with mic and pitch tools."
                />
            </Helmet>

            {/* Top chrome */}
            <header className="z-30 flex h-12 shrink-0 items-center gap-2 border-b border-white/10 bg-[#0a0a0a] px-2 sm:px-3">
                <Link
                    to="/"
                    data-focusable
                    className="inline-flex items-center gap-1.5 rounded-md px-2 py-1.5 text-xs font-semibold text-zinc-400 transition-colors hover:bg-white/5 hover:text-white"
                >
                    <ArrowLeft className="h-3.5 w-3.5" />
                    <span className="hidden sm:inline">ApX</span>
                </Link>
                <div className="flex items-center gap-2">
                    <span className="grid h-7 w-7 place-items-center rounded bg-primary">
                        <Film className="h-3.5 w-3.5 text-primary-foreground" />
                    </span>
                    <span className="text-sm font-bold tracking-wide">
                        ApX <span className="text-cyan-300">Karaoke</span>
                    </span>
                </div>

                <div className="ml-auto flex items-center gap-1.5 font-mono text-sm">
                    <span
                        className={cn(
                            'rounded-md border px-2 py-0.5 tracking-[0.2em]',
                            remoteStatusTone === 'hit'
                                ? 'border-cyan-400/40 bg-cyan-400/10 text-cyan-300'
                                : 'border-white/10 bg-white/5 text-zinc-300',
                        )}
                        aria-live="polite"
                    >
                        {codeDisplay}
                    </span>
                    <span
                        className={cn(
                            'hidden max-w-[9rem] truncate text-xs sm:inline',
                            remoteStatusTone === 'hit' && 'text-cyan-300',
                            remoteStatusTone === 'miss' && 'text-zinc-500',
                            remoteStatusTone === 'idle' && 'text-zinc-500',
                            remoteStatusTone === 'partial' && 'text-zinc-400',
                        )}
                    >
                        {remoteStatusText}
                    </span>
                </div>

                <button
                    type="button"
                    data-focusable
                    onClick={() => setMenuOpen((v) => !v)}
                    className="ml-1 grid h-9 w-9 place-items-center rounded-md bg-white/10 text-white active:scale-[0.98]"
                    aria-label={menuOpen ? 'Hide controls' : 'Show controls'}
                    aria-expanded={menuOpen}
                >
                    {menuOpen ? <ChevronDown className="h-4 w-4" /> : <ListMusic className="h-4 w-4" />}
                </button>
                {!isAndroidApp() && (
                    <button
                        type="button"
                        data-focusable
                        onClick={() => deepLinks.karaokeLibrary()}
                        className="hidden h-9 items-center gap-1 rounded-md border border-cyan-400/40 bg-cyan-400/10 px-2 text-xs font-semibold text-cyan-300 hover:bg-cyan-400/20 sm:inline-flex"
                        title="Open in the ApX Android app"
                    >
                        <Film className="h-3.5 w-3.5" /> App
                    </button>
                )}
            </header>

            {/* Stage + controls */}
            <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
                {/* VIDEO / STAGE */}
                <section
                    className={cn(
                        'relative flex min-h-0 flex-col bg-[#050505]',
                        menuOpen ? 'h-[38%] shrink-0 lg:h-auto lg:flex-1' : 'flex-1',
                    )}
                >
                    {/* Ambient standby background — looping bgv3.mp4 (muted) with
                        an animated gradient fallback. Fades out while a song
                        plays and back in when the stage returns to idle. */}
                    <video
                        ref={bgVideoRef}
                        src="/bgv3.mp4"
                        autoPlay
                        muted
                        loop
                        playsInline
                        aria-hidden="true"
                        className={cn(
                            'pointer-events-none absolute inset-0 h-full w-full object-cover transition-opacity duration-700',
                            activeVideo ? 'opacity-0' : 'opacity-50',
                        )}
                    />
                    <div
                        className={cn(
                            'pointer-events-none absolute inset-0 transition-opacity duration-700',
                            activeVideo ? 'opacity-0' : 'opacity-100',
                        )}
                        aria-hidden="true"
                    >
                        <div className="absolute left-1/4 top-1/4 h-72 w-72 -translate-x-1/2 rounded-full bg-cyan-500/15 blur-3xl" />
                        <div className="absolute right-1/4 bottom-1/4 h-64 w-64 translate-x-1/2 rounded-full bg-fuchsia-500/15 blur-3xl" />
                    </div>
                    <canvas
                        ref={bgCanvasRef}
                        className="pointer-events-none absolute inset-0 h-full w-full object-cover"
                        style={{ display: 'none' }}
                        aria-hidden="true"
                    />
                    <div
                        className="pointer-events-none absolute inset-0 opacity-30"
                        style={{
                            backgroundImage:
                                'linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)',
                            backgroundSize: '40px 40px',
                        }}
                        aria-hidden="true"
                    />

                    {/* UiPainter HUD overlay — queue parity + input display + transient overlays */}
                    <HudOverlay hud={painterState.hud} playingCode={painterState.playingCode} />

                    {activeVideo ? (
                        <div className="relative z-10 flex min-h-0 flex-1 flex-col overflow-y-auto p-2 sm:p-3">
                            <YoutubeKaraokePlayer
                                videoId={activeVideo.videoId}
                                title={activeVideo.song ? activeVideo.song.title : activeVideo.title}
                                author={activeVideo.author}
                                onClose={() => {
                                    setActiveVideo(null);
                                    setMenuOpen(true);
                                    uiPainter.setVideoMode(false);
                                    uiPainter.setPlayingCode('');
                                    uiPainter.setState('IDLE');
                                    if (queue.length) playNextFromQueue();
                                }}
                            />
                        </div>
                    ) : (
                        <UiScreensView
                            uiScreens={uiScreens}
                            state={screensState}
                            onNewSongsPage={onNewSongsPage}
                            onSetupActivate={onSetupActivate}
                            onSetupSetColor={onSetupSetColor}
                        />
                    )}
                </section>

                {/* CONTROLS DRAWER */}
                <AnimatePresence initial={false}>
                    {menuOpen && (
                        <motion.aside
                            initial={{ y: 40, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            exit={{ y: 40, opacity: 0 }}
                            transition={{ duration: 0.2, ease: 'easeOut' }}
                            className="z-20 flex min-h-0 flex-1 flex-col border-t border-white/10 bg-[#121212] lg:w-[min(420px,42vw)] lg:flex-none lg:border-l lg:border-t-0"
                        >
                            {/* Tabs */}
                            <div className="flex shrink-0 items-stretch border-b border-white/10 bg-[#1a1a1a]">
                                {[
                                    { id: 'remote', label: 'Remote' },
                                    { id: 'songbook', label: 'Songbook' },
                                    { id: 'queue', label: `Queue${queue.length ? ` (${queue.length})` : ''}` },
                                ].map((t) => (
                                    <button
                                        key={t.id}
                                        type="button"
                                        data-focusable
                                        onClick={() => setTab(t.id)}
                                        className={cn(
                                            'flex-1 py-3 text-xs font-bold uppercase tracking-wider transition-colors',
                                            tab === t.id
                                                ? 'border-b-2 border-cyan-400 bg-[#222] text-cyan-300'
                                                : 'text-zinc-500 hover:text-zinc-300',
                                        )}
                                    >
                                        {t.label}
                                    </button>
                                ))}
                                <button
                                    type="button"
                                    data-focusable
                                    onClick={() => setMenuOpen(false)}
                                    className="grid w-11 place-items-center text-zinc-500 hover:text-white"
                                    aria-label="Close menu"
                                >
                                    <X className="h-4 w-4" />
                                </button>
                            </div>

                            {/* REMOTE */}
                            {tab === 'remote' && (
                                <div className="flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto p-3">
                                    <div className="grid grid-cols-3 gap-2">
                                        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
                                            <button
                                                key={d}
                                                type="button"
                                                data-focusable
                                                onClick={() => pressNum(d)}
                                                className="rounded-md border border-[#2a2a2a] bg-[#1f1f1f] py-3 text-lg font-semibold text-zinc-200 shadow-[0_2px_0_#000] transition-transform active:translate-y-0.5 active:bg-cyan-400 active:text-black active:shadow-none"
                                            >
                                                {d}
                                            </button>
                                        ))}
                                        <button
                                            type="button"
                                            data-focusable
                                            onClick={pressDel}
                                            className="rounded-md border border-red-900/40 bg-[#4a1a1a] py-3 text-sm font-bold text-red-200 shadow-[0_2px_0_#000] active:translate-y-0.5 active:shadow-none"
                                        >
                                            DEL
                                        </button>
                                        <button
                                            type="button"
                                            data-focusable
                                            onClick={() => pressNum('0')}
                                            className="rounded-md border border-[#2a2a2a] bg-[#1f1f1f] py-3 text-lg font-semibold text-zinc-200 shadow-[0_2px_0_#000] active:translate-y-0.5 active:bg-cyan-400 active:text-black active:shadow-none"
                                        >
                                            0
                                        </button>
                                        <button
                                            type="button"
                                            data-focusable
                                            onClick={pressRes}
                                            className="rounded-md bg-cyan-400 py-3 text-sm font-bold text-black shadow-[0_2px_0_#006] active:translate-y-0.5 active:shadow-none"
                                        >
                                            RES
                                        </button>
                                    </div>

                                    {/* Live code-match preview — syncs the remote
                                        numpad with the songbook. Shows the top
                                        matches for the entered code, or a
                                        "No song found" notice. */}
                                    {codeBuffer && (
                                        <div className="rounded-lg border border-white/10 bg-[#181818] p-2">
                                            <p className="mb-1.5 flex items-center justify-between text-[10px] uppercase tracking-widest text-zinc-500">
                                                <span>Code match · {codeBuffer}</span>
                                                <button
                                                    type="button"
                                                    data-focusable
                                                    onClick={() => setTab('songbook')}
                                                    className="font-semibold text-cyan-300 hover:underline"
                                                >
                                                    View all
                                                </button>
                                            </p>
                                            {displayList.length > 0 ? (
                                                <ul className="space-y-px">
                                                    {displayList.slice(0, 4).map((s, i) => (
                                                        <li
                                                            key={s.id || songCode(s, i) + s.title}
                                                            className={cn(
                                                                'flex items-center justify-between rounded px-2 py-2',
                                                                i === 0 ? 'bg-cyan-400/15 ring-1 ring-cyan-400/40' : 'bg-[#222]',
                                                            )}
                                                        >
                                                            <div className="min-w-0 flex-1 pr-2">
                                                                <p className="truncate text-xs font-bold text-zinc-200">{s.title}</p>
                                                                <p className="truncate text-[10px] text-zinc-500">{s.artist || 'Unknown'}</p>
                                                            </div>
                                                            <span className="font-mono text-xs font-bold text-cyan-400">{songCode(s, i)}</span>
                                                        </li>
                                                    ))}
                                                </ul>
                                            ) : (
                                                <p className="px-2 py-3 text-center text-xs font-semibold text-zinc-500">
                                                    No song found for code {codeBuffer}
                                                </p>
                                            )}
                                        </div>
                                    )}

                                    <div className="flex gap-2">
                                        <div className="flex flex-[2] items-center justify-center rounded-lg bg-[#181818] p-2">
                                            <div className="grid grid-cols-3 grid-rows-3 gap-1">
                                                <span />
                                                <button
                                                    type="button"
                                                    data-focusable
                                                    onClick={() => moveSelection(-1)}
                                                    className="grid h-10 w-10 place-items-center rounded bg-[#333] text-white shadow-[0_2px_0_#000] active:translate-y-0.5 active:bg-cyan-400 active:text-black active:shadow-none"
                                                    aria-label="Up"
                                                >
                                                    <ChevronUp className="h-4 w-4" />
                                                </button>
                                                <span />
                                                <button
                                                    type="button"
                                                    data-focusable
                                                    onClick={() => setTab('songbook')}
                                                    className="grid h-10 w-10 place-items-center rounded bg-[#333] text-white shadow-[0_2px_0_#000] active:bg-cyan-400 active:text-black"
                                                    aria-label="Left"
                                                >
                                                    <ChevronLeft className="h-4 w-4" />
                                                </button>
                                                <button
                                                    type="button"
                                                    data-focusable
                                                    onClick={confirmSelection}
                                                    className="grid h-10 w-10 place-items-center rounded-full border border-[#555] bg-[#444] text-[10px] font-bold text-white active:scale-95 active:bg-cyan-400 active:text-black"
                                                >
                                                    OK
                                                </button>
                                                <button
                                                    type="button"
                                                    data-focusable
                                                    onClick={() => setTab('queue')}
                                                    className="grid h-10 w-10 place-items-center rounded bg-[#333] text-white shadow-[0_2px_0_#000] active:bg-cyan-400 active:text-black"
                                                    aria-label="Right"
                                                >
                                                    <ChevronRight className="h-4 w-4" />
                                                </button>
                                                <span />
                                                <button
                                                    type="button"
                                                    data-focusable
                                                    onClick={() => moveSelection(1)}
                                                    className="grid h-10 w-10 place-items-center rounded bg-[#333] text-white shadow-[0_2px_0_#000] active:translate-y-0.5 active:bg-cyan-400 active:text-black active:shadow-none"
                                                    aria-label="Down"
                                                >
                                                    <ChevronDown className="h-4 w-4" />
                                                </button>
                                                <span />
                                            </div>
                                        </div>
                                        <div className="flex flex-1 flex-col items-center justify-evenly rounded-lg bg-[#181818] py-2">
                                            <button
                                                type="button"
                                                data-focusable
                                                onClick={() => setMenuOpen(true)}
                                                className="grid h-12 w-12 place-items-center rounded-full bg-[#1a4a1a] text-emerald-200 shadow-[0_2px_0_#000] active:translate-y-0.5"
                                                aria-label="Open controls"
                                            >
                                                <Play className="h-5 w-5 fill-current" />
                                            </button>
                                            <button
                                                type="button"
                                                data-focusable
                                                onClick={() => {
                                                    setActiveVideo(null);
                                                    setCodeBuffer('');
                                                    uiPainter.setVideoMode(false);
                                                    uiPainter.setPlayingCode('');
                                                    uiPainter.setState('IDLE');
                                                }}
                                                className="grid h-12 w-12 place-items-center rounded-full bg-[#4a1a1a] text-red-200 shadow-[0_2px_0_#000] active:translate-y-0.5"
                                                aria-label="Stop"
                                            >
                                                <Square className="h-4 w-4 fill-current" />
                                            </button>
                                            <button
                                                type="button"
                                                data-focusable
                                                onClick={playNextFromQueue}
                                                className="grid h-12 w-12 place-items-center rounded-full bg-[#1a3a4a] text-sky-200 shadow-[0_2px_0_#000] active:translate-y-0.5"
                                                aria-label="Next in queue"
                                            >
                                                <SkipForward className="h-5 w-5" />
                                            </button>
                                        </div>
                                    </div>

                                    <div>
                                        <p className="mb-1 text-center text-[10px] uppercase tracking-widest text-zinc-600">
                                            Filters
                                        </p>
                                        <div className="grid grid-cols-2 gap-2">
                                            <label className="sr-only" htmlFor="oke-lang">
                                                Language
                                            </label>
                                            <select
                                                id="oke-lang"
                                                data-focusable
                                                value={lang}
                                                onChange={(e) => setLang(e.target.value)}
                                                className="h-10 rounded-md border border-[#333] bg-[#222] px-2 text-xs font-semibold text-zinc-200"
                                            >
                                                {languages.map((g) => (
                                                    <option key={g} value={g}>
                                                        {g === 'All' ? 'All languages' : g}
                                                    </option>
                                                ))}
                                            </select>
                                            <label className="sr-only" htmlFor="oke-sort">
                                                Sort
                                            </label>
                                            <select
                                                id="oke-sort"
                                                data-focusable
                                                value={sort}
                                                onChange={(e) => setSort(e.target.value)}
                                                className="h-10 rounded-md border border-[#333] bg-[#222] px-2 text-xs font-semibold text-zinc-200"
                                            >
                                                {SORTS.map((s) => (
                                                    <option key={s.id} value={s.id}>
                                                        {s.label}
                                                    </option>
                                                ))}
                                            </select>
                                        </div>
                                        <div className="mt-2 grid grid-cols-2 gap-2">
                                            <button
                                                type="button"
                                                data-focusable
                                                onClick={() => {
                                                    if (document.documentElement.requestFullscreen) {
                                                        document.documentElement.requestFullscreen().catch(() => {});
                                                    }
                                                }}
                                                className="inline-flex h-10 items-center justify-center gap-1 rounded-md bg-cyan-400 text-[11px] font-bold uppercase tracking-wide text-black"
                                            >
                                                <Fullscreen className="h-3.5 w-3.5" /> Full
                                            </button>
                                            <button
                                                type="button"
                                                data-focusable
                                                onClick={() => setVoiceLang((l) => (l === 'en' ? 'tl' : 'en'))}
                                                className="inline-flex h-10 items-center justify-center gap-1 rounded-md border border-white/10 bg-[#222] text-[11px] font-bold uppercase tracking-wide text-zinc-200"
                                                title="Toggle numpad voice announcement language"
                                            >
                                                <Volume2 className="h-3.5 w-3.5" /> Voice · {voiceLang === 'en' ? 'EN' : 'TL'}
                                            </button>
                                        </div>
                                        <div className="mt-2 grid grid-cols-2 gap-2">
                                            <button
                                                type="button"
                                                data-focusable
                                                onClick={() => uiScreens.showSetup()}
                                                className="inline-flex h-10 items-center justify-center gap-1 rounded-md border border-yellow-500/40 bg-yellow-500/10 text-[11px] font-bold uppercase tracking-wide text-yellow-300"
                                            >
                                                <Settings className="h-3.5 w-3.5" /> Setup
                                            </button>
                                            <button
                                                type="button"
                                                data-focusable
                                                onClick={() => uiScreens.showRanking()}
                                                className="inline-flex h-10 items-center justify-center gap-1 rounded-md border border-amber-500/40 bg-amber-500/10 text-[11px] font-bold uppercase tracking-wide text-amber-300"
                                            >
                                                <Trophy className="h-3.5 w-3.5" /> Ranking
                                            </button>
                                        </div>
                                        <div className="mt-2">
                                            <p className="mb-1 text-center text-[10px] uppercase tracking-widest text-zinc-600">
                                                Idle Display
                                            </p>
                                            <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
                                                {[
                                                    { id: 'SELECT', label: 'Select' },
                                                    { id: 'LOGO', label: 'Logo' },
                                                    { id: 'NEW_SONGS', label: 'New' },
                                                    { id: 'COMMERCIAL', label: 'Ad' },
                                                ].map((m) => (
                                                    <button
                                                        key={m.id}
                                                        type="button"
                                                        data-focusable
                                                        onClick={() => { uiScreens.setIdleMode(m.id); uiScreens.showIdle(); }}
                                                        className={cn(
                                                            'shrink-0 rounded-full px-3 py-1 text-[11px] font-semibold',
                                                            screensState.idleMode === m.id && screensState.screen === 'IDLE'
                                                                ? 'bg-cyan-400 text-black'
                                                                : 'bg-[#2a2a2a] text-zinc-400',
                                                        )}
                                                    >
                                                        {m.label}
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* SONGBOOK */}
                            {tab === 'songbook' && (
                                <div className="flex min-h-0 flex-1 flex-col">
                                    <div className="sticky top-0 z-10 border-b border-[#333] bg-[#1a1a1a] p-2">
                                        <form onSubmit={submitSearch} className="relative">
                                            <label htmlFor="mob-search" className="sr-only">
                                                Search title, artist or ID
                                            </label>
                                            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                                            <input
                                                id="mob-search"
                                                data-focusable
                                                type="search"
                                                autoComplete="off"
                                                autoCorrect="off"
                                                spellCheck={false}
                                                placeholder="Search Title, Artist or ID…"
                                                value={query}
                                                onChange={(e) => setQuery(e.target.value)}
                                                className="h-11 w-full rounded-md border border-[#444] bg-[#333] py-2 pl-10 pr-10 text-base text-white outline-none placeholder:text-zinc-500 focus:border-cyan-400/50"
                                            />
                                            {query ? (
                                                <button
                                                    type="button"
                                                    data-focusable
                                                    onClick={() => {
                                                        setQuery('');
                                                        submitSearch({ preventDefault() {} });
                                                    }}
                                                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-zinc-400"
                                                    aria-label="Clear search"
                                                >
                                                    <X className="h-4 w-4" />
                                                </button>
                                            ) : (
                                                <button
                                                    type="submit"
                                                    data-focusable
                                                    className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded bg-cyan-400 px-2 py-1 text-[10px] font-bold text-black"
                                                >
                                                    GO
                                                </button>
                                            )}
                                        </form>
                                        <div className="mt-2 flex items-center gap-2">
                                            <span className="rounded-full bg-red-500/15 px-3 py-1 text-[11px] font-semibold text-red-400">
                                                YouTube karaoke database
                                            </span>
                                        </div>
                                        <div className="mt-2 flex gap-2 overflow-x-auto no-scrollbar">
                                            {languages.map((g) => (
                                                <button
                                                    key={g}
                                                    type="button"
                                                    data-focusable
                                                    onClick={() => setLang(g)}
                                                    className={cn(
                                                        'shrink-0 rounded-full px-3 py-1 text-[11px] font-semibold',
                                                        lang === g
                                                            ? 'bg-cyan-400 text-black'
                                                            : 'bg-[#2a2a2a] text-zinc-400',
                                                    )}
                                                >
                                                    {g === 'All' ? 'All' : g}
                                                </button>
                                            ))}
                                        </div>
                                    </div>

                                    <div ref={listRef} id="mob-song-list" className="min-h-0 flex-1 overflow-y-auto bg-black p-1">
                                        {loading ? (
                                            <div className="space-y-1 p-1">
                                                {Array.from({ length: 10 }).map((_, i) => (
                                                    <div key={i} className="h-14 animate-pulse bg-[#222]" />
                                                ))}
                                            </div>
                                        ) : error ? (
                                            <div className="p-8 text-center">
                                                <AlertCircle className="mx-auto h-8 w-8 text-amber-400" />
                                                <p className="mt-3 text-sm font-semibold">{error}</p>
                                                <button
                                                    type="button"
                                                    data-focusable
                                                    onClick={() => window.location.reload()}
                                                    className="mt-4 rounded-md bg-[#333] px-4 py-2 text-xs font-bold"
                                                >
                                                    Try again
                                                </button>
                                            </div>
                                        ) : displayList.length === 0 ? (
                                            <div className="p-8 text-center text-sm text-zinc-500">No matches found</div>
                                        ) : (
                                            displayList.map((s, i) => {
                                                const code = songCode(s, i);
                                                const selected = i === listSelection;
                                                return (
                                                    <button
                                                        key={s.id || code + s.title}
                                                        type="button"
                                                        data-focusable
                                                        data-song-idx={i}
                                                        onClick={() => {
                                                            setListSelection(i);
                                                            openPopup(s);
                                                        }}
                                                        className={cn(
                                                            'song-item mb-px flex w-full items-center justify-between border-b border-[#333] border-l-[3px] bg-[#222] px-2.5 py-3 text-left transition-colors',
                                                            selected
                                                                ? 'border-l-cyan-400 bg-[#2c2c2c]'
                                                                : 'border-l-transparent hover:bg-[#2a2a2a]',
                                                        )}
                                                    >
                                                        <div className="min-w-0 flex-1 overflow-hidden pr-2">
                                                            <span className="block truncate text-[15px] font-bold text-zinc-200">
                                                                {s.title}
                                                            </span>
                                                            <span className="mt-0.5 flex items-center gap-1.5 text-xs text-zinc-500">
                                                                <span className="truncate">{s.artist || 'Unknown'}</span>
                                                                {s.language && (
                                                                    <span className="shrink-0 text-[10px] uppercase text-zinc-600">
                                                                        · {s.language}
                                                                    </span>
                                                                )}
                                                            </span>
                                                        </div>
                                                        <div className="flex shrink-0 items-center gap-2 pl-2">
                                                            <span className="font-mono text-sm font-bold text-cyan-400">
                                                                {code}
                                                            </span>
                                                        </div>
                                                    </button>
                                                );
                                            })
                                        )}

                                        {!loading && hasMore && displayList.length > 0 && (
                                            <div className="p-3">
                                                <button
                                                    type="button"
                                                    data-focusable
                                                    disabled={loadingMore}
                                                    onClick={loadMore}
                                                    className="flex w-full items-center justify-center gap-2 rounded-md bg-[#222] py-3 text-xs font-bold uppercase tracking-wide text-zinc-300"
                                                >
                                                    {loadingMore && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                                                    Load more songs
                                                </button>
                                            </div>
                                        )}

                                        <div className="border-t border-white/5 p-4 text-[11px] leading-relaxed text-zinc-600">
                                            Songbook powered by the YouTube karaoke database. Only perform songs you have rights to.{' '}
                                            <Link to="/content-rights" className="text-zinc-400 hover:underline">
                                                Content Rights
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* QUEUE */}
                            {tab === 'queue' && (
                                <div className="min-h-0 flex-1 overflow-y-auto bg-black p-2">
                                    {queue.length === 0 ? (
                                        <div className="p-10 text-center text-sm text-zinc-500">
                                            Queue is empty. Reserve songs from the Songbook.
                                        </div>
                                    ) : (
                                        <ul className="space-y-px">
                                            {queue.map((s, i) => (
                                                <li
                                                    key={`${s.id}-${s.queuedAt}`}
                                                    className="flex items-center gap-2 border-b border-[#333] bg-[#222] px-3 py-3"
                                                >
                                                    <span className="w-6 text-xs font-bold text-zinc-500">{i + 1}</span>
                                                    <div className="min-w-0 flex-1">
                                                        <p className="truncate text-sm font-bold text-zinc-200">{s.title}</p>
                                                        <p className="truncate text-xs text-zinc-500">{s.artist}</p>
                                                    </div>
                                                    <span className="font-mono text-xs font-bold text-cyan-400">{songCode(s)}</span>
                                                    <button
                                                        type="button"
                                                        data-focusable
                                                        onClick={() => startPlayFlow(s)}
                                                        className="rounded bg-primary px-2 py-1 text-[10px] font-bold text-primary-foreground"
                                                    >
                                                        Play
                                                    </button>
                                                    <button
                                                        type="button"
                                                        data-focusable
                                                        onClick={() => setQueue((q) => q.filter((_, j) => j !== i))}
                                                        className="rounded bg-[#333] px-2 py-1 text-[10px] font-bold text-zinc-400"
                                                        aria-label="Remove"
                                                    >
                                                        ✕
                                                    </button>
                                                </li>
                                            ))}
                                        </ul>
                                    )}
                                    {queue.length > 0 && (
                                        <button
                                            type="button"
                                            data-focusable
                                            onClick={() => setQueue([])}
                                            className="mt-3 w-full rounded-md border border-white/10 py-2 text-xs font-semibold text-zinc-500"
                                        >
                                            Clear queue
                                        </button>
                                    )}
                                </div>
                            )}
                        </motion.aside>
                    )}
                </AnimatePresence>
            </div>

            <AnimatePresence>
                {popupSong && (
                    <SongActionPopup
                        song={popupSong}
                        onClose={closePopup}
                        onPlay={startPlayFlow}
                        onReserve={reserveSong}
                        onReserveFirst={reserveFirst}
                    />
                )}
            </AnimatePresence>

            <UiSystemModals uiSystem={uiSystem} state={uiState} onEnter={enterInterface} />
        </div>
    );
};

export default KaraokeLibraryPage;
