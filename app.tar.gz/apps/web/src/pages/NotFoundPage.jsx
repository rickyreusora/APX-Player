import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
const NotFoundPage = () => <Layout>
        <Helmet>
            <title>Page Not Found | ApX Player</title>
            <meta name="description" content="The page you were looking for is not available on ApX Player." />
        </Helmet>
        <div className="mx-auto max-w-xl px-4 py-32 text-center sm:px-6">
            <p className="display text-8xl text-primary">404</p>
            <h1 className="display mt-2 text-4xl">Cute ko ikaw Dili</h1>
            <p className="mt-3 text-sm text-muted-foreground">
                The page you were looking for has been moved, removed, or never existed.
            </p>
            <Link to="/browse" className="mt-8 inline-block min-h-[48px] rounded-sm bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground">
                Browse the catalogue
            </Link>
        </div>
    </Layout>;
export default NotFoundPage;