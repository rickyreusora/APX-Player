import React from 'react';
import { Helmet } from 'react-helmet';
import Layout from '@/components/Layout';
import DocPage from '@/components/DocPage';

const TermsPage = () => (
    <Layout>
        <Helmet>
            <title>Terms of Use | ApX Player</title>
            <meta name="description" content="Terms of Use for ApX Player by MaruyaTVPH — the rules and conditions that govern access to and use of the ApX Player streaming and karaoke service." />
        </Helmet>
        <DocPage
            kicker="Legal"
            heading="Terms of Use"
            lastUpdated="October 7, 2026"
            intro="These Terms of Use (“Terms”) govern your access to and use of the ApX Player website and services operated by MaruyaTVPH at moviepinas.com and related domains (maruyatvph.com, maruyatvph.org) (the “Service”). By accessing or using the Service, you agree to be bound by these Terms. If you do not agree, do not use the Service."
            sections={[
                {
                    title: 'Eligibility',
                    body: [
                        'You must be at least 13 years old (or the minimum age of digital consent in your jurisdiction) to create an account. By using the Service, you represent that you meet this requirement and that you have the legal capacity to enter into these Terms.',
                    ],
                },
                {
                    title: 'Accounts',
                    body: [
                        'You are responsible for maintaining the accuracy of your account information and for keeping your password confidential. You are responsible for all activity that occurs under your account. Accounts may not be shared, transferred, or resold. Notify us immediately of any unauthorized use of your account.',
                    ],
                },
                {
                    title: 'Permitted use',
                    body: ['You may use the Service only for personal, non-commercial viewing and karaoke entertainment. You agree that you will not:'],
                    list: [
                        'Record, download, redistribute, re-upload, broadcast, publicly perform, or otherwise exploit any title or content available on the Service, except where a download is explicitly offered through an authorized source.',
                        'Circumvent, disable, or otherwise interfere with access controls, digital rights management, or security features of the Service.',
                        'Use automated systems (such as bots, scrapers, or spiders) to access or collect data from the Service, except as permitted by us.',
                        'Attempt to gain unauthorized access to the Service, other accounts, computer systems, or networks connected to the Service.',
                        'Introduce viruses, malware, or any other malicious code, or transmit unsolicited communications.',
                        'Use the Service for any unlawful, fraudulent, or abusive purpose, or in a manner that could damage, disable, or impair the Service.',
                    ],
                },
                {
                    title: 'Content and intellectual property',
                    body: [
                        'The Service may contain movies, series, live TV, karaoke content, and other media. ApX Player only streams or provides access to content that the site operator is legally authorized to distribute. Content is owned by its respective rights holders and is protected by copyright and other intellectual property laws.',
                        'You retain ownership of content you create on the Service (such as playlists). By submitting user content, you grant us a limited, non-exclusive license to host, store, and display it as needed to operate the Service. You represent that you have the rights to any content you submit.',
                    ],
                },
                {
                    title: 'Premium access and payments',
                    body: [
                        'Certain features may require premium access. Premium access is granted after a donation or payment is submitted and approved by an administrator. Payments are processed by third-party payment providers; we do not store full payment card details.',
                        'Unless required by law, payments and donations are generally non-refundable once premium access has been granted. If you believe a charge is incorrect, contact us with the transaction details.',
                    ],
                },
                {
                    title: 'Credits',
                    body: [
                        'Credits are a virtual balance used within the Service and have no cash value unless required by applicable law. Credits are non-transferable and may expire or be adjusted in accordance with our policies. We may modify credit balances to correct errors or reverse fraudulent activity.',
                    ],
                },
                {
                    title: 'Advertising',
                    body: [
                        'The Service is supported by advertising, including ads served by third-party advertising networks such as Google AdSense. We are not responsible for the content of third-party advertisements or the practices of advertisers. You should review the terms and privacy policies of any third-party advertiser before interacting with their offers.',
                    ],
                },
                {
                    title: 'Third-party services and links',
                    body: [
                        'The Service may contain links to or integrate third-party websites, services, and content (such as YouTube, Google, and payment providers). We do not control and are not responsible for third-party content, services, or practices. Your use of third-party services is at your own risk and subject to their terms and policies.',
                    ],
                },
                {
                    title: 'Catalogue availability',
                    body: [
                        'Titles and content may be added, modified, or removed at any time as licences begin and expire, or for operational reasons. We do not guarantee that any specific title will remain available, and we may modify, suspend, or discontinue any part of the Service at any time without notice.',
                    ],
                },
                {
                    title: 'Disclaimers',
                    body: [
                        'The Service is provided “as is” and “as available,” without warranties of any kind, whether express or implied, including implied warranties of merchantability, fitness for a particular purpose, or non-infringement. We do not warrant that the Service will be uninterrupted, error-free, secure, or that any content is accurate or complete.',
                    ],
                },
                {
                    title: 'Limitation of liability',
                    body: [
                        'To the maximum extent permitted by law, MaruyaTVPH and its operators shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of data, profits, or revenue, arising out of or related to your use of, or inability to use, the Service, even if advised of the possibility of such damages.',
                    ],
                },
                {
                    title: 'Indemnification',
                    body: [
                        'You agree to indemnify and hold harmless MaruyaTVPH and its operators from any claims, damages, losses, or expenses (including reasonable legal fees) arising out of your use of the Service, your violation of these Terms, or your infringement of any third-party rights.',
                    ],
                },
                {
                    title: 'Termination',
                    body: [
                        'We may suspend or terminate your access to the Service at any time, without notice, if we believe you have violated these Terms or for any other reason. You may stop using the Service and request deletion of your account at any time from your account page. Provisions that by their nature should survive termination (such as disclaimers, limitation of liability, and indemnification) will remain in effect.',
                    ],
                },
                {
                    title: 'Changes to these Terms',
                    body: [
                        'We may revise these Terms from time to time. The most current version will be posted on this page with a revised “Last updated” date. Your continued use of the Service after changes take effect constitutes acceptance of the updated Terms.',
                    ],
                },
                {
                    title: 'Governing law',
                    body: [
                        'These Terms are governed by the laws of the jurisdiction in which the site operator is established, without regard to conflict-of-law principles. You agree to the exclusive jurisdiction of the courts of that jurisdiction for any disputes arising from these Terms, except where local consumer-protection law requires otherwise.',
                    ],
                },
                {
                    title: 'Contact',
                    body: [
                        'Questions about these Terms can be sent to support@moviepinas.com or admin@maruyatvph.com, or through the details on our Contact page.',
                    ],
                },
            ]}
        />
    </Layout>
);

export default TermsPage;
