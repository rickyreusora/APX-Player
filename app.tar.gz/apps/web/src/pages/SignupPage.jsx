import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { toast } from 'sonner';
import Layout from '@/components/Layout';
import GoogleSignInButton from '@/components/GoogleSignInButton';
import { useGoogleAuth } from '@/hooks/useGoogleAuth';
import { useAuth } from '@/contexts/AuthContext';

const SignupPage = () => {
    const { signup, loginWithGoogle, isAuthed } = useAuth();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const { available: googleAvailable } = useGoogleAuth();
    const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
    const [busy, setBusy] = useState(false);
    const [googleBusy, setGoogleBusy] = useState(false);
    const [error, setError] = useState('');

    if (isAuthed) return <Navigate to="/dashboard" replace />;

    const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

    const onSubmit = async (e) => {
        e.preventDefault();
        setError('');
        if (!form.email || !form.password) return setError('Email and password are required.');
        if (form.password.length < 8) return setError('Password must be at least 8 characters.');
        if (form.password !== form.confirm) return setError('Passwords do not match.');
        setBusy(true);
        try {
            await signup(form.email, form.password, { name: form.name, role: 'user' });
            toast.success('Account created');
            const returnTo = searchParams.get('return_to');
            navigate(returnTo && returnTo.startsWith('/') ? returnTo : '/dashboard');
        } catch (err) {
            setError(err?.response?.data?.email?.message || err?.message || 'Could not create the account.');
        } finally {
            setBusy(false);
        }
    };

    const onGoogle = async () => {
        setGoogleBusy(true);
        setError('');
        try {
            await loginWithGoogle();
            toast.success('Account created');
            const returnTo = searchParams.get('return_to');
            navigate(returnTo && returnTo.startsWith('/') ? returnTo : '/dashboard');
        } catch (err) {
            setError(err?.message || 'Google sign-up was cancelled or failed.');
        } finally {
            setGoogleBusy(false);
        }
    };

    return (
        <Layout>
            <Helmet>
                <title>Create an Account | ApX Player</title>
                <meta name="description" content="Create a free ApX Player account to save favourites, build playlists and resume watching across devices." />
            </Helmet>
            <div className="mx-auto max-w-md px-4 py-20 sm:px-6">
                <div className="mb-2 h-1.5 w-16 rounded-full grad-ax-warm" aria-hidden="true" />
                <h1 className="font-display text-5xl font-extrabold">Create <span className="text-grad-warm">account</span></h1>
                <p className="mt-2 text-sm text-muted-foreground">Favourites, playlists and resume-watching, all synced.</p>

                {googleAvailable && (
                    <div className="mt-8">
                        <GoogleSignInButton label="Sign up with Google" onClick={onGoogle} busy={googleBusy} />
                        <div className="relative my-6">
                            <div className="absolute inset-0 flex items-center">
                                <div className="w-full border-t border-white/10" />
                            </div>
                            <div className="relative flex justify-center">
                                <span className="bg-background px-3 text-xs uppercase tracking-wider text-muted-foreground">or</span>
                            </div>
                        </div>
                    </div>
                )}

                <form onSubmit={onSubmit} className="space-y-5" noValidate>
                    <div className="flex flex-col gap-2">
                        <label htmlFor="name" className="text-sm font-medium">
                            Display name
                        </label>
                        <input id="name" value={form.name} onChange={set('name')} className="focus-glow h-12 rounded-xl border border-white/10 bg-white/5 px-4 text-sm" />
                    </div>
                    <div className="flex flex-col gap-2">
                        <label htmlFor="email" className="text-sm font-medium">
                            Email
                        </label>
                        <input id="email" type="email" autoComplete="email" value={form.email} onChange={set('email')} required className="focus-glow h-12 rounded-xl border border-white/10 bg-white/5 px-4 text-sm" />
                    </div>
                    <div className="flex flex-col gap-2">
                        <label htmlFor="password" className="text-sm font-medium">
                            Password
                        </label>
                        <input id="password" type="password" autoComplete="new-password" value={form.password} onChange={set('password')} required className="focus-glow h-12 rounded-xl border border-white/10 bg-white/5 px-4 text-sm" />
                        <span className="text-xs text-muted-foreground">At least 8 characters.</span>
                    </div>
                    <div className="flex flex-col gap-2">
                        <label htmlFor="confirm" className="text-sm font-medium">
                            Confirm password
                        </label>
                        <input id="confirm" type="password" autoComplete="new-password" value={form.confirm} onChange={set('confirm')} required className="focus-glow h-12 rounded-xl border border-white/10 bg-white/5 px-4 text-sm" />
                    </div>
                    {error && (
                        <p role="alert" className="rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-sm">
                            {error}
                        </p>
                    )}
                    <button type="submit" disabled={busy} className="focus-glow min-h-[48px] w-full rounded-full grad-ax text-sm font-semibold text-primary-foreground shadow-[0_0_20px_hsl(187_95%_55%/0.4)] transition-transform hover:scale-[1.02] active:scale-[0.98] disabled:opacity-60">
                        {busy ? 'Creating account…' : 'Create account'}
                    </button>
                </form>

                <p className="mt-6 text-sm text-muted-foreground">
                    Already have an account?{' '}
                    <Link to="/login" className="text-primary underline underline-offset-4">
                        Sign in
                    </Link>
                </p>
            </div>
        </Layout>
    );
};

export default SignupPage;
