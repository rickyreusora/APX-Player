import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import {
    ChevronDown,
    Download,
    Film,
    Gift,
    Link2,
    ListVideo,
    Loader2,
    Search,
    Wallet,
    X,
} from 'lucide-react';
import Layout from '@/components/Layout';
import Seo from '@/components/Seo';
import TopUpModal from '@/components/TopUpModal';
import { useAuth } from '@/contexts/AuthContext';
import pb from '@/lib/pocketbaseClient';
import apiServerClient, { API_SERVER_URL } from '@/lib/apiServerClient';

const QUEUE_KEY = 'apx-download-queue';
const NEWS_KEY = 'apx-downloader-news-v1';

const LINK_PLATFORMS = [
    'YouTube', 'TikTok', 'Instagram', 'Facebook', 'X', 'RedNote', 'TED', 'Reddit',
];

const faqs = [
    {
        q: 'How does the ApX downloader work?',
        a: 'Search a movie or series title and ApX looks it up through the integrated video catalog. Open a result to see its seasons and episodes, then save any episode as an MP4 straight to your device.',
    },
    {
        q: 'Can I download videos with subtitles?',
        a: 'When the source provides captions, the download resolver lists them alongside the file. Subtitle tracks are not scraped from outside sites.',
    },
    {
        q: 'What video qualities are available?',
        a: 'ApX delivers the best resolution the source permits — typically 720P MP4. The exact quality depends on what the upstream provider authorizes for download.',
    },
    {
        q: 'Do I need to paste a video link?',
        a: 'No. Search by title. You can also paste a direct link from YouTube, TikTok, Instagram, Facebook, X, RedNote, TED, or Reddit into the link box to save that clip.',
    },
    {
        q: 'What kind of content can I search for?',
        a: 'Movies and TV series across the integrated catalog, including Tagalog-dubbed and multi-subtitle titles. Live TV, karaoke, and short dramas have their own pages linked below.',
    },
    {
        q: 'Where are saved items stored?',
        a: 'The download queue is saved in this browser so you can revisit episodes. Downloaded files go directly to your device’s downloads folder.',
    },
    {
        q: 'Is this free to use?',
        a: 'Every ApX account gets 3 free downloads. After that, each download costs 1 credit — top up credits anytime from the Downloader page. Some sources mark episodes as VIP-locked; those are clearly shown as unavailable for download.',
    },
    {
        q: 'What if a video will not download?',
        a: 'If an episode is VIP-locked or the source has no direct file, ApX shows it as unavailable. Try another episode or another title from the results.',
    },
];

const platforms = [
    { id: 'youtube', label: 'YouTube', to: '/karaoke-library', tone: '#ff3333', mark: 'YT' },
    { id: 'instagram', label: 'Instagram', to: '/pro-reels', tone: 'ig', mark: 'IG' },
    { id: 'facebook', label: 'Facebook', to: '/pro-reels', tone: '#1877f2', mark: 'f' },
    { id: 'rednote', label: 'RedNote', to: '/pro-reels', tone: '#ff2442', mark: 'RN' },
    { id: 'tiktok', label: 'TikTok', to: '/pro-reels', tone: '#fff', mark: 'TT', fresh: true },
    { id: 'x', label: 'X (Twitter)', to: '/browse', tone: '#fff', mark: 'X', fresh: true },
];

function loadQueue() {
    try {
        const raw = JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]');
        return Array.isArray(raw) ? raw : [];
    } catch {
        return [];
    }
}

function Mark({ item }) {
    if (item.tone === 'ig') {
        return (
            <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-gradient-to-br from-yellow-400 via-pink-500 to-purple-500 text-[0.55rem] font-bold text-white">
                IG
            </span>
        );
    }
    return (
        <span
            className="inline-flex h-5 w-5 items-center justify-center rounded-md text-[0.55rem] font-bold text-white"
            style={{ background: item.tone === '#fff' ? '#111' : item.tone, color: '#fff' }}
        >
            {item.mark}
        </span>
    );
}

function formatBytes(bytes) {
    if (!bytes) return '';
    if (bytes >= 1073741824) return `${(bytes / 1073741824).toFixed(1)} GB`;
    if (bytes >= 1048576) return `${Math.round(bytes / 1048576)} MB`;
    return `${Math.round(bytes / 1024)} KB`;
}

export default function DownloaderPage() {
    const { user, refreshUser } = useAuth();
    const [q, setQ] = useState('');
    const [submitted, setSubmitted] = useState('');
    const [items, setItems] = useState([]);
    const [status, setStatus] = useState('idle');
    const [error, setError] = useState('');
    const [page, setPage] = useState(1);
    const [hasMore, setHasMore] = useState(false);
    const [loadingMore, setLoadingMore] = useState(false);

    const [picked, setPicked] = useState(null);
    const [detail, setDetail] = useState(null);
    const [detailStatus, setDetailStatus] = useState('idle');
    const [activeSeason, setActiveSeason] = useState(1);
    const [epStates, setEpStates] = useState({});

    const [queue, setQueue] = useState(loadQueue);
    const [queueOpen, setQueueOpen] = useState(false);
    const [news, setNews] = useState(false);
    const [openFaq, setOpenFaq] = useState(null);
    const [quota, setQuota] = useState({ freeRemaining: 3, credits: 0 });
    const [topUpOpen, setTopUpOpen] = useState(false);

    const [link, setLink] = useState('');
    const [linkState, setLinkState] = useState('idle');
    const [linkError, setLinkError] = useState('');
    const [linkResult, setLinkResult] = useState(null);
    const [linkFormat, setLinkFormat] = useState(0);

    const [suggestions, setSuggestions] = useState([]);
    const [showSuggest, setShowSuggest] = useState(false);
    const suggestTimer = useRef(null);
    const blurTimer = useRef(null);

    useEffect(() => {
        if (!localStorage.getItem(NEWS_KEY)) setNews(true);
    }, []);

    // Load the caller's download quota (free remaining + credit balance).
    const loadQuota = useCallback(async () => {
        if (!pb.authStore.isValid) return;
        try {
            const r = await apiServerClient.fetch('/download/quota', {
                headers: { Authorization: `Bearer ${pb.authStore.token}` },
            });
            const data = await r.json().catch(() => ({}));
            if (r.ok && data) {
                setQuota({
                    freeRemaining: Number(data.freeRemaining) || 0,
                    credits: Number(data.credits) || 0,
                });
            }
        } catch {
            /* non-fatal */
        }
    }, []);

    useEffect(() => {
        loadQuota();
    }, [loadQuota, user?.id]);

    // Reserve one download (free or 1 credit) and return a single-use token.
    // Returns null when the user must top up (and opens the top-up modal).
    const claimDownload = useCallback(
        async (source) => {
            if (!pb.authStore.isValid) {
                toast.error('Sign in to download');
                return null;
            }
            let r;
            try {
                r = await apiServerClient.fetch('/download/claim', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${pb.authStore.token}`,
                    },
                    body: JSON.stringify({ source }),
                });
            } catch {
                toast.error('Could not start the download', {
                    description: 'Please try again in a moment.',
                });
                return null;
            }
            const data = await r.json().catch(() => ({}));
            if (r.status === 402 || data.needsTopUp) {
                setTopUpOpen(true);
                toast.error('No downloads left', {
                    description: 'You have used all 3 free downloads. Top up credits to continue — 1 credit per download.',
                });
                return null;
            }
            if (!r.ok || !data.token) {
                toast.error(data.error || 'Could not start the download');
                return null;
            }
            setQuota({
                freeRemaining: Number(data.remainingFree) || 0,
                credits: Number(data.credits) || 0,
            });
            refreshUser();
            return data.token;
        },
        [refreshUser],
    );

    useEffect(() => {
        localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
    }, [queue]);

    const dismissNews = () => {
        localStorage.setItem(NEWS_KEY, '1');
        setNews(false);
    };

    const fetchSuggestions = (term) => {
        if (suggestTimer.current) clearTimeout(suggestTimer.current);
        if (!term || term.trim().length < 2) {
            setSuggestions([]);
            return;
        }
        suggestTimer.current = setTimeout(async () => {
            try {
                const r = await apiServerClient.fetch(
                    `/aoneroom/suggest?keyword=${encodeURIComponent(term.trim())}`,
                );
                const data = await r.json().catch(() => ({}));
                setSuggestions(Array.isArray(data.suggestions) ? data.suggestions.slice(0, 8) : []);
            } catch {
                setSuggestions([]);
            }
        }, 250);
    };

    const onQChange = (e) => {
        const val = e.target.value;
        setQ(val);
        fetchSuggestions(val);
        setShowSuggest(true);
    };

    const onSearch = async (e, term, nextPage = 1) => {
        e?.preventDefault();
        const keyword = (term ?? q).trim();
        if (!keyword) return;
        setQ(keyword);
        setShowSuggest(false);
        if (nextPage === 1) {
            setSubmitted(keyword);
            setStatus('loading');
            setError('');
            setPicked(null);
            setDetail(null);
            setPage(1);
        } else {
            setLoadingMore(true);
        }
        try {
            const r = await apiServerClient.fetch(
                `/aoneroom/search?keyword=${encodeURIComponent(keyword)}&page=${nextPage}&perPage=18`,
            );
            const data = await r.json().catch(() => ({}));
            if (!r.ok) throw new Error(data.error || 'Search failed. Try again.');
            const next = data.items || [];
            setItems((prev) => (nextPage === 1 ? next : [...prev, ...next]));
            setHasMore(!!data.hasMore);
            setPage(nextPage);
            setStatus('done');
        } catch (err) {
            if (nextPage === 1) {
                setItems([]);
                setStatus('error');
                setError(err?.message || 'Search failed. Try again.');
            } else {
                toast.error('Could not load more results', { description: err?.message });
            }
        } finally {
            setLoadingMore(false);
        }
    };

    const onPick = async (subject) => {
        setPicked(subject);
        setDetail(null);
        setDetailStatus('loading');
        setEpStates({});
        setActiveSeason(1);
        try {
            const r = await apiServerClient.fetch(
                `/aoneroom/detail?detailPath=${encodeURIComponent(subject.detailPath)}`,
            );
            const data = await r.json().catch(() => ({}));
            if (!r.ok) throw new Error(data.error || 'Could not load details.');
            setDetail(data);
            setActiveSeason(data.seasons?.[0]?.season || 1);
            setDetailStatus('done');
        } catch (err) {
            setDetailStatus('error');
            setError(err?.message || 'Could not load details.');
        }
    };

    const setEpState = (key, state) => {
        setEpStates((prev) => ({ ...prev, [key]: state }));
    };

    const handleEpisodeDownload = async (subject, se, ep) => {
        const key = `${se}-${ep}`;
        setEpState(key, 'checking');
        try {
            const r = await apiServerClient.fetch(
                `/aoneroom/download?subjectId=${encodeURIComponent(subject.subjectId)}&se=${se}&ep=${ep}&detailPath=${encodeURIComponent(subject.detailPath)}`,
            );
            const data = await r.json().catch(() => ({}));
            if (!r.ok || !data.available) {
                setEpState(key, 'unavailable');
                const reason = data?.reason === 'vip_locked'
                    ? 'This episode is VIP-locked by its provider.'
                    : 'No downloadable file is available for this episode.';
                toast.error('Download unavailable', { description: reason });
                return;
            }
            const base = (subject.title || 'apx-video').replace(/[^\w]+/g, '_').replace(/^_+|_+$/g, '');
            const fname = `${base}_S${se}E${ep}.mp4`;
            const token = await claimDownload('aoneroom');
            if (!token) {
                setEpState(key, 'idle');
                return;
            }
            const a = document.createElement('a');
            a.href = `${API_SERVER_URL}/aoneroom/file?subjectId=${encodeURIComponent(subject.subjectId)}&se=${se}&ep=${ep}&detailPath=${encodeURIComponent(subject.detailPath)}&filename=${encodeURIComponent(fname)}&token=${encodeURIComponent(token)}`;
            a.download = fname;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setEpState(key, 'idle');
            toast.success('Download started', { description: 'Saving the episode to your device.' });
        } catch {
            setEpState(key, 'unavailable');
            toast.error('Could not check download availability', {
                description: 'Please try again in a moment.',
            });
        }
    };

    const addToQueue = (subject, se, ep) => {
        const id = `${subject.subjectId}-S${se}E${ep}`;
        setQueue((prev) => {
            if (prev.some((row) => row.id === id)) return prev;
            return [
                {
                    id,
                    title: subject.title,
                    poster: subject.poster || '',
                    subjectId: subject.subjectId,
                    detailPath: subject.detailPath,
                    season: se,
                    episode: ep,
                },
                ...prev,
            ].slice(0, 24);
        });
        setQueueOpen(true);
    };

    const queueCount = queue.length;
    const empty = status === 'idle' || (status === 'done' && items.length === 0 && !submitted);

    const resultLabel = useMemo(() => {
        if (status === 'loading') return 'Searching the video catalog…';
        if (status === 'error') return error;
        if (status === 'done' && submitted) {
            return items.length
                ? `${items.length} result${items.length === 1 ? '' : 's'} for “${submitted}”`
                : `No matches for “${submitted}”. Try another title.`;
        }
        return 'No recommendations yet. Try searching above.';
    }, [status, error, submitted, items.length]);

    const onLinkDownload = async (e) => {
        e?.preventDefault();
        const url = link.trim();
        if (!url) return;
        setLinkState('working');
        setLinkError('');
        setLinkResult(null);
        try {
            const r = await apiServerClient.fetch(
                `/download/link/resolve?url=${encodeURIComponent(url)}`,
            );
            const data = await r.json().catch(() => ({}));
            if (!r.ok || !data.available) {
                setLinkState('error');
                setLinkError(
                    data.error
                    || (data.reason === 'vip_locked'
                        ? 'This video is locked by its provider and cannot be downloaded.'
                        : 'No downloadable file is available for this link. It may be private, region-locked, or still processing.'),
                );
                return;
            }
            setLinkResult(data);
            setLinkFormat(0);
            setLinkState('done');
        } catch {
            setLinkState('error');
            setLinkError('The download service did not respond. Please try again in a moment.');
        }
    };

    const saveLinkFile = async () => {
        if (!linkResult) return;
        const fmt = linkResult.formats[linkFormat] || linkResult.formats[0];
        const base = (linkResult.title || 'apx-video').replace(/[^\w]+/g, '_').replace(/^_+|_+$/g, '');
        const ext = (fmt.ext || 'mp4').replace(/[^\w]/g, '') || 'mp4';
        const fname = `${base}_${fmt.quality || 'video'}.${ext}`;
        const token = await claimDownload('link');
        if (!token) return;
        const params = new URLSearchParams({
            url: link.trim(),
            format: String(linkFormat),
            filename: fname,
            token,
        });
        const a = document.createElement('a');
        a.href = `${API_SERVER_URL}/download/link/file?${params.toString()}`;
        a.download = fname;
        document.body.appendChild(a);
        a.click();
        a.remove();
        toast.success('Download started', { description: 'Saving the video file to your device.' });
    };

    const currentSeason = detail?.seasons?.find((s) => s.season === activeSeason) || detail?.seasons?.[0];
    const episodeList = currentSeason
        ? Array.from({ length: currentSeason.maxEp || 0 }, (_, i) => i + 1)
        : [];

    return (
        <Layout bare>
            <Helmet>
                <title>Downloader — ApX Player</title>
                <meta
                    name="description"
                    content="Search movies and TV shows on ApX Player, pick HD quality, and save episodes to your download queue."
                />
            </Helmet>
            <Seo
                title="Downloader — ApX Player"
                description="Search movies and TV shows on ApX Player, pick HD quality, and save episodes to your download queue."
            />
            <div className="relative min-h-[calc(100dvh-4rem)] overflow-hidden bg-[#05080c] text-white">
                <div className="pointer-events-none absolute inset-x-0 top-0 h-[38rem] bg-[radial-gradient(circle_at_top,rgba(0,255,157,0.16),transparent_42%),radial-gradient(circle_at_top_right,rgba(0,212,255,0.16),transparent_28%)]" />
                <div className="relative mx-auto w-full max-w-[1380px] px-4 pb-16 pt-4 md:px-6 md:pt-6">
                    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                        <div className="flex flex-wrap items-center gap-2">
                            <span className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 text-sm text-white/80">
                                <Gift className="h-4 w-4 text-[#00ff9d]" aria-hidden="true" />
                                {quota.freeRemaining > 0
                                    ? `${quota.freeRemaining} free download${quota.freeRemaining === 1 ? '' : 's'} left`
                                    : 'Free downloads used'}
                            </span>
                            <span className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 text-sm text-white/80">
                                <Wallet className="h-4 w-4 text-[#00d4ff]" aria-hidden="true" />
                                {quota.credits} credit{quota.credits === 1 ? '' : 's'}
                            </span>
                            {quota.freeRemaining === 0 && (
                                <button
                                    type="button"
                                    onClick={() => setTopUpOpen(true)}
                                    className="inline-flex min-h-11 items-center gap-2 rounded-full border border-[#00ff9d]/40 bg-[#00ff9d]/10 px-4 text-sm font-semibold text-[#00ff9d]"
                                >
                                    <Wallet className="h-4 w-4" aria-hidden="true" />
                                    Top up credits
                                </button>
                            )}
                        </div>
                        <button
                            type="button"
                            onClick={() => setQueueOpen(true)}
                            className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 text-sm text-white/80 hover:border-[#00ff9d]/40"
                        >
                            <ListVideo className="h-4 w-4 text-[#00ff9d]" aria-hidden="true" />
                            Queue
                            <span className="rounded-full bg-[#00ff9d] px-1.5 text-xs font-bold text-[#021a10]">{queueCount}</span>
                        </button>
                    </div>

                    <section className="mb-8 pt-2 text-center md:mb-10 md:pt-6">
                        <div className="mb-4 flex flex-wrap items-center justify-center gap-2">
                            {['ApX Save', 'HD MP4', 'Subtitles'].map((chip) => (
                                <span key={chip} className="rounded-full border border-white/10 bg-white/[0.05] px-3 py-1 text-[0.68rem] uppercase tracking-[0.18em] text-white/70">
                                    {chip}
                                </span>
                            ))}
                        </div>
                        <h1 className="text-balance text-3xl font-semibold leading-[1.08] text-white md:text-5xl">
                            Free Online Video Downloader
                        </h1>
                        <p className="mx-auto mt-3 max-w-2xl text-sm leading-7 text-white/60 md:text-base">
                            Search movies and TV shows by title, or paste a video link to save an HD MP4 straight to your device.
                        </p>
                        <p className="mx-auto mt-2 max-w-2xl text-xs leading-6 text-white/45">
                            Every account gets <span className="font-semibold text-white/70">3 free downloads</span>. After that, each download costs <span className="font-semibold text-white/70">1 credit</span>. Top up credits anytime to keep saving.
                        </p>
                    </section>

                    <form onSubmit={onSearch} className="mx-auto w-full max-w-[1120px]" autoComplete="off">
                        <div className="relative">
                            <Search className="pointer-events-none absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-white/50" aria-hidden="true" />
                            <label htmlFor="dl-search" className="sr-only">Search movies and shows</label>
                            <input
                                id="dl-search"
                                value={q}
                                onChange={onQChange}
                                onFocus={() => suggestions.length && setShowSuggest(true)}
                                onBlur={() => { blurTimer.current = setTimeout(() => setShowSuggest(false), 150); }}
                                placeholder="Search video, movie, TV show, or anime title..."
                                className="w-full rounded-[22px] border border-white/10 bg-white/[0.04] py-4 pl-14 pr-32 text-sm font-medium text-white placeholder:text-white/40 focus:border-[#00ff9d]/50 focus:outline-none md:py-5 md:text-base"
                            />
                            <button
                                type="submit"
                                className="absolute right-2.5 top-1/2 min-h-10 min-w-[100px] -translate-y-1/2 rounded-[20px] border border-white/10 bg-[linear-gradient(135deg,#00ff9d_0%,#00c8b8_48%,#00d4ff_100%)] px-4 text-xs font-semibold text-[#021a10] shadow-[0_14px_34px_rgba(0,255,157,0.22)] active:scale-[0.98] md:min-w-[112px] md:text-sm"
                            >
                                Search
                            </button>
                            {showSuggest && suggestions.length > 0 && (
                                <ul className="absolute left-0 right-0 top-full z-30 mt-2 overflow-hidden rounded-2xl border border-white/10 bg-[#0c1218] text-left shadow-2xl">
                                    {suggestions.map((s) => (
                                        <li key={s}>
                                            <button
                                                type="button"
                                                className="flex w-full items-center gap-2 px-5 py-2.5 text-sm text-white/75 hover:bg-white/5"
                                                onMouseDown={(e) => { e.preventDefault(); onSearch(e, s); }}
                                            >
                                                <Search className="h-3.5 w-3.5 text-white/35" aria-hidden="true" />
                                                {s}
                                            </button>
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    </form>
                    <form onSubmit={onLinkDownload} className="mx-auto mt-3 w-full max-w-[1120px]">
                        <div className="relative">
                            <Link2 className="pointer-events-none absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-white/50" aria-hidden="true" />
                            <label htmlFor="dl-link" className="sr-only">Paste a video link</label>
                            <input
                                id="dl-link"
                                value={link}
                                onChange={(e) => setLink(e.target.value)}
                                placeholder="Or paste a YouTube, TikTok, Instagram, Facebook, X, RedNote, TED, or Reddit link…"
                                autoComplete="off"
                                inputMode="url"
                                className="w-full rounded-[22px] border border-white/10 bg-white/[0.04] py-4 pl-14 pr-36 text-sm font-medium text-white placeholder:text-white/40 focus:border-[#00d4ff]/50 focus:outline-none md:py-5 md:text-base"
                            />
                            <button
                                type="submit"
                                disabled={linkState === 'working' || !link.trim()}
                                className="absolute right-2.5 top-1/2 inline-flex min-h-10 min-w-[112px] -translate-y-1/2 items-center justify-center gap-1.5 rounded-[20px] border border-white/10 bg-white/10 px-4 text-xs font-semibold text-white hover:bg-white/15 active:scale-[0.98] disabled:opacity-55 md:text-sm"
                            >
                                {linkState === 'working'
                                    ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                                    : <Download className="h-4 w-4" aria-hidden="true" />}
                                {linkState === 'working' ? 'Working…' : 'Download'}
                            </button>
                        </div>
                        <div className="mt-2.5 flex flex-wrap items-center justify-center gap-1.5">
                            {LINK_PLATFORMS.map((name) => (
                                <span key={name} className="rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-0.5 text-[0.65rem] text-white/50">
                                    {name}
                                </span>
                            ))}
                        </div>
                    </form>

                    {linkState === 'working' && (
                        <div className="mx-auto mt-4 flex max-w-3xl items-center gap-3 rounded-[20px] border border-[#00d4ff]/25 bg-[#00d4ff]/[0.06] px-5 py-4 text-left">
                            <Loader2 className="h-5 w-5 shrink-0 animate-spin text-[#7fe6ff]" aria-hidden="true" />
                            <div>
                                <p className="text-sm font-semibold text-white">Fetching the video</p>
                                <p className="text-xs leading-5 text-white/55">Resolving the best available MP4. This usually takes a few seconds.</p>
                            </div>
                        </div>
                    )}

                    {linkState === 'error' && (
                        <div className="mx-auto mt-4 flex max-w-3xl items-start gap-3 rounded-[20px] border border-amber-400/25 bg-amber-400/[0.06] px-5 py-4 text-left">
                            <Film className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" aria-hidden="true" />
                            <p className="text-sm leading-6 text-amber-100/85">{linkError}</p>
                        </div>
                    )}

                    {linkState === 'done' && linkResult && (
                        <section className="mx-auto mt-4 max-w-3xl rounded-[24px] border border-[#00d4ff]/25 bg-[#0c1218] p-5 text-left md:p-6">
                            <p className="text-xs uppercase tracking-[0.16em] text-[#7fe6ff]">
                                {(linkResult.platform || 'video')} · ready to save
                            </p>
                            <h2 className="mt-1 text-lg font-semibold md:text-xl">{linkResult.title || 'Video'}</h2>
                            <div className="mt-4 flex flex-wrap gap-2">
                                {linkResult.formats.map((fmt, i) => (
                                    <button
                                        key={`${fmt.quality}-${i}`}
                                        type="button"
                                        onClick={() => setLinkFormat(i)}
                                        className={`min-h-11 rounded-2xl border px-4 text-sm ${linkFormat === i ? 'border-[#00d4ff]/50 bg-[#00d4ff]/10 text-[#7fe6ff]' : 'border-white/10 bg-white/[0.03] text-white/70'}`}
                                    >
                                        {fmt.quality || 'MP4'}{fmt.size ? ` · ${formatBytes(fmt.size)}` : ''}
                                    </button>
                                ))}
                            </div>
                            <button
                                type="button"
                                onClick={saveLinkFile}
                                className="mt-4 inline-flex min-h-11 items-center gap-2 rounded-full bg-[linear-gradient(135deg,#00ff9d,#00d4ff)] px-6 text-sm font-semibold text-[#021a10]"
                            >
                                <Download className="h-4 w-4" aria-hidden="true" />
                                Save {(linkResult.formats[linkFormat] || linkResult.formats[0]).quality || 'MP4'}
                            </button>
                        </section>
                    )}

                    <div className="mx-auto mt-4 flex max-w-[1120px] items-center justify-center gap-4 text-white/40 md:gap-6">
                        {['Search', 'Pick episode', 'Save'].map((step, i) => (
                            <span key={step} className="inline-flex items-center gap-1.5 text-xs md:text-sm">
                                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-white/[0.06] text-[0.6rem] font-semibold">{i + 1}</span>
                                {step}
                            </span>
                        ))}
                    </div>

                    <div className="mt-10 text-center">
                        <p className="text-sm text-white/58 md:text-base">{resultLabel}</p>
                        {status === 'loading' && (
                            <div className="mx-auto mt-6 grid max-w-5xl grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-6">
                                {Array.from({ length: 6 }).map((_, i) => (
                                    <div key={i} className="aspect-[2/3] animate-pulse rounded-2xl bg-white/[0.05]" />
                                ))}
                            </div>
                        )}
                        {status === 'done' && items.length > 0 && (
                            <ul className="mx-auto mt-6 grid max-w-5xl grid-cols-2 gap-3 text-left sm:grid-cols-3 md:grid-cols-6">
                                {items.map((title) => {
                                    const typeLabel = title.subjectType === 2 ? 'TV' : 'Movie';
                                    return (
                                        <li key={title.id}>
                                            <button
                                                type="button"
                                                onClick={() => onPick(title)}
                                                className="group w-full overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] text-left transition hover:border-[#00ff9d]/40"
                                            >
                                                <div className="relative aspect-[2/3] bg-black/40">
                                                    {title.poster ? (
                                                        <img src={title.poster} alt="" loading="lazy" className="h-full w-full object-cover" />
                                                    ) : (
                                                        <div className="grid h-full place-items-center text-white/30">
                                                            <Film className="h-8 w-8" />
                                                        </div>
                                                    )}
                                                    <span className="absolute left-1.5 top-1.5 rounded-md bg-black/70 px-1.5 py-0.5 text-[0.55rem] font-bold uppercase tracking-wide text-[#00ff9d] backdrop-blur-sm">
                                                        {typeLabel}
                                                    </span>
                                                    {title.rating > 0 && (
                                                        <span className="absolute right-1.5 top-1.5 inline-flex items-center gap-0.5 rounded-md bg-black/70 px-1.5 py-0.5 text-[0.55rem] font-semibold text-amber-300 backdrop-blur-sm">
                                                            ★ {title.rating.toFixed(1)}
                                                        </span>
                                                    )}
                                                    <span className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-2 pb-1.5 pt-6 text-[0.6rem] text-white/55 opacity-0 transition group-hover:opacity-100">
                                                        {title.year}{title.year && title.genre ? ' · ' : ''}{(title.genre || '').split(',').slice(0, 2).join(', ')}
                                                    </span>
                                                </div>
                                                <p className="truncate px-2 py-2 text-xs font-medium text-white/85">{title.title}</p>
                                            </button>
                                        </li>
                                    );
                                })}
                            </ul>
                        )}
                        {status === 'done' && hasMore && (
                            <div className="mt-6 text-center">
                                <button
                                    type="button"
                                    onClick={(e) => onSearch(e, submitted, page + 1)}
                                    disabled={loadingMore}
                                    className="inline-flex min-h-11 items-center gap-2 rounded-full border border-white/15 bg-white/5 px-6 text-sm text-white/80 disabled:opacity-60"
                                >
                                    {loadingMore && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
                                    {loadingMore ? 'Loading…' : 'Load more'}
                                </button>
                            </div>
                        )}
                        {empty && status !== 'loading' && (
                            <Film className="mx-auto mt-4 h-12 w-12 text-white/20" aria-hidden="true" />
                        )}
                    </div>

                    {picked && (
                        <section className="mx-auto mt-8 max-w-3xl rounded-[24px] border border-white/10 bg-[#0c1218] p-5 md:p-7">
                            <div className="flex gap-4">
                                {picked.poster && (
                                    <img src={picked.poster} alt="" className="hidden h-36 w-24 rounded-xl object-cover sm:block" />
                                )}
                                <div className="min-w-0 flex-1 text-left">
                                    <p className="text-xs uppercase tracking-[0.16em] text-[#00ff9d]">Download options</p>
                                    <h2 className="mt-1 text-xl font-semibold">{picked.title}</h2>
                                    <p className="mt-1 text-sm text-white/50">
                                        {picked.subjectType === 2 ? 'Series' : 'Movie'}{detail?.source ? ` · ${detail.source}` : ''}{picked.country ? ` · ${picked.country}` : ''}
                                    </p>
                                    {(picked.year || picked.rating > 0 || picked.genre) && (
                                        <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-white/55">
                                            {picked.year && <span>{picked.year}</span>}
                                            {picked.rating > 0 && (
                                                <span className="inline-flex items-center gap-0.5 text-amber-300">★ {picked.rating.toFixed(1)}</span>
                                            )}
                                            {picked.genre && <span className="text-white/45">{picked.genre}</span>}
                                        </div>
                                    )}
                                    {picked.description && (
                                        <p className="mt-2 line-clamp-3 text-xs leading-5 text-white/45">{picked.description}</p>
                                    )}
                                    {picked.subjectType !== 2 && (
                                        <div className="mt-4">
                                            <button
                                                type="button"
                                                onClick={() => handleEpisodeDownload(picked, 1, 1)}
                                                disabled={epStates['1-1'] === 'checking'}
                                                className="inline-flex min-h-11 items-center gap-2 rounded-full bg-[linear-gradient(135deg,#00ff9d,#00d4ff)] px-5 text-sm font-semibold text-[#021a10] disabled:opacity-60"
                                            >
                                                {epStates['1-1'] === 'checking' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Download className="h-4 w-4" aria-hidden="true" />}
                                                {epStates['1-1'] === 'checking' ? 'Checking…' : 'Download MP4'}
                                            </button>
                                            {epStates['1-1'] === 'unavailable' && (
                                                <p className="mt-3 text-xs text-amber-300/80">No downloadable file is available for this title.</p>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </div>

                            {picked.subjectType === 2 && (
                                <div className="mt-5 border-t border-white/10 pt-4">
                                    {detailStatus === 'loading' && (
                                        <div className="flex items-center gap-2 text-sm text-white/55">
                                            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Loading episodes…
                                        </div>
                                    )}
                                    {detailStatus === 'error' && (
                                        <p className="text-sm text-amber-300/80">Could not load episodes. Try another title.</p>
                                    )}
                                    {detailStatus === 'done' && detail && (
                                        <>
                                            {detail.seasons?.length > 1 && (
                                                <div className="mb-3 flex flex-wrap gap-2">
                                                    {detail.seasons.map((s) => (
                                                        <button
                                                            key={s.season}
                                                            type="button"
                                                            onClick={() => setActiveSeason(s.season)}
                                                            className={`min-h-9 rounded-full border px-3 text-xs ${activeSeason === s.season ? 'border-[#00ff9d]/50 bg-[#00ff9d]/10 text-[#00ff9d]' : 'border-white/10 bg-white/[0.03] text-white/70'}`}
                                                        >
                                                            Season {s.season}
                                                        </button>
                                                    ))}
                                                </div>
                                            )}
                                            {currentSeason && (
                                                <p className="mb-3 text-xs text-white/45">
                                                    Season {currentSeason.season} · {currentSeason.maxEp} episode{currentSeason.maxEp === 1 ? '' : 's'}
                                                    {currentSeason.resolutions?.length ? ` · ${currentSeason.resolutions.join('P / ')}P` : ''}
                                                </p>
                                            )}
                                            <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                                                {episodeList.map((ep) => {
                                                    const key = `${activeSeason}-${ep}`;
                                                    const st = epStates[key];
                                                    return (
                                                        <li key={ep} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-3 py-2.5">
                                                            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/[0.06] text-xs font-bold">E{ep}</span>
                                                            <span className="min-w-0 flex-1 truncate text-sm text-white/80">Episode {ep}</span>
                                                            <button
                                                                type="button"
                                                                onClick={() => addToQueue(picked, activeSeason, ep)}
                                                                className="grid h-9 w-9 place-items-center rounded-full border border-white/10 text-white/55 hover:text-[#00ff9d]"
                                                                aria-label={`Add episode ${ep} to queue`}
                                                            >
                                                                <ListVideo className="h-4 w-4" />
                                                            </button>
                                                            <button
                                                                type="button"
                                                                onClick={() => handleEpisodeDownload(picked, activeSeason, ep)}
                                                                disabled={st === 'checking'}
                                                                className="inline-flex min-h-9 items-center gap-1.5 rounded-full bg-[linear-gradient(135deg,#00ff9d,#00d4ff)] px-3 text-xs font-semibold text-[#021a10] disabled:opacity-60"
                                                            >
                                                                {st === 'checking' ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <Download className="h-3.5 w-3.5" aria-hidden="true" />}
                                                                {st === 'checking' ? '…' : 'Save'}
                                                            </button>
                                                        </li>
                                                    );
                                                })}
                                            </ul>
                                            {episodeList.length === 0 && (
                                                <p className="text-sm text-amber-300/80">No episodes listed for this season.</p>
                                            )}
                                        </>
                                    )}
                                </div>
                            )}
                        </section>
                    )}

                    <section className="mt-12">
                        <div className="mb-8 h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" />
                        <div className="relative overflow-hidden rounded-[28px] border border-white/10 bg-white/[0.03] px-5 py-7 md:px-8 md:py-9">
                            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                                <div className="max-w-xl text-left">
                                    <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.05] px-3 py-1.5">
                                        <span className="flex items-center gap-1">
                                            {platforms.slice(0, 4).map((p) => <Mark key={p.id} item={p} />)}
                                        </span>
                                        <span className="text-xs font-semibold uppercase tracking-[0.18em] text-white/70">Video Downloader</span>
                                    </div>
                                    <h2 className="text-xl font-semibold md:text-2xl">
                                        Open YouTube, Instagram <span className="bg-gradient-to-r from-[#00ff9d] to-[#00d4ff] bg-clip-text text-transparent">&amp; more in ApX</span>
                                    </h2>
                                    <p className="mt-2 text-sm leading-7 text-white/55 md:text-base">
                                        Paste a link from any of these platforms into the box above and ApX saves the MP4 for you. The buttons below open the matching ApX page.
                                    </p>
                                    <div className="mt-4 flex flex-wrap gap-2">
                                        {['In-app playback', 'MP4 in the player', 'Free search'].map((c) => (
                                            <span key={c} className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs text-white/60">{c}</span>
                                        ))}
                                    </div>
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    {platforms.map((p) => (
                                        <Link
                                            key={p.id}
                                            to={p.to}
                                            className="relative inline-flex min-h-11 items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white/80 hover:border-white/25"
                                        >
                                            {p.fresh && (
                                                <span className="absolute -right-1 -top-1 rounded-full bg-[#00d97e] px-1.5 py-px text-[0.55rem] font-bold uppercase text-black">NEW</span>
                                            )}
                                            <Mark item={p} />
                                            {p.label}
                                        </Link>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </section>

                    <section className="mt-10">
                        <div className="mb-8 h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" />
                        <div className="relative overflow-hidden rounded-[28px] border border-[rgba(0,255,157,0.18)] bg-[rgba(0,255,157,0.04)] px-5 py-7 md:px-8 md:py-9">
                            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                                <div className="max-w-xl text-left">
                                    <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-[rgba(0,255,157,0.18)] bg-[rgba(0,255,157,0.06)] px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-[#00d97e]">
                                        Official app
                                        <span className="rounded-full bg-[#00d97e] px-1.5 py-px text-[0.55rem] font-bold text-black">FREE</span>
                                    </div>
                                    <h2 className="text-xl font-semibold md:text-2xl">
                                        Install ApX Player <span className="bg-gradient-to-r from-[#00ff9d] to-[#00d4ff] bg-clip-text text-transparent">on this device</span>
                                    </h2>
                                    <p className="mt-2 text-sm leading-7 text-white/55">
                                        Add the web app or download the official MaruyaTVPH APK. No third-party extension is required.
                                    </p>
                                </div>
                                <div className="flex flex-col items-start gap-2">
                                    <button
                                        type="button"
                                        onClick={() => window.dispatchEvent(new CustomEvent('apx-open-install'))}
                                        className="inline-flex min-h-12 items-center gap-2 rounded-full bg-[linear-gradient(135deg,#00ff9d,#00d4ff)] px-6 text-sm font-semibold text-[#021a10]"
                                    >
                                        <Download className="h-4 w-4" aria-hidden="true" />
                                        Install ApX
                                    </button>
                                    <a className="text-xs text-white/45 underline" href="https://maruyatvph.com/apx/ApX.apk">
                                        Download official APK
                                    </a>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section className="mt-12 max-w-3xl space-y-8 text-left">
                        <div>
                            <h2 className="mb-4 text-xl font-semibold md:text-2xl">A downloader built around search</h2>
                            <div className="space-y-3 text-sm leading-7 text-white/60 md:text-base">
                                <p>ApX Downloader is for people who know the title, not a file link.</p>
                                <p>Search a movie or series, open the match, and save any episode as an MP4 — the best resolution the source authorizes.</p>
                            </div>
                        </div>
                        <div className="grid grid-cols-3 gap-3">
                            {[
                                ['480P', 'Compact'],
                                ['720P', 'Balanced'],
                                ['1080P', 'Sharp'],
                            ].map(([label, hint], i) => (
                                <div key={label} className={`rounded-2xl border p-4 text-center ${i === 1 ? 'border-white/20 bg-white/[0.05]' : 'border-white/10 bg-white/[0.03]'}`}>
                                    <div className={`text-lg font-semibold ${i === 1 ? 'bg-gradient-to-r from-[#00ff9d] to-[#00d4ff] bg-clip-text text-transparent' : ''}`}>{label}</div>
                                    <div className="text-xs text-white/50">{hint}</div>
                                </div>
                            ))}
                        </div>
                    </section>

                    <section className="mt-12">
                        <h2 className="mb-6 text-xl font-semibold md:text-2xl">Frequently Asked Questions</h2>
                        <div className="space-y-3">
                            {faqs.map((item, i) => {
                                const open = openFaq === i;
                                return (
                                    <div key={item.q} className="overflow-hidden rounded-[24px] border border-white/10 bg-white/[0.04]">
                                        <button
                                            type="button"
                                            className="flex w-full items-start justify-between gap-3 px-5 py-4 text-left md:px-6"
                                            aria-expanded={open}
                                            onClick={() => setOpenFaq(open ? null : i)}
                                        >
                                            <span className="flex items-start gap-3">
                                                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white/[0.08] text-sm font-bold">Q</span>
                                                <span className="pt-1 text-sm font-semibold md:text-base">{item.q}</span>
                                            </span>
                                            <ChevronDown className={`mt-1 h-4 w-4 shrink-0 text-white/60 transition ${open ? 'rotate-180' : ''}`} />
                                        </button>
                                        {open && (
                                            <div className="flex items-start gap-3 px-5 pb-5 md:px-6">
                                                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white/[0.08] text-sm font-bold text-white/70">A</span>
                                                <p className="pt-1 text-sm leading-7 text-white/65">{item.a}</p>
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </section>
                </div>
            </div>

            {news && (
                <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/70 p-4 backdrop-blur-md sm:items-center">
                    <div className="relative w-full max-w-sm overflow-hidden rounded-[28px] border border-[#00ff9d]/25 bg-[#071018] px-6 pb-6 pt-7 shadow-[0_0_0_1px_rgba(0,255,157,0.15)]">
                        <div className="absolute inset-x-0 top-0 h-px bg-[linear-gradient(90deg,transparent,rgba(0,255,157,0.7),rgba(0,212,255,0.5),transparent)]" />
                        <button type="button" onClick={dismissNews} className="absolute right-4 top-4 grid h-7 w-7 place-items-center rounded-full border border-white/10 text-white/50" aria-label="Close">
                            <X className="h-3.5 w-3.5" />
                        </button>
                        <div className="mb-5 inline-flex items-center rounded-full border border-white/10 px-3 py-1 text-[0.65rem] uppercase tracking-[0.18em] text-white/70">
                            <span className="mr-1.5 h-1.5 w-1.5 animate-pulse rounded-full bg-[#00ff9d]" />
                            What&apos;s new
                        </div>
                        <h2 className="text-2xl font-bold">
                            Save episodes as<br />
                            <span className="bg-gradient-to-r from-[#00ff9d] to-[#00d4ff] bg-clip-text text-transparent">HD MP4 files</span>
                        </h2>
                        <p className="mt-2.5 text-sm leading-6 text-white/55">
                            Search a series, open it, and save any episode straight to your device. Add episodes to the queue to revisit them later.
                        </p>
                        <button type="button" onClick={() => { dismissNews(); setQueueOpen(true); }} className="mt-5 flex w-full items-center gap-3 rounded-2xl border border-[rgba(0,255,157,0.22)] bg-[linear-gradient(135deg,rgba(0,255,157,0.1),rgba(0,212,255,0.06))] px-4 py-3.5 text-left">
                            <span className="grid h-10 w-10 place-items-center rounded-xl bg-[rgba(0,255,157,0.15)] text-[#00ff9d]">
                                <Download className="h-5 w-5" />
                            </span>
                            <span>
                                <span className="block text-sm font-semibold">Download Queue</span>
                                <span className="text-xs text-white/50">Multi-episode select · progress panel</span>
                            </span>
                        </button>
                        <Link to="/browse?kind=series" onClick={dismissNews} className="mt-2.5 flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3.5">
                            <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/10 text-sm font-bold">TV</span>
                            <span className="flex-1 text-left">
                                <span className="block text-sm font-semibold">Series library</span>
                                <span className="text-xs text-white/50">Browse shows in ApX</span>
                            </span>
                            <ChevronDown className="-rotate-90 h-4 w-4 text-white/40" />
                        </Link>
                        <button type="button" onClick={dismissNews} className="mt-4 w-full rounded-full border border-white/10 bg-white/[0.06] py-2.5 text-sm">
                            Got it
                        </button>
                    </div>
                </div>
            )}

            {queueOpen && (
                <div className="fixed inset-0 z-[70] flex justify-end bg-black/50" onClick={() => setQueueOpen(false)}>
                    <aside className="h-full w-full max-w-sm overflow-y-auto border-l border-white/10 bg-[#071018] p-5" onClick={(e) => e.stopPropagation()}>
                        <div className="mb-4 flex items-center justify-between">
                            <h2 className="text-lg font-semibold">Download queue</h2>
                            <button type="button" onClick={() => setQueueOpen(false)} className="grid h-9 w-9 place-items-center rounded-full border border-white/10" aria-label="Close queue">
                                <X className="h-4 w-4" />
                            </button>
                        </div>
                        {queue.length === 0 ? (
                            <p className="text-sm text-white/50">Nothing queued yet. Search a title and add an episode.</p>
                        ) : (
                            <ul className="space-y-2">
                                {queue.map((row) => (
                                    <li key={row.id} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-2">
                                        {row.poster ? <img src={row.poster} alt="" className="h-14 w-10 rounded-lg object-cover" /> : <span className="grid h-14 w-10 place-items-center rounded-lg bg-white/5"><Film className="h-4 w-4" /></span>}
                                        <div className="min-w-0 flex-1">
                                            <p className="truncate text-sm font-medium">{row.title}</p>
                                            <p className="text-xs text-white/45">S{row.season} · E{row.episode}</p>
                                        </div>
                                        <button type="button" className="grid h-9 w-9 place-items-center rounded-full border border-white/10 text-[#00d4ff]" onClick={() => handleEpisodeDownload({ subjectId: row.subjectId, detailPath: row.detailPath, title: row.title }, row.season, row.episode)} aria-label={`Download ${row.title}`}>
                                            <Download className="h-3.5 w-3.5" />
                                        </button>
                                        <button type="button" className="grid h-9 w-9 place-items-center rounded-full border border-white/10 text-white/40" onClick={() => setQueue((prev) => prev.filter((r) => r.id !== row.id))} aria-label="Remove">
                                            <X className="h-3.5 w-3.5" />
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        )}
                        {queue.length > 0 && (
                            <button type="button" className="mt-4 text-xs text-white/40" onClick={() => setQueue([])}>
                                Clear queue
                            </button>
                        )}
                    </aside>
                </div>
            )}

            <TopUpModal
                open={topUpOpen}
                onClose={() => setTopUpOpen(false)}
                user={user}
                onSuccess={() => loadQuota()}
            />
        </Layout>
    );
}
