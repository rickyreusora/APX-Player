import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Crown, Heart, ListPlus, Lock, Play, ShieldCheck, Star } from 'lucide-react';
import { toast } from 'sonner';
import Layout from '@/components/Layout';
import { ErrorState, LoadingState } from '@/components/StateBlocks';
import { useAuth } from '@/contexts/AuthContext';
import pb from '@/lib/pocketbaseClient';
import {
    addPlaylistItem,
    findFavorite,
    formatDuration,
    getTitleBySlug,
    listEpisodes,
    listPlaylists,
    toggleFavorite,
} from '@/lib/catalog';
import { isPremiumTitle } from '@/lib/premium';
import PremiumPromptModal from '@/components/PremiumPromptModal';

const TitleDetailPage = () => {
    const { slug } = useParams();
    const navigate = useNavigate();
    const [params] = useSearchParams();
    const { user, isAuthed, isPremium } = useAuth();
    const [title, setTitle] = useState(null);
    const [seasons, setSeasons] = useState([]);
    const [selectedSeason, setSelectedSeason] = useState(null);
    const [episodes, setEpisodes] = useState([]);
    const [loadingEpisodes, setLoadingEpisodes] = useState(false);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [isFav, setIsFav] = useState(false);
    const [playlists, setPlaylists] = useState([]);
    const [showTrailer, setShowTrailer] = useState(false);
    const [premiumPromptOpen, setPremiumPromptOpen] = useState(false);

    const load = async () => {
        setLoading(true);
        setError('');
        try {
            const rec = await getTitleBySlug(slug);
            setTitle(rec);
            if (rec.kind === 'series') {
                const ss = rec.seasons || [];
                setSeasons(ss);
                const first = ss[0]?.season_number || 1;
                setSelectedSeason(first);
            }
            if (user?.id) {
                setIsFav(!!(await findFavorite(user.id, rec.tmdb_id, rec.kind)));
                setPlaylists(await listPlaylists(user.id));
            }
        } catch (err) {
            setError(err?.status === 404 ? 'That title is not available.' : err?.message || 'Could not load this title.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [slug, user?.id]);

    useEffect(() => {
        if (title?.kind !== 'series' || !selectedSeason) return;
        let cancelled = false;
        setLoadingEpisodes(true);
        listEpisodes(title.tmdb_id, selectedSeason)
            .then((eps) => {
                if (!cancelled) setEpisodes(eps);
            })
            .catch(() => {
                if (!cancelled) setEpisodes([]);
            })
            .finally(() => {
                if (!cancelled) setLoadingEpisodes(false);
            });
        return () => {
            cancelled = true;
        };
    }, [title, selectedSeason]);

    const onToggleFav = async () => {
        if (!isAuthed) {
            navigate('/login');
            return;
        }
        try {
            const next = await toggleFavorite(user.id, title);
            setIsFav(next);
            toast.success(next ? 'Added to favourites' : 'Removed from favourites');
        } catch (err) {
            toast.error(err?.message || 'Could not update favourites.');
        }
    };

    const onAddToPlaylist = async (playlistId) => {
        if (!playlistId) return;
        try {
            await addPlaylistItem(user.id, playlistId, title);
            toast.success('Added to playlist');
        } catch (err) {
            toast.error(err?.message || 'Could not add to playlist.');
        }
    };

    if (loading) {
        return (
            <Layout>
                <LoadingState label="Loading title…" />
            </Layout>
        );
    }

    if (error || !title) {
        return (
            <Layout>
                <div className="py-24">
                    <ErrorState message={error} onRetry={load} />
                </div>
            </Layout>
        );
    }

    const genreNames = (title.genres || []).map((g) => g.name);
    const premiumRequired = params.get('premium') === '1' || isPremiumTitle(title);
    const premiumBlocked = premiumRequired && !isPremium;
    const watchTarget = title.kind === 'series'
        ? `/watch/${title.slug}?s=${selectedSeason || 1}&e=1${premiumRequired ? '&premium=1' : ''}`
        : `/watch/${title.slug}${premiumRequired ? '?premium=1' : ''}`;

    return (
        <Layout>
            <Helmet>
                <title>Title Details | ApX Player</title>
                <meta
                    name="description"
                    content="View movie and series details, cast, and playback options on ApX Player by MaruyaTVPH."
                />
            </Helmet>

            <section className="relative">
                <div className="relative h-[52vh] min-h-[340px] w-full overflow-hidden">
                    {title.backdrop && (
                        <img
                            src={title.backdrop}
                            alt={`Backdrop still from ${title.title}`}
                            className="h-full w-full object-cover"
                        />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
                </div>

                <div className="mx-auto -mt-40 max-w-[80rem] px-4 pb-16 sm:px-6">
                    <div className="grid gap-8 md:grid-cols-[240px_1fr]">
                        <div className="w-40 overflow-hidden rounded-sm border border-white/10 shadow-2xl shadow-black md:w-full">
                            {title.poster && (
                                <img src={title.poster} alt={`Poster artwork for ${title.title}`} className="w-full" />
                            )}
                        </div>

                        <div>
                            <h1 className="display text-5xl leading-none sm:text-6xl">{title.title}</h1>
                            <p className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
                                <span>{title.year || '—'}</span>
                                <span aria-hidden="true">·</span>
                                <span>{title.kind === 'series' ? 'Series' : 'Movie'}</span>
                                {title.duration_minutes ? (
                                    <>
                                        <span aria-hidden="true">·</span>
                                        <span>{formatDuration(title.duration_minutes)}</span>
                                    </>
                                ) : null}
                                {title.age_rating && (
                                    <span className="rounded-sm border border-border px-1.5 py-0.5 text-[11px]">{title.age_rating}</span>
                                )}
                                {!!title.rating && (
                                    <span className="inline-flex items-center gap-1">
                                        <Star className="h-3.5 w-3.5 fill-primary text-primary" aria-hidden="true" /> {title.rating}
                                    </span>
                                )}
                            </p>

                            {genreNames.length > 0 && (
                                <ul className="mt-4 flex flex-wrap gap-2">
                                    {genreNames.map((g) => (
                                        <li key={g} className="rounded-sm bg-secondary px-3 py-1 text-xs font-medium">
                                            {g}
                                        </li>
                                    ))}
                                </ul>
                            )}

                            <p className="mt-6 max-w-3xl text-base leading-relaxed text-foreground/85">{title.synopsis}</p>

                            <dl className="mt-6 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-3 text-sm sm:grid-cols-2">
                                {title.creator && (
                                    <div>
                                        <dt className="text-muted-foreground">Creator</dt>
                                        <dd className="font-medium">{title.creator}</dd>
                                    </div>
                                )}
                                {title.cast_list && (
                                    <div>
                                        <dt className="text-muted-foreground">Cast</dt>
                                        <dd className="font-medium">{title.cast_list}</dd>
                                    </div>
                                )}
                            </dl>

                            <div className="mt-8 flex flex-wrap gap-3">
                                {premiumBlocked ? (
                                    <button
                                        type="button"
                                        onClick={() => setPremiumPromptOpen(true)}
                                        className="inline-flex min-h-[48px] items-center gap-2 rounded-sm grad-ax px-7 text-base font-semibold text-primary-foreground transition-transform active:scale-[0.98]"
                                    >
                                        <Lock className="h-5 w-5" aria-hidden="true" /> Unlock with Premium
                                    </button>
                                ) : (
                                    <Link
                                        to={watchTarget}
                                        className="inline-flex min-h-[48px] items-center gap-2 rounded-sm bg-primary px-7 text-base font-semibold text-primary-foreground transition-transform hover:bg-primary/90 active:scale-[0.98]"
                                    >
                                        <Play className="h-5 w-5 fill-current" aria-hidden="true" /> Play
                                    </Link>
                                )}
                                {premiumRequired && (
                                    <span className="inline-flex min-h-[48px] items-center gap-1.5 rounded-sm border border-primary/40 bg-primary/10 px-4 text-sm font-semibold text-primary">
                                        <Crown className="h-4 w-4" aria-hidden="true" /> Premium title
                                    </span>
                                )}
                                {title.trailer_url && (
                                    <a
                                        href={title.trailer_url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="inline-flex min-h-[48px] items-center rounded-sm border border-border px-6 text-sm font-semibold transition-colors hover:border-primary hover:text-primary"
                                    >
                                        Watch trailer
                                    </a>
                                )}
                                <button
                                    type="button"
                                    onClick={onToggleFav}
                                    aria-pressed={isFav}
                                    className="inline-flex min-h-[48px] items-center gap-2 rounded-sm border border-border px-6 text-sm font-semibold transition-colors hover:border-primary hover:text-primary"
                                >
                                    <Heart className={isFav ? 'h-4 w-4 fill-primary text-primary' : 'h-4 w-4'} aria-hidden="true" />
                                    {isFav ? 'In favourites' : 'Add to favourites'}
                                </button>
                                {isAuthed && playlists.length > 0 && (
                                    <div className="inline-flex min-h-[48px] items-center gap-2 rounded-sm border border-border px-3">
                                        <ListPlus className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                                        <label htmlFor="add-playlist" className="sr-only">
                                            Add to playlist
                                        </label>
                                        <select
                                            id="add-playlist"
                                            defaultValue=""
                                            onChange={(e) => {
                                                onAddToPlaylist(e.target.value);
                                                e.target.value = '';
                                            }}
                                            className="bg-transparent text-sm"
                                        >
                                            <option value="">Add to playlist…</option>
                                            {playlists.map((p) => (
                                                <option key={p.id} value={p.id}>
                                                    {p.name}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                )}
                            </div>

                            <p className="mt-8 inline-flex items-start gap-2 rounded-sm border border-primary/30 bg-primary/5 p-4 text-xs leading-relaxed text-muted-foreground">
                                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                                <span>
                                    Catalogue data and artwork are provided by TMDB. Playback is handled by the Videasy
                                    embedded player.
                                </span>
                            </p>
                        </div>
                    </div>

                    {title.kind === 'series' && (
                        <section className="mt-16">
                            <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
                                <h2 className="display text-3xl">Episodes</h2>
                                {seasons.length > 0 && (
                                    <div>
                                        <label htmlFor="season-pick" className="mb-1.5 block text-xs text-muted-foreground">
                                            Season
                                        </label>
                                        <select
                                            id="season-pick"
                                            value={selectedSeason || ''}
                                            onChange={(e) => setSelectedSeason(Number(e.target.value))}
                                            className="h-11 rounded-sm border border-border bg-secondary/60 px-3 text-sm"
                                        >
                                            {seasons.map((s) => (
                                                <option key={s.season_number} value={s.season_number}>
                                                    {s.name || `Season ${s.season_number}`}
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                )}
                            </div>
                            {loadingEpisodes ? (
                                <p className="text-sm text-muted-foreground">Loading episodes…</p>
                            ) : episodes.length === 0 ? (
                                <p className="text-sm text-muted-foreground">No episodes found for this season.</p>
                            ) : (
                                <ul className="divide-y divide-border overflow-hidden rounded-sm border border-border">
                                    {episodes.map((ep) => (
                                        <li key={ep.id} className="flex flex-col gap-4 bg-card/40 p-4 sm:flex-row sm:items-center">
                                            {ep.still && (
                                                <img
                                                    src={ep.still}
                                                    alt={`Still from ${title.title} episode ${ep.episode_number}`}
                                                    className="h-24 w-full rounded-sm object-cover sm:w-44"
                                                    loading="lazy"
                                                />
                                            )}
                                            <div className="flex-1">
                                                <h3 className="text-sm font-semibold">
                                                    E{ep.episode_number} — {ep.name}
                                                </h3>
                                                <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{ep.synopsis}</p>
                                                {ep.duration_minutes ? (
                                                    <p className="mt-1 text-xs text-muted-foreground">{formatDuration(ep.duration_minutes)}</p>
                                                ) : null}
                                            </div>
                                            <Link
                                                to={`/watch/${title.slug}?s=${selectedSeason}&e=${ep.episode_number}${premiumRequired ? '&premium=1' : ''}`}
                                                onClick={(e) => {
                                                    if (premiumBlocked) {
                                                        e.preventDefault();
                                                        setPremiumPromptOpen(true);
                                                    }
                                                }}
                                                className="inline-flex min-h-[44px] items-center gap-2 self-start rounded-sm bg-secondary px-5 text-sm font-semibold transition-colors hover:bg-primary hover:text-primary-foreground"
                                            >
                                                <Play className="h-4 w-4 fill-current" aria-hidden="true" /> Play
                                            </Link>
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </section>
                    )}
                </div>
            </section>

            <PremiumPromptModal
                open={premiumPromptOpen}
                onClose={() => setPremiumPromptOpen(false)}
                titleName={title.title}
            />
        </Layout>
    );
};

export default TitleDetailPage;
