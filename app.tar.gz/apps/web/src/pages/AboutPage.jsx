import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import {
    Film,
    Radio,
    Mic2,
    Clapperboard,
    Download,
    ShieldCheck,
    Sparkles,
    MonitorSmartphone,
    Tv,
    Mail,
    Phone,
    MapPin,
    Facebook,
    Youtube,
    Music2,
    Globe,
    Send,
} from 'lucide-react';
import Layout from '@/components/Layout';

const features = [
    {
        icon: Film,
        title: 'Movies & Series',
        body: 'A curated catalogue of films and shows with rich detail pages, episodes, and seamless playback across every device you own.',
    },
    {
        icon: Radio,
        title: 'Live TV',
        body: 'Tune into live channels with adaptive streaming built for smooth playback on mobile data, home Wi-Fi, and big-screen TVs.',
    },
    {
        icon: Mic2,
        title: 'Karaoke Stage',
        body: 'A full karaoke experience — search, queue, sing, and score. Real-time pitch detection turns every session into a performance.',
    },
    {
        icon: Clapperboard,
        title: 'Pro Reels',
        body: 'Binge short-form dramas in a portrait, fullscreen-first player designed for the way you actually watch on your phone.',
    },
    {
        icon: Download,
        title: 'Downloader',
        body: 'Find titles, pick a quality, and queue authorized downloads — with in-app playback when a source is streaming-only.',
    },
    {
        icon: ShieldCheck,
        title: 'Rights-First Catalogue',
        body: 'Every title passes an internal rights confirmation before it can be published. Only content you are licensed to distribute goes live.',
    },
];

const platforms = [
    { icon: MonitorSmartphone, label: 'Web' },
    { icon: Tv, label: 'Android TV' },
    { icon: Mic2, label: 'Mobile' },
    { icon: Globe, label: 'Desktop' },
];

const stats = [
    { value: '5', label: 'Ways to watch' },
    { value: '4K', label: 'Adaptive playback' },
    { value: '24/7', label: 'Live & on-demand' },
    { value: '1', label: 'All-in-one app' },
];

const socials = [
    { icon: Mail, label: 'support@moviepinas.com', href: 'mailto:support@moviepinas.com' },
    { icon: Mail, label: 'admin@maruyatvph.com', href: 'mailto:admin@maruyatvph.com' },
    { icon: Phone, label: '0994 372 9761', href: 'tel:+639943729761' },
    { icon: MapPin, label: 'View on map', href: 'https://maps.app.goo.gl/ZabCmwmhjtNADsHGA' },
    { icon: Facebook, label: 'Facebook', href: 'https://www.facebook.com/share/1CWdrxizEq/' },
    { icon: Youtube, label: 'YouTube', href: 'https://youtube.com/channel/UCBrYLVpcrD2tllQtETy52tA?si=F69vh1VjPbVtihLI' },
    { icon: Music2, label: 'Spotify', href: 'https://open.spotify.com/artist/6jw2xFq5VMVhfnh3iqqEsu?si=zDFudFmyT1iT33Oh1IJ8dw&utm_source=copy-link' },
    { icon: Send, label: 'Telegram assistant', href: 'https://t.me/maruyatvph_bot' },
];

const AboutPage = () => (
    <Layout>
        <Helmet>
            <title>About ApX Player | All-in-One Streaming & Karaoke by MaruyaTVPH</title>
            <meta
                name="description"
                content="ApX Player by MaruyaTVPH is an all-in-one streaming and karaoke app for web, mobile, desktop, and Android TV — movies, series, Live TV, karaoke, Pro Reels, and a built-in downloader."
            />
        </Helmet>

        {/* Hero */}
        <section className="relative overflow-hidden">
            <div className="pointer-events-none absolute inset-0 -z-10">
                <div className="absolute -top-32 left-1/2 h-[36rem] w-[36rem] -translate-x-1/2 rounded-full bg-primary/15 blur-[120px]" />
                <div className="absolute right-0 top-40 h-72 w-72 rounded-full bg-accent/10 blur-[100px]" />
            </div>
            <div className="mx-auto max-w-[72rem] px-4 pb-12 pt-20 sm:px-6 sm:pt-28">
                <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">
                    <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                    About ApX Player
                </div>
                <h1 className="display mt-4 max-w-3xl text-5xl leading-[0.95] sm:text-7xl">
                    One app for everything you watch — and everything you sing.
                </h1>
                <p className="mt-6 max-w-2xl text-lg leading-relaxed text-foreground/80">
                    ApX Player is an all-in-one streaming and karaoke platform by{' '}
                    <span className="font-semibold text-grad">MaruyaTVPH</span>. It brings movies and series,
                    Live TV, a full karaoke stage, short-form Pro Reels, and a built-in downloader into a single,
                    cinematic experience — built for web, mobile, desktop, and Android TV with remote-friendly
                    navigation.
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-3">
                    <Link
                        to="/browse"
                        className="focus-glow inline-flex min-h-12 items-center gap-2 rounded-full grad-ax px-6 text-sm font-semibold text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.35)] transition-transform hover:scale-[1.03] active:scale-[0.98]"
                    >
                        <Film className="h-4 w-4" aria-hidden="true" /> Start watching
                    </Link>
                    <Link
                        to="/contact"
                        className="focus-glow inline-flex min-h-12 items-center gap-2 rounded-full border border-white/10 bg-white/5 px-6 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary"
                    >
                        Get in touch
                    </Link>
                </div>

                {/* Stat band */}
                <div className="mt-14 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/5 bg-white/5 sm:grid-cols-4">
                    {stats.map((s) => (
                        <div key={s.label} className="bg-background/60 px-5 py-6 text-center">
                            <div className="display text-4xl text-grad sm:text-5xl">{s.value}</div>
                            <div className="mt-1 text-xs uppercase tracking-[0.18em] text-muted-foreground">
                                {s.label}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>

        {/* What we do / features */}
        <section className="mx-auto max-w-[90rem] px-4 py-16 sm:px-6">
            <div className="max-w-2xl">
                <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">What we do</p>
                <h2 className="display mt-3 text-4xl sm:text-5xl">A complete entertainment hub, not just a player</h2>
                <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                    ApX Player unifies the way you discover and enjoy media. Browse a curated catalogue, tune into
                    live channels, sing along with real-time scoring, or lose yourself in short-form dramas — all
                    without leaving the app.
                </p>
            </div>

            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {features.map((f) => (
                    <div
                        key={f.title}
                        className="group relative overflow-hidden rounded-2xl border border-white/5 bg-card/60 p-6 transition-colors hover:border-primary/40"
                    >
                        <div className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-primary/10 opacity-0 blur-2xl transition-opacity group-hover:opacity-100" />
                        <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary ring-1 ring-primary/20">
                            <f.icon className="h-5 w-5" aria-hidden="true" />
                        </span>
                        <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
                        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
                    </div>
                ))}
            </div>
        </section>

        {/* Platforms */}
        <section className="mx-auto max-w-[90rem] px-4 py-12 sm:px-6">
            <div className="flex flex-col items-start justify-between gap-8 rounded-3xl border border-white/5 bg-gradient-to-br from-white/[0.04] to-transparent p-8 sm:p-12 lg:flex-row lg:items-center">
                <div className="max-w-xl">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">
                        Built for every screen
                    </p>
                    <h2 className="display mt-3 text-4xl sm:text-5xl">Watch anywhere, sing anywhere</h2>
                    <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                        From a phone on the commute to an Android TV in the living room, ApX Player adapts its
                        layout, controls, and focus states to the device in front of you — including D-pad and
                        remote-friendly navigation on the big screen.
                    </p>
                </div>
                <div className="grid w-full grid-cols-2 gap-3 sm:grid-cols-4 lg:w-auto">
                    {platforms.map((p) => (
                        <div
                            key={p.label}
                            className="flex flex-col items-center gap-2 rounded-2xl border border-white/5 bg-background/60 px-6 py-5 text-center"
                        >
                            <p.icon className="h-6 w-6 text-primary" aria-hidden="true" />
                            <span className="text-sm font-medium">{p.label}</span>
                        </div>
                    ))}
                </div>
            </div>
        </section>

        {/* How the catalogue is managed */}
        <section className="mx-auto max-w-[72rem] px-4 py-16 sm:px-6">
            <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">
                How the catalogue is managed
            </p>
            <h2 className="display mt-3 text-4xl sm:text-5xl">Rights-first, by design</h2>
            <div className="mt-8 space-y-6">
                <div className="rounded-2xl border border-white/5 bg-card/60 p-6">
                    <h3 className="text-lg font-semibold">Internal rights confirmation</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                        Administrators record the rights holder, licence reference, and an explicit
                        distribution-rights confirmation for every title and media source. Titles without that
                        confirmation cannot be published to viewers.
                    </p>
                </div>
                <div className="rounded-2xl border border-white/5 bg-card/60 p-6">
                    <h3 className="text-lg font-semibold">Curated, not cluttered</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                        We host and stream a hand-curated library rather than an endless firehose. Every entry is
                        chosen, checked, and prepared before it reaches your screen — so what you see is always
                        ready to watch.
                    </p>
                </div>
            </div>
        </section>

        {/* Connect */}
        <section className="mx-auto max-w-[90rem] px-4 pb-20 sm:px-6">
            <div className="rounded-3xl border border-white/5 bg-gradient-to-br from-primary/[0.06] to-transparent p-8 sm:p-12">
                <div className="max-w-2xl">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">
                        Connect with MaruyaTVPH
                    </p>
                    <h2 className="display mt-3 text-4xl sm:text-5xl">We're just a message away</h2>
                    <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                        Questions, partnerships, or support — reach the MaruyaTVPH team through any of the channels
                        below, or visit the full contact page.
                    </p>
                    <Link
                        to="/contact"
                        className="focus-glow mt-6 inline-flex min-h-12 items-center gap-2 rounded-full border border-white/10 bg-white/5 px-6 text-sm font-semibold text-foreground transition-colors hover:border-primary/50 hover:text-primary"
                    >
                        Go to contact page
                    </Link>
                </div>
                <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    {socials.map((s) => (
                        <a
                            key={s.label}
                            href={s.href}
                            target={s.href.startsWith('http') ? '_blank' : undefined}
                            rel="noopener noreferrer"
                            className="focus-glow group flex items-center gap-3 rounded-xl border border-white/5 bg-background/60 px-4 py-3 transition-colors hover:border-primary/40"
                        >
                            <s.icon className="h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                            <span className="truncate text-sm text-muted-foreground transition-colors group-hover:text-foreground">
                                {s.label}
                            </span>
                        </a>
                    ))}
                </div>
            </div>
        </section>
    </Layout>
);

export default AboutPage;
