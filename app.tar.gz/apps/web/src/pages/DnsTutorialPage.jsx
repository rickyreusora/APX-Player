import React from 'react';
import { Helmet } from 'react-helmet';
import { Shield, Settings, Search, Check, ArrowRight } from 'lucide-react';
import Layout from '@/components/Layout';

const steps = [
    {
        icon: Settings,
        title: 'Open Phone Settings',
        body: 'Open the Settings app on your Android phone. You can usually find it in your app drawer or by swiping down from the top of the screen and tapping the gear icon.',
    },
    {
        icon: Search,
        title: 'Search for "Private DNS"',
        body: 'At the top of Settings, tap the search bar and type “Private DNS”. Tap the result labelled “Private DNS” to open the DNS configuration screen.',
    },
    {
        icon: Shield,
        title: 'Select Custom / Private DNS provider hostname',
        body: 'On the Private DNS screen, choose the “Custom private DNS provider hostname” option (sometimes labelled “Private DNS provider hostname”).',
    },
    {
        icon: Check,
        title: 'Enter dns.adguard-dns.com and Save',
        body: 'Type exactly: dns.adguard-dns.com — then tap Save. Your phone will now route all DNS queries through AdGuard, blocking ads and trackers at the network level.',
    },
];

const DnsTutorialPage = () => (
    <Layout>
        <Helmet>
            <title>DNS Tutorial | Block Ads on Android | ApX Player</title>
            <meta
                name="description"
                content="Step-by-step guide to set up Private DNS (dns.adguard-dns.com) on your Android phone to block ads and trackers while using ApX Player."
            />
        </Helmet>

        <section className="relative overflow-hidden">
            <div className="pointer-events-none absolute inset-0 grad-ax opacity-[0.08]" aria-hidden="true" />
            <div className="relative mx-auto max-w-[56rem] px-4 pb-10 pt-16 sm:px-6">
                <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">Tutorial</p>
                <h1 className="display text-5xl sm:text-6xl">
                    <span className="text-grad">DNS</span> Tutorial
                </h1>
                <p className="mt-5 max-w-2xl text-base leading-relaxed text-foreground/80">
                    Block ads and trackers at the network level on your Android phone by switching to a private DNS
                    provider. Follow these four quick steps — no apps required.
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-3">
                    <a
                        href="#steps"
                        className="focus-glow inline-flex items-center gap-2 rounded-full grad-ax px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.35)] transition-transform hover:scale-[1.03] active:scale-[0.98]"
                    >
                        View steps <ArrowRight className="h-4 w-4" aria-hidden="true" />
                    </a>
                    <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-muted-foreground">
                        <Shield className="h-4 w-4 text-primary" aria-hidden="true" /> Android only
                    </span>
                </div>
            </div>
        </section>

        <section id="steps" className="mx-auto max-w-[56rem] px-4 py-12 sm:px-6">
            <ol className="space-y-5">
                {steps.map((step, i) => {
                    const Icon = step.icon;
                    return (
                        <li
                            key={step.title}
                            className="glass relative overflow-hidden rounded-2xl p-5 sm:p-6"
                        >
                            <div className="flex items-start gap-4">
                                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl grad-ax text-primary-foreground shadow-[0_0_18px_hsl(187_95%_55%/0.35)]">
                                    <Icon className="h-6 w-6" strokeWidth={2.2} aria-hidden="true" />
                                </span>
                                <div className="min-w-0 flex-1">
                                    <div className="flex items-center gap-3">
                                        <span className="display text-2xl text-grad">{i + 1}</span>
                                        <h2 className="text-lg font-semibold">{step.title}</h2>
                                    </div>
                                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
                                </div>
                            </div>
                        </li>
                    );
                })}
            </ol>

            <div className="mt-10 rounded-2xl border border-primary/30 bg-primary/5 p-5 sm:p-6">
                <h2 className="flex items-center gap-2 text-base font-semibold">
                    <Check className="h-5 w-5 text-primary" aria-hidden="true" /> You're all set
                </h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    Once saved, your phone uses <code className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-primary">dns.adguard-dns.com</code> for all
                    networks — Wi-Fi and mobile data. Ads and known trackers are blocked automatically while you stream on ApX Player.
                </p>
            </div>

            <div className="mt-8 rounded-2xl border border-dashed border-border p-5 text-sm leading-relaxed text-muted-foreground">
                <h2 className="mb-2 text-base font-semibold text-foreground">Notes</h2>
                <ul className="list-inside list-disc space-y-1.5">
                    <li>Menu names vary slightly between Android brands (Samsung, Xiaomi, Pixel, etc.) — look for “Private DNS”.</li>
                    <li>If a network stops working, switch Private DNS back to “Automatic” or “Off” to troubleshoot.</li>
                    <li>This setting applies system-wide and works alongside the ApX Player app.</li>
                </ul>
            </div>
        </section>
    </Layout>
);

export default DnsTutorialPage;
