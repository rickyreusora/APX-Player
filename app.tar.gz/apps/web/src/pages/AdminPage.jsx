import React, { useCallback, useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Check, Clock, Crown, Film, Image as ImageIcon, LayoutDashboard, Megaphone, Tags, Trash2, Users, X } from 'lucide-react';
import { toast } from 'sonner';
import Layout from '@/components/Layout';
import { ErrorState, LoadingState } from '@/components/StateBlocks';
import { useAuth } from '@/contexts/AuthContext';
import pb from '@/lib/pocketbaseClient';
import {
    TOPUP_AMOUNT,
    approveTopUp,
    listPendingTopUps,
    rejectTopUp,
} from '@/lib/credits';
import {
    PREMIUM_MIN_DONATION,
    approveDonation,
    listDonationHistory,
    listPendingDonations,
    proofImageUrl,
    rejectDonation,
} from '@/lib/premium';
import {
    createBroadcast,
    deleteBroadcast,
    listBroadcasts,
    toggleBroadcast,
    updateBroadcast,
} from '@/lib/broadcast';
import H2apkBuilder from '@/components/H2apkBuilder';

const AdminPage = () => {
    const { user } = useAuth();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [userCount, setUserCount] = useState(0);
    const [playlistCount, setPlaylistCount] = useState(0);
    const [favoriteCount, setFavoriteCount] = useState(0);
    const [progressCount, setProgressCount] = useState(0);

    const [pending, setPending] = useState([]);
    const [pendingLoading, setPendingLoading] = useState(false);
    const [actioningId, setActioningId] = useState(null);
    const [rejectTarget, setRejectTarget] = useState(null);
    const [rejectReason, setRejectReason] = useState('');

    // Premium donations
    const [premiumPending, setPremiumPending] = useState([]);
    const [premiumHistory, setPremiumHistory] = useState([]);
    const [premiumLoading, setPremiumLoading] = useState(false);
    const [premiumActioningId, setPremiumActioningId] = useState(null);
    const [premiumRejectTarget, setPremiumRejectTarget] = useState(null);
    const [premiumRejectReason, setPremiumRejectReason] = useState('');
    const [proofView, setProofView] = useState(null);

    // Broadcast messages
    const [broadcasts, setBroadcasts] = useState([]);
    const [broadcastLoading, setBroadcastLoading] = useState(false);
    const [broadcastSaving, setBroadcastSaving] = useState(false);
    const [broadcastForm, setBroadcastForm] = useState({ title: '', message: '', active: true });
    const [editingId, setEditingId] = useState(null);
    const [broadcastActioningId, setBroadcastActioningId] = useState(null);
    const [deleteTarget, setDeleteTarget] = useState(null);

    const loadMetrics = useCallback(async () => {
        setLoading(true);
        setError('');
        try {
            const [u, p, f, pr] = await Promise.all([
                pb.collection('users').getList(1, 1, { requestKey: 'admin-users' }),
                pb.collection('playlists').getList(1, 1, { requestKey: 'admin-playlists' }),
                pb.collection('favorites').getList(1, 1, { requestKey: 'admin-favorites' }),
                pb.collection('progress').getList(1, 1, { requestKey: 'admin-progress' }),
            ]);
            setUserCount(u.totalItems);
            setPlaylistCount(p.totalItems);
            setFavoriteCount(f.totalItems);
            setProgressCount(pr.totalItems);
        } catch (err) {
            setError(err?.message || 'Could not load admin data.');
        } finally {
            setLoading(false);
        }
    }, []);

    const loadPending = useCallback(async () => {
        setPendingLoading(true);
        try {
            const list = await listPendingTopUps();
            setPending(list);
        } catch (err) {
            // Non-fatal — pending list failure shouldn't blank the page.
            console.error('load pending top-ups failed', err);
            setPending([]);
        } finally {
            setPendingLoading(false);
        }
    }, []);

    const loadPremium = useCallback(async () => {
        setPremiumLoading(true);
        try {
            const [pend, hist] = await Promise.all([
                listPendingDonations(),
                listDonationHistory().catch(() => []),
            ]);
            setPremiumPending(pend);
            setPremiumHistory(hist);
        } catch (err) {
            console.error('load premium donations failed', err);
            setPremiumPending([]);
            setPremiumHistory([]);
        } finally {
            setPremiumLoading(false);
        }
    }, []);

    const loadBroadcasts = useCallback(async () => {
        setBroadcastLoading(true);
        try {
            const list = await listBroadcasts();
            setBroadcasts(list);
        } catch (err) {
            console.error('load broadcasts failed', err);
            setBroadcasts([]);
        } finally {
            setBroadcastLoading(false);
        }
    }, []);

    useEffect(() => {
        loadMetrics();
        loadPending();
        loadPremium();
        loadBroadcasts();
    }, [loadMetrics, loadPending, loadPremium, loadBroadcasts]);

    const handleApprove = async (tx) => {
        setActioningId(tx.id);
        try {
            await approveTopUp(tx.id, user);
            toast.success(`Approved ₱${TOPUP_AMOUNT} for ${tx.expand?.owner?.name || tx.expand?.owner?.email || 'user'}`);
            await loadPending();
        } catch (err) {
            toast.error(err?.message || 'Could not approve the top-up.');
        } finally {
            setActioningId(null);
        }
    };

    const confirmReject = async () => {
        if (!rejectTarget) return;
        setActioningId(rejectTarget.id);
        try {
            await rejectTopUp(rejectTarget.id, user, rejectReason.trim());
            toast.success('Top-up rejected');
            setRejectTarget(null);
            setRejectReason('');
            await loadPending();
        } catch (err) {
            toast.error(err?.message || 'Could not reject the top-up.');
        } finally {
            setActioningId(null);
        }
    };

    const handleApproveDonation = async (don) => {
        setPremiumActioningId(don.id);
        try {
            await approveDonation(don.id, user);
            toast.success(`Premium granted for ${don.expand?.owner?.name || don.expand?.owner?.email || 'user'}`);
            await loadPremium();
        } catch (err) {
            toast.error(err?.message || 'Could not approve the donation.');
        } finally {
            setPremiumActioningId(null);
        }
    };

    const confirmRejectDonation = async () => {
        if (!premiumRejectTarget) return;
        setPremiumActioningId(premiumRejectTarget.id);
        try {
            await rejectDonation(premiumRejectTarget.id, user, premiumRejectReason.trim());
            toast.success('Donation rejected');
            setPremiumRejectTarget(null);
            setPremiumRejectReason('');
            await loadPremium();
        } catch (err) {
            toast.error(err?.message || 'Could not reject the donation.');
        } finally {
            setPremiumActioningId(null);
        }
    };

    const resetBroadcastForm = () => {
        setBroadcastForm({ title: '', message: '', active: true });
        setEditingId(null);
    };

    const startEditBroadcast = (b) => {
        setEditingId(b.id);
        setBroadcastForm({ title: b.title || '', message: b.message || '', active: !!b.active });
        if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const submitBroadcast = async (e) => {
        e.preventDefault();
        if (!broadcastForm.message || !broadcastForm.message.trim()) {
            toast.error('Broadcast message is required.');
            return;
        }
        setBroadcastSaving(true);
        try {
            if (editingId) {
                await updateBroadcast(user, editingId, broadcastForm);
                toast.success('Broadcast updated.');
            } else {
                await createBroadcast(user, broadcastForm);
                toast.success('Broadcast created.');
            }
            resetBroadcastForm();
            await loadBroadcasts();
        } catch (err) {
            toast.error(err?.message || 'Could not save the broadcast.');
        } finally {
            setBroadcastSaving(false);
        }
    };

    const handleToggleBroadcast = async (b) => {
        setBroadcastActioningId(b.id);
        try {
            await toggleBroadcast(user, b);
            toast.success(b.active ? 'Broadcast hidden.' : 'Broadcast published.');
            await loadBroadcasts();
        } catch (err) {
            toast.error(err?.message || 'Could not toggle the broadcast.');
        } finally {
            setBroadcastActioningId(null);
        }
    };

    const confirmDeleteBroadcast = async () => {
        if (!deleteTarget) return;
        setBroadcastActioningId(deleteTarget.id);
        try {
            await deleteBroadcast(user, deleteTarget.id);
            toast.success('Broadcast deleted.');
            setDeleteTarget(null);
            if (editingId === deleteTarget.id) resetBroadcastForm();
            await loadBroadcasts();
        } catch (err) {
            toast.error(err?.message || 'Could not delete the broadcast.');
        } finally {
            setBroadcastActioningId(null);
        }
    };

    const metrics = [
        { label: 'Registered users', value: userCount, icon: Users },
        { label: 'User playlists', value: playlistCount, icon: Tags },
        { label: 'Favourites saved', value: favoriteCount, icon: Film },
        { label: 'Watch entries', value: progressCount, icon: LayoutDashboard },
    ];

    return (
        <Layout>
            <Helmet>
                <title>Admin Console | ApX Player</title>
                <meta name="description" content="Administrator console for ApX Player account, usage metrics and top-up approvals." />
            </Helmet>

            <div className="mx-auto max-w-[90rem] px-4 py-12 sm:px-6">
                <header className="mb-8">
                    <div className="mb-2 h-1.5 w-16 rounded-full grad-ax" aria-hidden="true" />
                    <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary">Admin console</p>
                    <h1 className="font-display text-5xl font-extrabold">Overview</h1>
                    <p className="mt-2 text-sm text-muted-foreground">Signed in as {user?.email}</p>
                </header>

                {/* Pending Top-Ups approval queue */}
                <section className="mb-12 glass rounded-2xl p-6">
                    <div className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-2">
                            <Clock className="h-5 w-5 text-amber-500" />
                            <h2 className="font-display text-2xl font-bold">Pending Top-Ups</h2>
                            {pending.length > 0 && (
                                <span className="rounded-full bg-amber-500/15 px-2.5 py-0.5 text-xs font-semibold text-amber-500">
                                    {pending.length} awaiting approval
                                </span>
                            )}
                        </div>
                        <button
                            type="button"
                            onClick={loadPending}
                            className="focus-glow rounded-full border border-border px-3 py-2 text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary"
                        >
                            Refresh
                        </button>
                    </div>

                    {pendingLoading ? (
                        <p className="mt-4 text-sm text-muted-foreground">Loading pending payments…</p>
                    ) : pending.length === 0 ? (
                        <p className="mt-4 text-sm text-muted-foreground">No payments are waiting for approval.</p>
                    ) : (
                        <ul className="mt-5 divide-y divide-border overflow-hidden rounded-sm border border-border">
                            {pending.map((tx) => {
                                const owner = tx.expand?.owner;
                                const ownerName = owner?.name || owner?.email || 'Unknown user';
                                const isOwn = tx.owner === user?.id;
                                return (
                                    <li key={tx.id} className="flex flex-col gap-4 bg-card/40 p-4 sm:flex-row sm:items-center">
                                        <div className="flex-1">
                                            <div className="flex flex-wrap items-center gap-2">
                                                <p className="text-sm font-semibold">{ownerName}</p>
                                                <span className="rounded-sm bg-secondary px-2 py-0.5 text-[11px] text-muted-foreground">
                                                    {owner?.email}
                                                </span>
                                                {isOwn && (
                                                    <span className="rounded-sm bg-amber-500/15 px-2 py-0.5 text-[11px] font-medium text-amber-500">
                                                        Your own payment — cannot approve
                                                    </span>
                                                )}
                                            </div>
                                            <p className="mt-1 text-xs text-muted-foreground">
                                                {new Date(tx.created).toLocaleString()}
                                                {tx.reference ? ` · Ref ${tx.reference}` : ' · No reference'}
                                            </p>
                                            <p className="mt-1 text-[11px] text-muted-foreground">
                                                Status: <span className="font-medium text-amber-500">Pending approval</span>
                                            </p>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-lg font-bold text-primary">₱{Number(tx.amount)}</p>
                                        </div>
                                        <div className="flex shrink-0 gap-2">
                                            <button
                                                type="button"
                                                onClick={() => handleApprove(tx)}
                                                disabled={actioningId === tx.id || isOwn}
                                                className="inline-flex min-h-[44px] items-center gap-1.5 rounded-sm bg-primary px-4 text-sm font-semibold text-primary-foreground active:scale-[0.98] disabled:opacity-50"
                                                title={isOwn ? 'You cannot approve your own payment' : 'Approve and credit the user'}
                                            >
                                                <Check className="h-4 w-4" /> Approve
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setRejectTarget(tx);
                                                    setRejectReason('');
                                                }}
                                                disabled={actioningId === tx.id || isOwn}
                                                className="inline-flex min-h-[44px] items-center gap-1.5 rounded-sm border border-destructive px-4 text-sm font-semibold text-destructive hover:bg-destructive hover:text-destructive-foreground active:scale-[0.98] disabled:opacity-50"
                                            >
                                                <X className="h-4 w-4" /> Reject
                                            </button>
                                        </div>
                                    </li>
                                );
                            })}
                        </ul>
                    )}
                </section>

                {/* Premium Donations approval queue */}
                <section className="mb-12 glass rounded-2xl p-6">
                    <div className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-2">
                            <Crown className="h-5 w-5 text-primary" />
                            <h2 className="font-display text-2xl font-bold">Premium Donations</h2>
                            {premiumPending.length > 0 && (
                                <span className="rounded-full bg-primary/15 px-2.5 py-0.5 text-xs font-semibold text-primary">
                                    {premiumPending.length} awaiting approval
                                </span>
                            )}
                        </div>
                        <button
                            type="button"
                            onClick={loadPremium}
                            className="focus-glow rounded-full border border-border px-3 py-2 text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary"
                        >
                            Refresh
                        </button>
                    </div>

                    {premiumLoading ? (
                        <p className="mt-4 text-sm text-muted-foreground">Loading premium donations…</p>
                    ) : premiumPending.length === 0 ? (
                        <p className="mt-4 text-sm text-muted-foreground">No premium donations are waiting for approval.</p>
                    ) : (
                        <ul className="mt-5 divide-y divide-border overflow-hidden rounded-sm border border-border">
                            {premiumPending.map((don) => {
                                const owner = don.expand?.owner;
                                const ownerName = owner?.name || owner?.email || 'Unknown user';
                                const isOwn = don.owner === user?.id;
                                const belowMin = Number(don.amount) < PREMIUM_MIN_DONATION;
                                return (
                                    <li key={don.id} className="flex flex-col gap-4 bg-card/40 p-4 sm:flex-row sm:items-center">
                                        <div className="flex-1">
                                            <div className="flex flex-wrap items-center gap-2">
                                                <p className="text-sm font-semibold">{ownerName}</p>
                                                <span className="rounded-sm bg-secondary px-2 py-0.5 text-[11px] text-muted-foreground">
                                                    {owner?.email}
                                                </span>
                                                {isOwn && (
                                                    <span className="rounded-sm bg-amber-500/15 px-2 py-0.5 text-[11px] font-medium text-amber-500">
                                                        Your own donation — cannot approve
                                                    </span>
                                                )}
                                                {belowMin && (
                                                    <span className="rounded-sm bg-destructive/15 px-2 py-0.5 text-[11px] font-medium text-destructive">
                                                        Below ₱{PREMIUM_MIN_DONATION} minimum
                                                    </span>
                                                )}
                                            </div>
                                            <p className="mt-1 text-xs text-muted-foreground">
                                                {new Date(don.created).toLocaleString()}
                                            </p>
                                            <p className="mt-1 text-xs text-muted-foreground">
                                                Sender: <span className="text-foreground">{don.sender_name}</span>
                                                {' · '}Ref: <span className="font-mono text-foreground">{don.gcash_reference}</span>
                                            </p>
                                            {don.proof_image && (
                                                <button
                                                    type="button"
                                                    onClick={() => setProofView(proofImageUrl(don, don.proof_image))}
                                                    className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-primary hover:underline"
                                                >
                                                    <ImageIcon className="h-3.5 w-3.5" /> View proof of payment
                                                </button>
                                            )}
                                        </div>
                                        <div className="text-right">
                                            <p className="text-lg font-bold text-primary">₱{Number(don.amount)}</p>
                                        </div>
                                        <div className="flex shrink-0 gap-2">
                                            <button
                                                type="button"
                                                onClick={() => handleApproveDonation(don)}
                                                disabled={premiumActioningId === don.id || isOwn || belowMin}
                                                className="inline-flex min-h-[44px] items-center gap-1.5 rounded-sm bg-primary px-4 text-sm font-semibold text-primary-foreground active:scale-[0.98] disabled:opacity-50"
                                                title={belowMin ? 'Amount below ₱50 minimum' : isOwn ? 'You cannot approve your own donation' : 'Approve and grant premium access'}
                                            >
                                                <Check className="h-4 w-4" /> Approve
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setPremiumRejectTarget(don);
                                                    setPremiumRejectReason('');
                                                }}
                                                disabled={premiumActioningId === don.id || isOwn}
                                                className="inline-flex min-h-[44px] items-center gap-1.5 rounded-sm border border-destructive px-4 text-sm font-semibold text-destructive hover:bg-destructive hover:text-destructive-foreground active:scale-[0.98] disabled:opacity-50"
                                            >
                                                <X className="h-4 w-4" /> Reject
                                            </button>
                                        </div>
                                    </li>
                                );
                            })}
                        </ul>
                    )}

                    {/* Approved / rejected history */}
                    {premiumHistory.length > 0 && (
                        <div className="mt-8">
                            <h3 className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                                Approval history
                            </h3>
                            <ul className="divide-y divide-border overflow-hidden rounded-sm border border-border">
                                {premiumHistory.map((don) => {
                                    const owner = don.expand?.owner;
                                    const tone = don.status === 'approved' ? 'text-primary' : 'text-destructive';
                                    return (
                                        <li key={don.id} className="flex items-center gap-4 bg-card/30 p-4">
                                            <div className="flex-1">
                                                <p className="text-sm font-semibold">
                                                    {owner?.name || owner?.email || 'Unknown user'}
                                                    {' · '}₱{Number(don.amount)}
                                                </p>
                                                <p className="text-xs text-muted-foreground">
                                                    {new Date(don.created).toLocaleString()}
                                                    {don.approval_date ? ` · ${don.status} ${new Date(don.approval_date).toLocaleDateString()}` : ''}
                                                </p>
                                                {don.status === 'rejected' && don.rejection_reason && (
                                                    <p className="text-[11px] text-destructive">Reason: {don.rejection_reason}</p>
                                                )}
                                            </div>
                                            <span className={`text-[11px] font-semibold uppercase ${tone}`}>{don.status}</span>
                                        </li>
                                    );
                                })}
                            </ul>
                        </div>
                    )}
                </section>

                {/* Broadcast messages management */}
                <section className="mb-12 glass rounded-2xl p-6">
                    <div className="flex items-center gap-2">
                        <Megaphone className="h-5 w-5 text-primary" />
                        <h2 className="font-display text-2xl font-bold">Broadcast Message</h2>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                        Publish a pop-up announcement shown to every visitor across the site. Visitors dismiss it with the
                        OK button; it reappears for them only after you publish or edit it again.
                    </p>

                    {/* Create / edit form */}
                    <form onSubmit={submitBroadcast} className="mt-5 space-y-4 rounded-xl border border-border bg-card/40 p-5">
                        <div className="flex flex-col gap-2">
                            <label htmlFor="bc-title" className="text-xs font-medium text-muted-foreground">
                                Title <span className="text-muted-foreground/60">(optional)</span>
                            </label>
                            <input
                                id="bc-title"
                                type="text"
                                value={broadcastForm.title}
                                onChange={(e) => setBroadcastForm((f) => ({ ...f, title: e.target.value }))}
                                maxLength={120}
                                placeholder="e.g. Scheduled maintenance"
                                className="focus-glow rounded-sm border border-border bg-secondary/50 px-3 py-2.5 text-sm"
                            />
                        </div>
                        <div className="flex flex-col gap-2">
                            <label htmlFor="bc-message" className="text-xs font-medium text-muted-foreground">
                                Message <span className="text-destructive">*</span>
                            </label>
                            <textarea
                                id="bc-message"
                                rows={3}
                                value={broadcastForm.message}
                                onChange={(e) => setBroadcastForm((f) => ({ ...f, message: e.target.value }))}
                                maxLength={1000}
                                required
                                placeholder="Write the announcement visitors will see…"
                                className="focus-glow rounded-sm border border-border bg-secondary/50 p-3 text-sm"
                            />
                        </div>
                        <label className="flex items-center gap-2.5 text-sm">
                            <input
                                type="checkbox"
                                checked={broadcastForm.active}
                                onChange={(e) => setBroadcastForm((f) => ({ ...f, active: e.target.checked }))}
                                className="h-4 w-4 rounded border-border"
                            />
                            <span>Active — show this broadcast to visitors now</span>
                        </label>
                        <div className="flex flex-wrap gap-3">
                            <button
                                type="submit"
                                disabled={broadcastSaving}
                                className="inline-flex min-h-[44px] items-center gap-1.5 rounded-sm bg-primary px-5 text-sm font-semibold text-primary-foreground active:scale-[0.98] disabled:opacity-50"
                            >
                                {broadcastSaving ? 'Saving…' : editingId ? 'Update broadcast' : 'Create broadcast'}
                            </button>
                            {editingId && (
                                <button
                                    type="button"
                                    onClick={resetBroadcastForm}
                                    className="min-h-[44px] rounded-sm border border-border px-5 text-sm font-semibold"
                                >
                                    Cancel edit
                                </button>
                            )}
                        </div>
                    </form>

                    {/* Existing broadcasts */}
                    {broadcastLoading ? (
                        <p className="mt-4 text-sm text-muted-foreground">Loading broadcasts…</p>
                    ) : broadcasts.length === 0 ? (
                        <p className="mt-4 text-sm text-muted-foreground">No broadcasts yet.</p>
                    ) : (
                        <ul className="mt-5 divide-y divide-border overflow-hidden rounded-sm border border-border">
                            {broadcasts.map((b) => (
                                <li key={b.id} className="flex flex-col gap-3 bg-card/40 p-4 sm:flex-row sm:items-center">
                                    <div className="flex-1">
                                        <div className="flex flex-wrap items-center gap-2">
                                            <p className="text-sm font-semibold">{b.title || 'Untitled broadcast'}</p>
                                            <span
                                                className={`rounded-sm px-2 py-0.5 text-[11px] font-medium ${
                                                    b.active
                                                        ? 'bg-primary/15 text-primary'
                                                        : 'bg-secondary text-muted-foreground'
                                                }`}
                                            >
                                                {b.active ? 'Active' : 'Inactive'}
                                            </span>
                                        </div>
                                        <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{b.message}</p>
                                        <p className="mt-1 text-[11px] text-muted-foreground">
                                            Updated {new Date(b.updated || b.created).toLocaleString()}
                                        </p>
                                    </div>
                                    <div className="flex shrink-0 gap-2">
                                        <button
                                            type="button"
                                            onClick={() => handleToggleBroadcast(b)}
                                            disabled={broadcastActioningId === b.id}
                                            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-sm border border-border px-3 text-xs font-semibold hover:border-primary hover:text-primary disabled:opacity-50"
                                        >
                                            {b.active ? 'Hide' : 'Publish'}
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => startEditBroadcast(b)}
                                            disabled={broadcastActioningId === b.id}
                                            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-sm border border-border px-3 text-xs font-semibold hover:border-primary hover:text-primary disabled:opacity-50"
                                        >
                                            Edit
                                        </button>
                                        <button
                                            type="button"
                                            onClick={() => setDeleteTarget(b)}
                                            disabled={broadcastActioningId === b.id}
                                            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-sm border border-destructive px-3 text-xs font-semibold text-destructive hover:bg-destructive hover:text-destructive-foreground disabled:opacity-50"
                                        >
                                            <Trash2 className="h-3.5 w-3.5" /> Delete
                                        </button>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    )}
                </section>

                {/* HTML → APK builder (admin-only, powered by H2APK) */}
                <H2apkBuilder />

                {loading && <LoadingState />}
                {!loading && error && <ErrorState message={error} onRetry={loadMetrics} />}

                {!loading && !error && (
                    <>
                        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                            {metrics.map((m) => (
                                <div key={m.label} className="ring-grad relative overflow-hidden rounded-2xl border border-white/8 bg-card/60 p-5">
                                    <m.icon className="mb-3 h-5 w-5 text-primary" aria-hidden="true" />
                                    <p className="font-display text-4xl font-extrabold">{m.value}</p>
                                    <p className="mt-1 text-xs uppercase tracking-[0.15em] text-muted-foreground">{m.label}</p>
                                </div>
                            ))}
                        </div>

                        <div className="mt-12 ring-grad relative overflow-hidden rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-card to-card p-6">
                            <h2 className="font-display text-2xl font-bold">Catalogue powered by TMDB</h2>
                            <p className="mt-3 max-w-3xl text-sm leading-relaxed text-foreground/80">
                                The ApX Player catalogue is now sourced live from TMDB, so titles, seasons and episodes no
                                longer need to be managed manually here. Browse the catalogue from the public pages, and
                                playback opens in the embedded Videasy player. User accounts, favourites, playlists and
                                watch history remain stored in this site's database.
                            </p>
                        </div>
                    </>
                )}
            </div>

            {/* Reject confirmation dialog */}
            {rejectTarget && (
                <div
                    className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
                    role="dialog"
                    aria-modal="true"
                    aria-label="Reject top-up"
                >
                    <div className="w-full max-w-md rounded-xl border border-border bg-card p-6 shadow-2xl">
                        <h3 className="display text-2xl">Reject this top-up?</h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                            {rejectTarget.expand?.owner?.name || rejectTarget.expand?.owner?.email || 'This user'} will not be credited ₱{Number(rejectTarget.amount)} and will be notified of the rejection.
                        </p>
                        <div className="mt-4 flex flex-col gap-2">
                            <label htmlFor="reject-reason" className="text-xs text-muted-foreground">
                                Rejection reason (optional)
                            </label>
                            <textarea
                                id="reject-reason"
                                rows={3}
                                value={rejectReason}
                                onChange={(e) => setRejectReason(e.target.value)}
                                placeholder="e.g. Payment not received"
                                className="rounded-sm border border-border bg-secondary/50 p-3 text-sm"
                            />
                        </div>
                        <div className="mt-5 flex justify-end gap-3">
                            <button
                                type="button"
                                onClick={() => {
                                    setRejectTarget(null);
                                    setRejectReason('');
                                }}
                                className="min-h-[44px] rounded-sm border border-border px-5 text-sm font-semibold"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                onClick={confirmReject}
                                disabled={actioningId === rejectTarget.id}
                                className="min-h-[44px] rounded-sm bg-destructive px-5 text-sm font-semibold text-destructive-foreground disabled:opacity-60"
                            >
                                {actioningId === rejectTarget.id ? 'Rejecting…' : 'Confirm rejection'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Premium donation reject dialog */}
            {premiumRejectTarget && (
                <div
                    className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
                    role="dialog"
                    aria-modal="true"
                    aria-label="Reject premium donation"
                >
                    <div className="w-full max-w-md rounded-xl border border-border bg-card p-6 shadow-2xl">
                        <h3 className="display text-2xl">Reject this donation?</h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                            {premiumRejectTarget.expand?.owner?.name || premiumRejectTarget.expand?.owner?.email || 'This user'} will not be granted premium access for the ₱{Number(premiumRejectTarget.amount)} donation.
                        </p>
                        <div className="mt-4 flex flex-col gap-2">
                            <label htmlFor="premium-reject-reason" className="text-xs text-muted-foreground">
                                Rejection reason (optional)
                            </label>
                            <textarea
                                id="premium-reject-reason"
                                rows={3}
                                value={premiumRejectReason}
                                onChange={(e) => setPremiumRejectReason(e.target.value)}
                                placeholder="e.g. Payment not received"
                                className="rounded-sm border border-border bg-secondary/50 p-3 text-sm"
                            />
                        </div>
                        <div className="mt-5 flex justify-end gap-3">
                            <button
                                type="button"
                                onClick={() => {
                                    setPremiumRejectTarget(null);
                                    setPremiumRejectReason('');
                                }}
                                className="min-h-[44px] rounded-sm border border-border px-5 text-sm font-semibold"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                onClick={confirmRejectDonation}
                                disabled={premiumActioningId === premiumRejectTarget.id}
                                className="min-h-[44px] rounded-sm bg-destructive px-5 text-sm font-semibold text-destructive-foreground disabled:opacity-60"
                            >
                                {premiumActioningId === premiumRejectTarget.id ? 'Rejecting…' : 'Confirm rejection'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Proof-of-payment image viewer */}
            {proofView && (
                <div
                    className="fixed inset-0 z-[90] flex items-center justify-center bg-black/90 p-4 backdrop-blur-sm"
                    role="dialog"
                    aria-modal="true"
                    aria-label="Proof of payment"
                    onClick={() => setProofView(null)}
                >
                    <button
                        type="button"
                        onClick={() => setProofView(null)}
                        className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full bg-white/10 text-white hover:bg-white/20"
                        aria-label="Close"
                    >
                        <X className="h-5 w-5" />
                    </button>
                    <img
                        src={proofView}
                        alt="Proof of payment"
                        className="max-h-[90dvh] max-w-full rounded-lg object-contain"
                        onClick={(e) => e.stopPropagation()}
                    />
                </div>
            )}

            {/* Broadcast delete confirmation */}
            {deleteTarget && (
                <div
                    className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
                    role="dialog"
                    aria-modal="true"
                    aria-label="Delete broadcast"
                >
                    <div className="w-full max-w-md rounded-xl border border-border bg-card p-6 shadow-2xl">
                        <h3 className="display text-2xl">Delete this broadcast?</h3>
                        <p className="mt-2 text-sm text-muted-foreground">
                            “{deleteTarget.title || deleteTarget.message.slice(0, 60)}” will be permanently removed.
                        </p>
                        <div className="mt-5 flex justify-end gap-3">
                            <button
                                type="button"
                                onClick={() => setDeleteTarget(null)}
                                className="min-h-[44px] rounded-sm border border-border px-5 text-sm font-semibold"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                onClick={confirmDeleteBroadcast}
                                disabled={broadcastActioningId === deleteTarget.id}
                                className="min-h-[44px] rounded-sm bg-destructive px-5 text-sm font-semibold text-destructive-foreground disabled:opacity-60"
                            >
                                {broadcastActioningId === deleteTarget.id ? 'Deleting…' : 'Delete'}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </Layout>
    );
};

export default AdminPage;
