import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Info, Maximize, Minimize, Play } from 'lucide-react';
import Layout from '@/components/Layout';
import { ErrorState, LoadingState } from '@/components/StateBlocks';
import { useAuth } from '@/contexts/AuthContext';
import {
    formatDuration,
    getTitleBySlug,
    listEpisodes,
    saveProgress,
    videasyUrl,
} from '@/lib/catalog';
import { isPremiumTitle } from '@/lib/premium';
import PremiumPromptModal from '@/components/PremiumPromptModal';

const WatchPage = () => {
    const { slug } = useParams();
    const [params, setParams] = useSearchParams();
    const navigate = useNavigate();
    const { user, isAuthed, isPremium } = useAuth();

    const [title, setTitle] = useState(null);
    const [seasons, setSeasons] = useState([]);
    const [episodes, setEpisodes] = useState([]);
    const [loadingEpisodes, setLoadingEpisodes] = useState(false);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [isFullscreen, setIsFullscreen] = useState(false);
    const playerWrapRef = useRef(null);

    const season = Number(params.get('s')) || 1;
    const episode = Number(params.get('e')) || 1;

    const load = async () => {
        setLoading(true);
        setError('');
        try {
            const rec = await getTitleBySlug(slug);
            setTitle(rec);
            if (rec.kind === 'series') {
                setSeasons(rec.seasons || []);
            }
        } catch (err) {
            setError(err?.status === 404 ? 'That title is not available.' : err?.message || 'Could not load this title.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [slug]);

    // Load episode list for the active season (series only).
    useEffect(() => {
        if (title?.kind !== 'series') return;
        let cancelled = false;
        setLoadingEpisodes(true);
        listEpisodes(title.tmdb_id, season)
            .then((eps) => {
                if (!cancelled) setEpisodes(eps);
            })
            .catch(() => {
                if (!cancelled) setEpisodes([]);
            })
            .finally(() => {
                if (!cancelled) setLoadingEpisodes(false);
            });
        return () => {
            cancelled = true;
        };
    }, [title, season]);

    // Record a watch-history entry (best-effort). The Videasy iframe is a
    // third-party player we cannot introspect, so we log that the user started
    // the title/episode rather than a precise playback position.
    useEffect(() => {
        if (!isAuthed || !title || !user?.id) return;
        saveProgress(user.id, title, title.kind === 'series' ? season : 0, title.kind === 'series' ? episode : 0, 0, 0).catch(
            () => {},
        );
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isAuthed, title?.tmdb_id, season, episode]);

    const playerUrl = useMemo(() => {
        if (!title) return '';
        return videasyUrl(title, title.kind === 'series' ? season : undefined, title.kind === 'series' ? episode : undefined);
    }, [title, season, episode]);

    // Premium gate: Vivamax / Viva One content requires premium access.
    const premiumRequired = params.get('premium') === '1' || isPremiumTitle(title);
    const premiumBlocked = premiumRequired && !isPremium;

    const activeEpisode = useMemo(
        () => episodes.find((e) => e.episode_number === episode) || null,
        [episodes, episode],
    );

    const setSeasonEpisode = (s, e) => {
        const next = new URLSearchParams(params);
        next.set('s', String(s));
        next.set('e', String(e));
        setParams(next);
    };

    const lockLandscape = async () => {
        const orientation = window.screen?.orientation;
        const isFs = document.fullscreenElement || document.webkitFullscreenElement;
        if (isFs && orientation?.lock) {
            await orientation.lock('landscape').catch(() => {});
        }
    };

    const unlockOrientation = () => {
        window.screen?.orientation?.unlock?.();
    };

    const toggleFullscreen = async () => {
        const el = playerWrapRef.current;
        if (!el) return;
        const isFs = document.fullscreenElement || document.webkitFullscreenElement;
        if (isFs) {
            const exit = document.exitFullscreen || document.webkitExitFullscreen;
            if (exit) await exit.call(document).catch(() => {});
            unlockOrientation();
        } else {
            const req = el.requestFullscreen || el.webkitRequestFullscreen || el.webkitEnterFullscreen;
            if (req) {
                try {
                    const ret = req.call(el);
                    if (ret && typeof ret.catch === 'function') await ret.catch(() => {});
                } catch {
                    /* fullscreen unavailable on this browser */
                }
                await lockLandscape();
            }
        }
    };

    useEffect(() => {
        const onFsChange = () => {
            const active = document.fullscreenElement === playerWrapRef.current ||
                document.webkitFullscreenElement === playerWrapRef.current;
            setIsFullscreen(active);
            if (active) {
                lockLandscape();
            } else {
                unlockOrientation();
            }
        };
        document.addEventListener('fullscreenchange', onFsChange);
        document.addEventListener('webkitfullscreenchange', onFsChange);
        return () => {
            document.removeEventListener('fullscreenchange', onFsChange);
            document.removeEventListener('webkitfullscreenchange', onFsChange);
            unlockOrientation();
        };
    }, []);

    if (loading) {
        return (
            <Layout bare>
                <LoadingState label="Preparing player…" />
            </Layout>
        );
    }

    if (error || !title) {
        return (
            <Layout bare>
                <div className="py-24">
                    <ErrorState message={error || 'Title unavailable.'} onRetry={() => navigate(0)} />
                </div>
            </Layout>
        );
    }

    return (
        <Layout bare>
            <Helmet>
                <title>Watch | ApX Player</title>
                <meta
                    name="description"
                    content="Stream movies and TV series on ApX Player by MaruyaTVPH with a clean cinematic player."
                />
            </Helmet>

            <div className="mx-auto max-w-[95rem] px-4 py-6 sm:px-6">
                <div className="mb-4 flex items-center gap-4">
                    <Link
                        to={`/title/${title.slug}`}
                        className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
                    >
                        <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back to details
                    </Link>
                </div>

                <div
                    ref={playerWrapRef}
                    className="group relative overflow-hidden rounded-sm border border-white/10 bg-black"
                >
                    <div className="relative aspect-video w-full bg-black">
                        {premiumBlocked ? (
                            <div className="absolute inset-0 grid place-items-center bg-gradient-to-br from-primary/10 via-card to-card p-6 text-center">
                                <div className="max-w-md">
                                    <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full grad-ax shadow-[0_0_24px_hsl(187_95%_55%/0.5)]">
                                        <Play className="h-8 w-8 fill-current text-primary-foreground" />
                                    </div>
                                    <h2 className="display text-3xl">Premium access required</h2>
                                    <p className="mt-2 text-sm text-muted-foreground">
                                        This title is part of the Vivamax / Viva One premium collection. Send a one-time
                                        donation of at least ₱50 to unlock every premium title.
                                    </p>
                                </div>
                            </div>
                        ) : playerUrl ? (
                            <iframe
                                key={playerUrl}
                                src={playerUrl}
                                title={`Player for ${title.title}`}
                                className="absolute inset-0 h-full w-full"
                                allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                                allowFullScreen
                                frameBorder="0"
                            />
                        ) : (
                            <div className="grid h-full w-full place-items-center text-sm text-muted-foreground">
                                No player source available for this title.
                            </div>
                        )}
                    </div>
                    {playerUrl && !premiumBlocked && (
                        <button
                            type="button"
                            onClick={toggleFullscreen}
                            className="absolute bottom-3 right-3 z-10 grid h-10 w-10 place-items-center rounded-sm bg-black/70 text-white opacity-0 transition-opacity hover:bg-black/90 group-hover:opacity-100 focus-visible:opacity-100"
                            aria-label={isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
                        >
                            {isFullscreen ? (
                                <Minimize className="h-5 w-5" aria-hidden="true" />
                            ) : (
                                <Maximize className="h-5 w-5" aria-hidden="true" />
                            )}
                        </button>
                    )}
                </div>

                <PremiumPromptModal
                    open={premiumBlocked}
                    onClose={() => navigate(`/title/${title.slug}`)}
                    titleName={title.title}
                />

                <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_320px]">
                    <div>
                        <h1 className="display text-4xl">{title.title}</h1>
                        {title.kind === 'series' && activeEpisode && (
                            <p className="mt-1 text-sm text-primary">
                                S{season} · E{activeEpisode.episode_number} — {activeEpisode.name}
                            </p>
                        )}
                        <p className="mt-4 max-w-3xl text-sm leading-relaxed text-muted-foreground">
                            {activeEpisode?.synopsis || title.synopsis}
                        </p>
                        {!isAuthed && (
                            <p className="mt-5 rounded-sm border border-border bg-card/50 p-4 text-sm text-muted-foreground">
                                <Link to="/login" className="text-primary underline underline-offset-4">
                                    Sign in
                                </Link>{' '}
                                to keep track of what you watch across devices.
                            </p>
                        )}
                        <p className="mt-5 rounded-sm border border-primary/30 bg-primary/5 p-4 text-xs leading-relaxed text-muted-foreground">
                            Catalogue data and artwork are sourced from TMDB. Report an issue via the{' '}
                            <Link to="/content-rights" className="text-primary underline underline-offset-4">
                                Content Rights notice
                            </Link>
                            . -MaruyaTVPh
                        </p>
                    </div>

                    {title.kind === 'series' && (
                        <aside>
                            {seasons.length > 1 && (
                                <div className="mb-4">
                                    <label htmlFor="watch-season" className="mb-1.5 block text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                                        Season
                                    </label>
                                    <select
                                        id="watch-season"
                                        value={season}
                                        onChange={(e) => setSeasonEpisode(Number(e.target.value), 1)}
                                        className="h-11 w-full rounded-sm border border-border bg-secondary/60 px-3 text-sm"
                                    >
                                        {seasons.map((s) => (
                                            <option key={s.season_number} value={s.season_number}>
                                                {s.name || `Season ${s.season_number}`}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            )}
                            <h2 className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                                Episodes
                            </h2>
                            {loadingEpisodes ? (
                                <p className="text-sm text-muted-foreground">Loading episodes…</p>
                            ) : episodes.length === 0 ? (
                                <p className="text-sm text-muted-foreground">No episodes found for this season.</p>
                            ) : (
                                <ul className="max-h-[460px] space-y-2 overflow-y-auto pr-1">
                                    {episodes.map((ep) => {
                                        const active = ep.episode_number === episode;
                                        return (
                                            <li key={ep.id}>
                                                <button
                                                    type="button"
                                                    onClick={() => setSeasonEpisode(season, ep.episode_number)}
                                                    className={`w-full rounded-sm border p-3 text-left text-sm transition-colors ${active ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/50'}`}
                                                >
                                                    <span className="font-semibold">
                                                        E{ep.episode_number} — {ep.name}
                                                    </span>
                                                    {ep.duration_minutes ? (
                                                        <span className="mt-1 block text-xs text-muted-foreground">
                                                            {formatDuration(ep.duration_minutes)}
                                                        </span>
                                                    ) : null}
                                                </button>
                                            </li>
                                        );
                                    })}
                                </ul>
                            )}
                        </aside>
                    )}
                </div>
            </div>
        </Layout>
    );
};

export default WatchPage;
