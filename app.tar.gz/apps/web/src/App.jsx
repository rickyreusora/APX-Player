import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { Toaster } from 'sonner';
import ScrollToTop from '@/components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import AdminRoute from '@/components/AdminRoute';
import InstallPrompt from '@/components/InstallPrompt';
import InstallModal from '@/components/InstallModal';
import BroadcastDialog from '@/components/BroadcastDialog';
import PromotionalOffer from '@/components/PromotionalOffer';
import { AuthProvider } from '@/contexts/AuthContext';
import HomePage from '@/pages/HomePage';
import BrowsePage from '@/pages/BrowsePage';
import LiveTVPage from '@/pages/LiveTVPage';
import KaraokeLibraryPage from '@/pages/KaraokeLibraryPage';
import ProReelsPage from '@/pages/ProReelsPage';
import DownloaderPage from '@/pages/DownloaderPage';
import TitleDetailPage from '@/pages/TitleDetailPage';
import WatchPage from '@/pages/WatchPage';
import LoginPage from '@/pages/LoginPage';
import SignupPage from '@/pages/SignupPage';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage';
import DashboardPage from '@/pages/DashboardPage';
import AdminPage from '@/pages/AdminPage';
import AboutPage from '@/pages/AboutPage';
import ContactPage from '@/pages/ContactPage';
import PrivacyPage from '@/pages/PrivacyPage';
import TermsPage from '@/pages/TermsPage';
import ContentRightsPage from '@/pages/ContentRightsPage';
import DnsTutorialPage from '@/pages/DnsTutorialPage';
import NotFoundPage from '@/pages/NotFoundPage';

function App() {
    return (
        <AuthProvider>
            <Router>
                <ScrollToTop />
                <Routes>
                    <Route
                        path="/"
                        element={
                            <ProtectedRoute>
                                <HomePage />
                            </ProtectedRoute>
                        }
                    />
                    <Route
                        path="/karaoke-library"
                        element={
                            <ProtectedRoute>
                                <KaraokeLibraryPage />
                            </ProtectedRoute>
                        }
                    />
                    <Route
                        path="/pro-reels"
                        element={
                            <ProtectedRoute>
                                <ProReelsPage />
                            </ProtectedRoute>
                        }
                    />
                    <Route
                        path="/downloader"
                        element={
                            <ProtectedRoute>
                                <DownloaderPage />
                            </ProtectedRoute>
                        }
                    />
                    <Route
                        path="/browse"
                        element={
                            <ProtectedRoute>
                                <BrowsePage />
                            </ProtectedRoute>
                        }
                    />
                    <Route
                        path="/livetv"
                        element={
                            <ProtectedRoute>
                                <LiveTVPage />
                            </ProtectedRoute>
                        }
                    />
                    <Route
                        path="/title/:slug"
                        element={
                            <ProtectedRoute>
                                <TitleDetailPage />
                            </ProtectedRoute>
                        }
                    />
                    <Route
                        path="/watch/:slug"
                        element={
                            <ProtectedRoute>
                                <WatchPage />
                            </ProtectedRoute>
                        }
                    />
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/signup" element={<SignupPage />} />
                    <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                    <Route
                        path="/dashboard"
                        element={
                            <ProtectedRoute>
                                <DashboardPage />
                            </ProtectedRoute>
                        }
                    />
                    <Route
                        path="/admin"
                        element={
                            <AdminRoute>
                                <AdminPage />
                            </AdminRoute>
                        }
                    />
                    <Route path="/about" element={<AboutPage />} />
                    <Route path="/contact" element={<ContactPage />} />
                    <Route path="/privacy" element={<PrivacyPage />} />
                    <Route path="/terms" element={<TermsPage />} />
                    <Route path="/content-rights" element={<ContentRightsPage />} />
                    <Route path="/dns-tutorial" element={<DnsTutorialPage />} />
                    <Route path="*" element={<NotFoundPage />} />
                </Routes>
                <Toaster theme="dark" position="top-right" richColors />
                <InstallPrompt />
                <InstallModal />
                <BroadcastDialog />
                <PromotionalOffer />
            </Router>
        </AuthProvider>
    );
}

export default App;
