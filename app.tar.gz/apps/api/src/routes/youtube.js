import { Router } from 'express';
import { isIntegrationConfigured, respondNotConfigured } from '../utils/integrationConfig.js';
import logger from '../utils/logger.js';

const router = Router();

// YouTube Data API v3 integration for the ApX Karaoke song database.
//
// A user-supplied key (YOUTUBE_API_KEY in apps/api/.env) unlocks the real
// Data API: richer metadata (exact duration, view count, upload date) and a
// proper quota. When the key is absent we fall back to scraping YouTube's
// ytInitialData so the feature still works (with lighter metadata) — the
// frontend gets the same normalized shape either way.
//
// Search results are cached in-process (the instance hibernates when idle, so
// a process-lifetime cache is enough) and best-effort upserted into the
// PocketBase `karaoke_songs` collection so the curated database persists.

const YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY;

const BROWSER_UA =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

const HEADERS = {
    'User-Agent': BROWSER_UA,
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
};

async function fetchWithTimeout(target, opts = {}, ms = 12000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    try {
        return await fetch(target, { ...opts, signal: ctrl.signal });
    } finally {
        clearTimeout(t);
    }
}

/* ------------------------------------------------------------------ */
/*  In-memory cache + quota tracker                                    */
/* ------------------------------------------------------------------ */
const CACHE_TTL = 6 * 60 * 60 * 1000;
const cache = new Map();

function cacheGet(key) {
    const e = cache.get(key);
    if (!e) return null;
    if (Date.now() > e.exp) {
        cache.delete(key);
        return null;
    }
    return e.value;
}
function cacheSet(key, value) {
    cache.set(key, { value, exp: Date.now() + CACHE_TTL });
}

// YouTube Data API v3 default daily quota is 10,000 units. A search.list call
// costs 100 units; videos.list costs 1 unit. We track a rolling daily counter
// and, when close to the budget, stop making API calls and serve from cache
// (or the scrape fallback) instead.
const QUOTA_BUDGET = 9000; // leave headroom
let quotaUsed = 0;
let quotaResetAt = startOfNextDay();

function startOfNextDay() {
    const d = new Date();
    d.setUTCHours(24, 0, 0, 0);
    return d.getTime();
}
function quotaAvailable(cost) {
    if (Date.now() > quotaResetAt) {
        quotaUsed = 0;
        quotaResetAt = startOfNextDay();
    }
    return quotaUsed + cost <= QUOTA_BUDGET;
}
function quotaSpend(cost) {
    quotaUsed += cost;
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */
// Parse ISO 8601 duration (PT#H#M#S) → seconds.
function parseIsoDuration(iso) {
    if (!iso) return null;
    const m = iso.match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/i);
    if (!m) return null;
    const h = parseInt(m[1] || '0', 10);
    const min = parseInt(m[2] || '0', 10);
    const s = parseInt(m[3] || '0', 10);
    return h * 3600 + min * 60 + s;
}

function formatDuration(sec) {
    if (sec == null || Number.isNaN(sec)) return null;
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${String(s).padStart(2, '0')}`;
}

const GENRE_RULES = [
    { genre: 'OPM', re: /\b(opm|filipino|philippines|tagalog|cebuano|manila)\b/i },
    { genre: 'K-Pop', re: /\b(korea|kpop|k-pop|bts|blackpink|twice|gangnam)\b/i },
    { genre: 'J-Pop', re: /\b(japan|jpop|j-pop|anime|tokyo|ghibli|naruto|one ok rock)\b/i },
    { genre: 'Latin', re: /\b(latin|salsa|bailando|despacito|bamba|bolero|spanish|reggaeton)\b/i },
    { genre: 'Rock', re: /\b(rock|guitar|metal|punk|alternative)\b/i },
    { genre: 'Pop', re: /\b(pop|dance|disco|funk|soul|love|heart|tonight|baby)\b/i },
    { genre: 'Country', re: /\b(country|western|nashville)\b/i },
    { genre: 'R&B', re: /\b(r&b|rnb|soul|blues|jazz)\b/i },
    { genre: 'Holiday', re: /\b(christmas|carol|jingle|santa|holiday)\b/i },
];

function inferGenre(text) {
    if (!text) return 'Other';
    for (const r of GENRE_RULES) if (r.re.test(text)) return r.genre;
    return 'Other';
}

// Heuristic difficulty from duration + title keywords.
function inferDifficulty(title, sec) {
    const t = (title || '').toLowerCase();
    if (/\b(ballad|power|anthem|diva|whitney|celine|aria|opera|bohemian)\b/.test(t)) return 'Expert';
    if (sec != null && sec >= 270) return 'Hard';
    if (/\b(rock|rap|fast|medley)\b/.test(t)) return 'Hard';
    if (sec != null && sec <= 180) return 'Easy';
    return 'Normal';
}

function normalizeYouTube({
    videoId,
    title,
    artist,
    thumbnail,
    durationSec,
    durationLabel,
    viewCount,
    publishedAt,
    channelTitle,
}) {
    const sec = durationSec != null ? durationSec : null;
    return {
        id: `yt:${videoId}`,
        videoId,
        title: (title || 'Unknown').toString().trim(),
        artist: (artist || channelTitle || 'Unknown').toString().trim(),
        thumbnail: thumbnail || null,
        duration: durationLabel || formatDuration(sec) || null,
        durationSec: sec,
        views: viewCount != null ? viewCount.toLocaleString() : null,
        viewCount: viewCount || 0,
        publishedAt: publishedAt || null,
        language: 'International',
        genre: inferGenre(`${title} ${artist || ''}`),
        difficulty: inferDifficulty(title, sec),
        source: 'youtube',
    };
}

/* ------------------------------------------------------------------ */
/*  PocketBase upsert (best-effort, lazy)                              */
/* ------------------------------------------------------------------ */
let pbClient = null;
async function getPbClient() {
    if (pbClient !== null) return pbClient;
    try {
        // Lazy import so Express never crashes if PB is unavailable.
        const mod = await import('../utils/pocketbaseClient.js');
        pbClient = mod.default;
        return pbClient;
    } catch (err) {
        logger.warn('youtube: PocketBase client unavailable, skipping upsert', String(err));
        pbClient = false;
        return false;
    }
}

async function upsertSongs(songs) {
    if (!songs || !songs.length) return;
    try {
        const pb = await getPbClient();
        if (!pb) return;
        for (const s of songs) {
            try {
                // Find existing by video_id; upsert.
                const existing = await pb
                    .collection('karaoke_songs')
                    .getFirstListItem(`video_id = "${s.videoId}"`)
                    .catch(() => null);
                const payload = {
                    video_id: s.videoId,
                    title: s.title,
                    artist: s.artist,
                    duration_seconds: s.durationSec || 0,
                    thumbnail: s.thumbnail || '',
                    source: 'youtube',
                    language: s.language,
                    genre: s.genre,
                    view_count: s.viewCount || 0,
                    upload_date: s.publishedAt || '',
                    difficulty: s.difficulty,
                };
                if (existing) {
                    await pb.collection('karaoke_songs').update(existing.id, payload);
                } else {
                    await pb.collection('karaoke_songs').create(payload);
                }
            } catch {
                /* per-song upsert failure is non-fatal */
            }
        }
    } catch {
        /* best-effort */
    }
}

/* ------------------------------------------------------------------ */
/*  YouTube Data API v3 path                                           */
/* ------------------------------------------------------------------ */
async function youtubeApiSearch({ q, max, order, lang }) {
    const searchCost = 100;
    if (!quotaAvailable(searchCost)) {
        throw new Error('youtube api quota exhausted');
    }
    const params = new URLSearchParams({
        part: 'snippet',
        type: 'video',
        videoEmbeddable: 'true',
        maxResults: String(Math.min(Math.max(max || 15, 5), 50)),
        q: `${q} karaoke`,
        key: YOUTUBE_API_KEY,
        order: order || 'relevance',
    });
    if (lang) params.set('relevanceLanguage', lang);

    const searchRes = await fetchWithTimeout(
        `https://www.googleapis.com/youtube/v3/search?${params.toString()}`,
        { headers: { Accept: 'application/json' } },
        12000,
    );
    if (!searchRes.ok) {
        throw new Error(`youtube search failed: ${searchRes.status} ${searchRes.statusText}`);
    }
    quotaSpend(searchCost);
    const searchData = await searchRes.json();
    const items = Array.isArray(searchData.items) ? searchData.items : [];
    const videoIds = items
        .map((it) => it?.id?.videoId)
        .filter(Boolean);

    if (!videoIds.length) return [];

    // videos.list for durations + statistics (1 unit).
    const detailCost = 1;
    if (quotaAvailable(detailCost)) {
        const vparams = new URLSearchParams({
            part: 'contentDetails,statistics,snippet',
            id: videoIds.join(','),
            key: YOUTUBE_API_KEY,
        });
        const vRes = await fetchWithTimeout(
            `https://www.googleapis.com/youtube/v3/videos?${vparams.toString()}`,
            { headers: { Accept: 'application/json' } },
            12000,
        );
        if (vRes.ok) {
            quotaSpend(detailCost);
            const vData = await vRes.json();
            const byId = new Map((vData.items || []).map((it) => [it.id, it]));
            return items
                .map((it) => {
                    const id = it?.id?.videoId;
                    if (!id) return null;
                    const det = byId.get(id);
                    const snip = det?.snippet || it?.snippet || {};
                    const thumbs = snip.thumbnails || {};
                    const thumb =
                        thumbs.medium?.url || thumbs.high?.url || thumbs.default?.url || null;
                    return normalizeYouTube({
                        videoId: id,
                        title: (snip.title || '').replace(/\s*\|\s*.*$/, '').trim(),
                        artist: null,
                        channelTitle: snip.channelTitle || null,
                        thumbnail: thumb,
                        durationSec: parseIsoDuration(det?.contentDetails?.duration),
                        viewCount: det?.statistics?.viewCount
                            ? parseInt(det.statistics.viewCount, 10)
                            : null,
                        publishedAt: snip.publishedAt || null,
                    });
                })
                .filter(Boolean);
        }
    }

    // Fallback: search.list items only (no durations).
    return items
        .map((it) => {
            const id = it?.id?.videoId;
            if (!id) return null;
            const snip = it?.snippet || {};
            const thumbs = snip.thumbnails || {};
            const thumb =
                thumbs.medium?.url || thumbs.high?.url || thumbs.default?.url || null;
            return normalizeYouTube({
                videoId: id,
                title: (snip.title || '').trim(),
                channelTitle: snip.channelTitle || null,
                thumbnail: thumb,
                publishedAt: snip.publishedAt || null,
            });
        })
        .filter(Boolean);
}

/* ------------------------------------------------------------------ */
/*  Scrape fallback (no API key)                                       */
/* ------------------------------------------------------------------ */
function parseYouTubeScrape(html) {
    const m = html.match(/var\s+ytInitialData\s*=\s*(\{[\s\S]*?\});\s*<\/script>/);
    if (!m) return [];
    let data;
    try {
        data = JSON.parse(m[1]);
    } catch {
        return [];
    }
    const out = [];
    const seen = new Set();
    function walk(o, depth) {
        if (!o || typeof o !== 'object' || depth > 60) return;
        if (o.videoId && o.title && !seen.has(o.videoId)) {
            seen.add(o.videoId);
            const title = (o.title.runs || []).map((r) => r.text).join('').trim();
            const thumbs = o.thumbnail?.thumbnails || [];
            const thumb = thumbs.length ? thumbs[thumbs.length - 1].url : null;
            if (title) {
                out.push(
                    normalizeYouTube({
                        videoId: o.videoId,
                        title,
                        channelTitle:
                            o.longBylineText?.runs?.[0]?.text ||
                            o.ownerText?.runs?.[0]?.text ||
                            null,
                        thumbnail: thumb,
                        durationLabel: o.lengthText?.simpleText || null,
                        viewCount: o.viewCountText?.simpleText
                            ? parseInt(String(o.viewCountText.simpleText).replace(/[^\d]/g, ''), 10) || null
                            : null,
                    }),
                );
            }
        }
        for (const k of Object.keys(o)) walk(o[k], depth + 1);
    }
    walk(data, 0);
    return out.slice(0, 15);
}

async function youtubeScrapeSearch(q) {
    const target = `https://www.youtube.com/results?search_query=${encodeURIComponent(
        `${q} karaoke`,
    )}`;
    const r = await fetchWithTimeout(
        target,
        {
            headers: {
                'User-Agent': BROWSER_UA,
                Accept: 'text/html,application/xhtml+xml',
                'Accept-Language': 'en-US,en;q=0.9',
            },
            redirect: 'follow',
        },
        11000,
    );
    if (!r.ok) {
        throw new Error(`youtube scrape failed: ${r.status} ${r.statusText}`);
    }
    const html = await r.text();
    return parseYouTubeScrape(html);
}

/* ------------------------------------------------------------------ */
/*  Routes                                                             */
/* ------------------------------------------------------------------ */

// GET /youtube/status — is the YouTube Data API key configured?
router.get('/status', (req, res) => {
    res.json({
        configured: isIntegrationConfigured('YOUTUBE_API_KEY'),
        quotaUsed,
        quotaBudget: QUOTA_BUDGET,
    });
});

// GET /youtube/search?q=&max=&order=&lang=
// order: relevance | viewCount | date | rating
router.get('/search', async (req, res) => {
    const q = (req.query.q || '').trim();
    if (!q) {
        return res.status(422).json({ error: 'A search query is required.' });
    }
    const max = parseInt(req.query.max, 10) || 15;
    const order = (req.query.order || 'relevance').toLowerCase();
    const lang = req.query.lang || '';

    const cacheKey = `ytsearch:${order}:${lang}:${q.toLowerCase()}`;
    const cached = cacheGet(cacheKey);
    if (cached) return res.json(cached);

    let songs = [];
    let usedApi = false;
    if (isIntegrationConfigured('YOUTUBE_API_KEY')) {
        try {
            songs = await youtubeApiSearch({ q, max, order, lang });
            usedApi = true;
        } catch (err) {
            logger.warn('youtube api search failed, falling back to scrape', String(err));
            songs = await youtubeScrapeSearch(q);
        }
    } else {
        // No key — scrape. Still fully functional, lighter metadata.
        songs = await youtubeScrapeSearch(q);
    }

    // Best-effort persist to the karaoke_songs database.
    void upsertSongs(songs);

    const out = {
        query: q,
        source: usedApi ? 'youtube-api' : 'youtube-scrape',
        configured: isIntegrationConfigured('YOUTUBE_API_KEY'),
        total: songs.length,
        songs,
    };
    cacheSet(cacheKey, out);
    res.json(out);
});

// GET /youtube/trending — curated popular karaoke searches, merged + deduped.
router.get('/trending', async (req, res) => {
    const cacheKey = 'yttrending';
    const cached = cacheGet(cacheKey);
    if (cached) return res.json(cached);

    const seeds = [
        'popular karaoke songs 2024',
        'opm karaoke hits',
        'kpop karaoke',
        'classic rock karaoke',
        'love song karaoke',
    ];
    const seen = new Set();
    const merged = [];
    // Run a couple of seeds to stay light on quota.
    const picks = isIntegrationConfigured('YOUTUBE_API_KEY') ? seeds.slice(0, 3) : seeds.slice(0, 2);
    for (const seed of picks) {
        try {
            let list;
            if (isIntegrationConfigured('YOUTUBE_API_KEY')) {
                try {
                    list = await youtubeApiSearch({ q: seed, max: 10, order: 'viewCount' });
                } catch {
                    list = await youtubeScrapeSearch(seed);
                }
            } else {
                list = await youtubeScrapeSearch(seed);
            }
            for (const s of list) {
                if (seen.has(s.videoId)) continue;
                seen.add(s.videoId);
                merged.push(s);
            }
        } catch {
            /* ignore seed failures */
        }
    }
    merged.sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0));
    const top = merged.slice(0, 24);
    void upsertSongs(top);
    const out = { source: 'youtube', total: top.length, songs: top };
    cacheSet(cacheKey, out);
    res.json(out);
});

export default router;
