import { Router } from 'express';
import { Readable } from 'node:stream';

const router = Router();

const CIGNAL_PLAYLIST_URL = 'https://maruyatvph.com/cignal.m3u';
const CONVERGE_PLAYLIST_URL = 'https://maruyatvph.com/converge.m3u';

// --- small XML helpers for the Converge manifest rewrite ---
const decodeXml = (s) =>
    s
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&apos;/g, "'");

const xmlEscape = (s) =>
    s
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');

// Encode a string for use in a URL query value, but keep Shaka's
// $Time$ / $RepresentationID$ / $Number$ / $Bandwidth$ placeholders literal
// (encodeURIComponent encodes "$" to %24, which Shaka would not substitute).
const encodeSeg = (s) => encodeURIComponent(s).replace(/%24/g, '$');

// Parse an M3U playlist (Kodi-style with KODIPROP clearkey lines) into a
// flat list of channel objects the frontend can render and feed to Shaka.
function parsePlaylist(text) {
    const lines = text.split(/\r?\n/);
    const channels = [];
    let current = null;
    let pendingProps = {};

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        if (line.startsWith('#EXTINF')) {
            // #EXTINF:-1 tvg-id="x" tvg-logo="y" group-title="z",Channel Name
            const commaIdx = line.indexOf(',');
            const name = commaIdx >= 0 ? line.slice(commaIdx + 1).trim() : '';
            const attrsPart = commaIdx >= 0 ? line.slice(0, commaIdx) : line;
            const tvgId = (attrsPart.match(/tvg-id="([^"]*)"/) || [])[1] || '';
            const tvgLogo = (attrsPart.match(/tvg-logo="([^"]*)"/) || [])[1] || '';
            const groupTitle =
                (attrsPart.match(/group-title="([^"]*)"/) || [])[1] || 'Other';

            current = {
                name,
                tvgId,
                logo: tvgLogo,
                group: groupTitle,
                url: '',
                clearkey: null,
            };
            pendingProps = {};
        } else if (line.startsWith('#KODIPROP:')) {
            // Collect clearkey license type + key for the current channel.
            const body = line.slice('#KODIPROP:'.length);
            const eqIdx = body.indexOf('=');
            if (eqIdx < 0) continue;
            const key = body.slice(0, eqIdx).trim();
            const val = body.slice(eqIdx + 1).trim();
            pendingProps[key] = val;
        } else if (!line.startsWith('#')) {
            // Stream URL line. Finalize the current channel.
            if (current) {
                current.url = line;
                if (pendingProps['inputstream.adaptive.license_type'] === 'clearkey') {
                    const licKey = pendingProps['inputstream.adaptive.license_key'] || '';
                    // Format: KID:KEY (hex)
                    const [kid, keyHex] = licKey.split(':');
                    if (kid && keyHex) {
                        current.clearkey = { kid: kid.trim(), key: keyHex.trim() };
                    }
                }
                channels.push(current);
                current = null;
                pendingProps = {};
            }
        }
    }

    return channels;
}

// Build a sorted, unique group list from a channel array.
function groupsFrom(channels) {
    const groupSet = new Set();
    for (const c of channels) groupSet.add(c.group || 'Other');
    return Array.from(groupSet).sort((a, b) => a.localeCompare(b));
}

// GET /livetv/playlist — fetch and parse the Cignal m3u into JSON.
router.get('/playlist', async (req, res) => {
    const upstream = await fetch(CIGNAL_PLAYLIST_URL);
    if (!upstream.ok) {
        throw new Error(
            `livetv playlist fetch failed: ${upstream.status} ${upstream.statusText}`,
        );
    }
    const text = await upstream.text();
    const channels = parsePlaylist(text).map((c) => ({ ...c, source: 'Cignal' }));
    res.json({ channels, groups: groupsFrom(channels) });
});

// GET /livetv/converge/playlist — fetch and parse the Converge m3u into JSON.
// Stream URLs are rewritten to point at the Converge manifest proxy below so
// the browser never loads the mixed-content / geo-restricted origin directly.
router.get('/converge/playlist', async (req, res) => {
    const upstream = await fetch(CONVERGE_PLAYLIST_URL);
    if (!upstream.ok) {
        throw new Error(
            `converge playlist fetch failed: ${upstream.status} ${upstream.statusText}`,
        );
    }
    const text = await upstream.text();
    const channels = parsePlaylist(text).map((c) => ({
        ...c,
        source: 'Converge',
        // Hand the browser our proxy manifest URL; the original origin URL
        // travels encoded in the `u` query param.
        url: `/hcgi/api/livetv/converge/stream?u=${encodeURIComponent(c.url)}`,
        clearkey: null,
    }));
    res.json({ channels, groups: groupsFrom(channels) });
});

// GET /livetv/converge/stream?u=<original manifest URL>
// Fetches the original (HTTP, IP-based) DASH manifest, follows the JITP
// redirect, then rewrites every SegmentTemplate media/init URL so the
// segments are fetched through /livetv/converge/segment instead of the
// origin. Returns a browser-safe, same-origin MPD.
router.get('/converge/stream', async (req, res) => {
    const u = req.query.u;
    if (!u) {
        return res
            .status(422)
            .json({ error: 'u query param (original manifest URL) is required' });
    }

    const upstream = await fetch(u, { redirect: 'follow' });
    if (!upstream.ok) {
        throw new Error(
            `converge manifest fetch failed: ${upstream.status} ${upstream.statusText}`,
        );
    }

    // After the JITP 302, upstream.url is the final manifest URL. Segment
    // template URLs are relative, so they resolve against this base dir.
    const finalUrl = upstream.url || u;
    const base = finalUrl.slice(0, finalUrl.lastIndexOf('/') + 1);
    const encBase = encodeURIComponent(base);

    const xml = await upstream.text();

    const rewritten = xml.replace(
        /\b(media|initialization)="([^"]*)"/g,
        (match, attr, rawVal) => {
            const raw = decodeXml(rawVal); // e.g. fragment-$Time$-$RepresentationID$.m4s?pkgip=...&...
            const proxyUrl = `segment?base=${encBase}&seg=${encodeSeg(raw)}`;
            return `${attr}="${xmlEscape(proxyUrl)}"`;
        },
    );

    res.set('Content-Type', 'application/dash+xml');
    res.set('Cache-Control', 'no-store');
    res.set('Access-Control-Allow-Origin', '*');
    res.send(rewritten);
});

// GET /livetv/converge/segment?base=<origin base dir>&seg=<segment path+query>
// Proxies a single DASH segment (init .mp4 or fragment .m4s) from the
// origin, streaming the bytes back to the browser.
router.get('/converge/segment', async (req, res) => {
    const base = req.query.base;
    const seg = req.query.seg;
    if (!base || !seg) {
        return res
            .status(422)
            .json({ error: 'base and seg query params are required' });
    }

    const fullUrl = base + seg;
    const upstream = await fetch(fullUrl, { redirect: 'follow' });
    if (!upstream.ok) {
        throw new Error(
            `converge segment fetch failed: ${upstream.status} ${upstream.statusText}`,
        );
    }

    res.set('Content-Type', upstream.headers.get('content-type') || 'application/octet-stream');
    res.set('Cache-Control', 'no-store');
    res.set('Access-Control-Allow-Origin', '*');

    // Stream the upstream body straight through to the client.
    Readable.fromWeb(upstream.body).pipe(res);
});

export default router;
