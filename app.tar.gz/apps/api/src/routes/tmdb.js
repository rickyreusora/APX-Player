import { Router } from 'express';
import {
  isIntegrationConfigured,
  respondNotConfigured,
} from '../utils/integrationConfig.js';

const router = Router();

const TMDB_BASE = 'https://api.themoviedb.org/3';
const IMG_BASE = 'https://image.tmdb.org/t/p';
const TMDB_KEY = process.env.TMDB_API_KEY;

const posterUrl = (path) => (path ? `${IMG_BASE}/w500${path}` : '');
const backdropUrl = (path) => (path ? `${IMG_BASE}/w1280${path}` : '');
const stillUrl = (path) => (path ? `${IMG_BASE}/w500${path}` : '');

const slugify = (s) =>
  String(s || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');

const yearOf = (d) => (d ? String(d).slice(0, 4) : '');

// Normalize a TMDB list item into the shape the frontend expects.
function normalizeItem(raw, forcedKind) {
  const kind = forcedKind || (raw.media_type === 'tv' ? 'series' : raw.media_type === 'movie' ? 'movie' : raw.first_air_date ? 'series' : 'movie');
  const isTv = kind === 'series';
  const name = isTv ? raw.name : raw.title;
  return {
    id: raw.id,
    tmdb_id: raw.id,
    kind,
    title: name || raw.original_name || raw.original_title || 'Untitled',
    slug: `${isTv ? 'series' : 'movie'}-${raw.id}`,
    synopsis: raw.overview || '',
    poster: posterUrl(raw.poster_path),
    backdrop: backdropUrl(raw.backdrop_path || raw.poster_path),
    year: Number(yearOf(isTv ? raw.first_air_date : raw.release_date)) || null,
    rating: typeof raw.vote_average === 'number' ? Math.round(raw.vote_average * 10) / 10 : null,
    popularity: raw.popularity || raw.vote_count || 0,
    genre_ids: raw.genre_ids || [],
  };
}

async function tmdbFetch(path, query = {}) {
  const url = new URL(`${TMDB_BASE}${path}`);
  url.searchParams.set('api_key', TMDB_KEY);
  url.searchParams.set('language', 'en-US');
  for (const [k, v] of Object.entries(query)) {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v));
  }
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`tmdb ${path} failed: ${res.status} ${res.statusText}`);
  }
  return res.json();
}

// Guard every route: if the user hasn't added their TMDB key yet, report the
// setup state instead of throwing a 500 on every catalogue load.
router.use((req, res, next) => {
  if (!isIntegrationConfigured('TMDB_API_KEY')) {
    return respondNotConfigured(res, { integration: 'TMDB', envKeys: 'TMDB_API_KEY' });
  }
  next();
});

// --- Status ---
router.get('/status', (req, res) => {
  res.json({ configured: true });
});

// --- Genres (movie + tv merged) ---
router.get('/genres', async (req, res, next) => {
  try {
    const kind = req.query.kind; // 'movie' | 'tv' | undefined
    const kinds = kind === 'movie' ? ['movie'] : kind === 'tv' ? ['tv'] : ['movie', 'tv'];
    const out = [];
    const seen = new Set();
    for (const k of kinds) {
      const data = await tmdbFetch(`/genre/${k}/list`);
      for (const g of data.genres || []) {
        if (seen.has(g.id)) continue;
        seen.add(g.id);
        out.push({ id: g.id, name: g.name, slug: slugify(g.name) });
      }
    }
    res.json(out);
  } catch (err) {
    next(err);
  }
});

// --- Catalog (browse): search, discover, or trending ---
router.get('/catalog', async (req, res) => {
  const { q, kind, genre, sort, page = 1 } = req.query;
  const pageNum = Math.max(1, Number(page) || 1);

  if (q && String(q).trim()) {
    const data = await tmdbFetch('/search/multi', { query: q, page: pageNum });
    const items = (data.results || [])
      .filter((r) => r.media_type === 'movie' || r.media_type === 'tv')
      .map((r) => normalizeItem(r));
    return res.json({
      items,
      page: data.page,
      totalPages: data.total_pages,
      totalItems: data.total_results,
    });
  }

  const tmdbKind = kind === 'series' ? 'tv' : kind === 'movie' ? 'movie' : null;

  if (tmdbKind) {
    const sortMap = {
      popular: 'popularity.desc',
      top_rated: 'vote_average.desc',
      newest: tmdbKind === 'tv' ? 'first_air_date.desc' : 'release_date.desc',
      oldest: tmdbKind === 'tv' ? 'first_air_date.asc' : 'release_date.asc',
      title: tmdbKind === 'tv' ? 'name.asc' : 'original_title.asc',
    };
    const sortBy = sortMap[sort] || 'popularity.desc';
    const query = { sort_by: sortBy, page: pageNum, 'vote_count.gte': sort === 'top_rated' ? 200 : undefined };
    if (genre && genre !== 'all') query.with_genres = genre;
    const data = await tmdbFetch(`/discover/${tmdbKind}`, query);
    const items = (data.results || []).map((r) => normalizeItem(r, kind));
    return res.json({
      items,
      page: data.page,
      totalPages: data.total_pages,
      totalItems: data.total_results,
    });
  }

  // kind=all -> trending
  const data = await tmdbFetch('/trending/all/week', { page: pageNum });
  const items = (data.results || [])
    .filter((r) => r.media_type === 'movie' || r.media_type === 'tv')
    .map((r) => normalizeItem(r));
  res.json({
    items,
    page: data.page,
    totalPages: data.total_pages,
    totalItems: data.total_results,
  });
});

// --- Home rows ---
router.get('/home', async (req, res, next) => {
  try {
    const [trending, popMovies, popTv, topRated] = await Promise.all([
      tmdbFetch('/trending/all/week'),
      tmdbFetch('/movie/popular'),
      tmdbFetch('/tv/popular'),
      tmdbFetch('/movie/top_rated'),
    ]);
    const norm = (list, forced) => (list || []).map((r) => normalizeItem(r, forced));
    res.json({
      featured: norm(trending.results),
      recent: norm(popMovies.results, 'movie'),
      popular: norm(topRated.results, 'movie'),
      series: norm(popTv.results, 'series'),
    });
  } catch (err) {
    next(err);
  }
});

// --- Movie details ---
router.get('/movie/:id', async (req, res) => {
  const data = await tmdbFetch(`/movie/${req.params.id}`, {
    append_to_response: 'credits,release_dates,videos',
  });
  const cast = (data.credits?.cast || []).slice(0, 12).map((c) => c.name).join(', ');
  const director = (data.credits?.crew || []).find((c) => c.job === 'Director');
  let ageRating = '';
  const us = (data.release_dates?.results || []).find((r) => r.iso_3166_1 === 'US');
  if (us?.release_dates?.[0]?.certification) ageRating = us.release_dates[0].certification;
  const trailer = (data.videos?.results || []).find((v) => v.type === 'Trailer' && v.site === 'YouTube');
  res.json({
    id: data.id,
    tmdb_id: data.id,
    kind: 'movie',
    title: data.title,
    slug: `movie-${data.id}`,
    synopsis: data.overview || '',
    poster: posterUrl(data.poster_path),
    backdrop: backdropUrl(data.backdrop_path),
    year: Number(yearOf(data.release_date)) || null,
    rating: typeof data.vote_average === 'number' ? Math.round(data.vote_average * 10) / 10 : null,
    age_rating: ageRating,
    duration_minutes: data.runtime || null,
    cast_list: cast,
    creator: director?.name || '',
    trailer_url: trailer ? `https://www.youtube.com/watch?v=${trailer.key}` : '',
    genres: (data.genres || []).map((g) => ({ id: g.id, name: g.name, slug: slugify(g.name) })),
    production_companies: (data.production_companies || []).map((c) => ({ id: c.id, name: c.name })),
    networks: [],
    popularity: data.popularity || 0,
    rights_holder: '',
  });
});

// --- TV details ---
router.get('/tv/:id', async (req, res) => {
  const data = await tmdbFetch(`/tv/${req.params.id}`, {
    append_to_response: 'credits,videos,content_ratings',
  });
  const cast = (data.credits?.cast || []).slice(0, 12).map((c) => c.name).join(', ');
  const creator = (data.created_by || []).map((c) => c.name).join(', ');
  let ageRating = '';
  const us = (data.content_ratings?.results || []).find((r) => r.iso_3166_1 === 'US');
  if (us?.rating) ageRating = us.rating;
  const trailer = (data.videos?.results || []).find((v) => v.type === 'Trailer' && v.site === 'YouTube');
  const seasons = (data.seasons || [])
    .filter((s) => s.season_number > 0)
    .map((s) => ({
      season_number: s.season_number,
      name: s.name,
      episode_count: s.episode_count,
      poster: posterUrl(s.poster_path),
      overview: s.overview || '',
    }));
  res.json({
    id: data.id,
    tmdb_id: data.id,
    kind: 'series',
    title: data.name,
    slug: `series-${data.id}`,
    synopsis: data.overview || '',
    poster: posterUrl(data.poster_path),
    backdrop: backdropUrl(data.backdrop_path),
    year: Number(yearOf(data.first_air_date)) || null,
    rating: typeof data.vote_average === 'number' ? Math.round(data.vote_average * 10) / 10 : null,
    age_rating: ageRating,
    duration_minutes: (data.episode_run_time || [])[0] || null,
    cast_list: cast,
    creator,
    trailer_url: trailer ? `https://www.youtube.com/watch?v=${trailer.key}` : '',
    genres: (data.genres || []).map((g) => ({ id: g.id, name: g.name, slug: slugify(g.name) })),
    networks: (data.networks || []).map((n) => ({ id: n.id, name: n.name })),
    production_companies: (data.production_companies || []).map((c) => ({ id: c.id, name: c.name })),
    popularity: data.popularity || 0,
    number_of_seasons: data.number_of_seasons || seasons.length,
    seasons,
    rights_holder: '',
  });
});

// --- Season details (episode list) ---
router.get('/tv/:id/season/:season', async (req, res) => {
  const data = await tmdbFetch(`/tv/${req.params.id}/season/${req.params.season}`);
  const episodes = (data.episodes || []).map((ep) => ({
    id: ep.id,
    episode_number: ep.episode_number,
    season_number: ep.season_number,
    name: ep.name,
    synopsis: ep.overview || '',
    still: stillUrl(ep.still_path),
    duration_minutes: ep.runtime || null,
    air_date: ep.air_date || '',
  }));
  res.json({
    season_number: data.season_number,
    name: data.name,
    episodes,
  });
});

// --- Network catalog (Vivamax / Viva One) ---
// In-memory server-side cache for network discover results.
const networkCache = new Map();
const NETWORK_CACHE_TTL = 10 * 60 * 1000; // 10 minutes

const NETWORK_SORT_MAP = (tmdbKind) => ({
  popular: 'popularity.desc',
  top_rated: 'vote_average.desc',
  newest: tmdbKind === 'tv' ? 'first_air_date.desc' : 'release_date.desc',
  oldest: tmdbKind === 'tv' ? 'first_air_date.asc' : 'release_date.asc',
  title: tmdbKind === 'tv' ? 'name.asc' : 'original_title.asc',
});

async function discoverByNetwork(networkId, tmdbKind, sort, page) {
  const sortBy = (NETWORK_SORT_MAP(tmdbKind)[sort] || 'popularity.desc');
  return tmdbFetch(`/discover/${tmdbKind}`, {
    with_networks: networkId,
    sort_by: sortBy,
    page,
    'vote_count.gte': sort === 'top_rated' ? 50 : undefined,
  });
}

async function discoverByCompany(companyId, tmdbKind, sort, page) {
  const sortBy = (NETWORK_SORT_MAP(tmdbKind)[sort] || 'popularity.desc');
  return tmdbFetch(`/discover/${tmdbKind}`, {
    with_companies: companyId,
    sort_by: sortBy,
    page,
    'vote_count.gte': sort === 'top_rated' ? 50 : undefined,
  });
}

// Shared merge + re-sort logic for network/company discover responses.
function mergeDiscover(responses, fetchKinds, sort) {
  let items = [];
  let totalPages = 1;
  let totalItems = 0;
  fetchKinds.forEach((k, i) => {
    const data = responses[i];
    const forced = k === 'tv' ? 'series' : 'movie';
    items = items.concat((data.results || []).map((r) => normalizeItem(r, forced)));
    totalPages = Math.max(totalPages, data.total_pages || 1);
    totalItems += data.total_results || 0;
  });
  const sortFns = {
    popular: (a, b) => (b.popularity || 0) - (a.popularity || 0),
    top_rated: (a, b) => (b.rating || 0) - (a.rating || 0),
    newest: (a, b) => (b.year || 0) - (a.year || 0),
    oldest: (a, b) => (a.year || 0) - (b.year || 0),
    title: (a, b) => String(a.title).localeCompare(String(b.title)),
  };
  items.sort(sortFns[sort] || sortFns.popular);
  return { items, totalPages, totalItems };
}

router.get('/network/:networkId', async (req, res) => {
  const { networkId } = req.params;
  if (!/^\d+$/.test(networkId)) {
    return res.status(422).json({ error: 'networkId must be numeric' });
  }
  const { kind, sort = 'popular', page = 1 } = req.query;
  const pageNum = Math.max(1, Number(page) || 1);

  const cacheKey = `net:${networkId}:${kind || 'all'}:${sort}:${pageNum}`;
  const cached = networkCache.get(cacheKey);
  if (cached && Date.now() - cached.t < NETWORK_CACHE_TTL) {
    return res.json(cached.v);
  }

  const fetchKinds = kind === 'movie' ? ['movie'] : kind === 'series' ? ['tv'] : ['movie', 'tv'];
  const responses = await Promise.all(
    fetchKinds.map((k) => discoverByNetwork(networkId, k, sort, pageNum)),
  );
  const { items, totalPages, totalItems } = mergeDiscover(responses, fetchKinds, sort);

  const payload = {
    networkId: Number(networkId),
    items,
    page: pageNum,
    totalPages,
    totalItems,
  };
  networkCache.set(cacheKey, { t: Date.now(), v: payload });
  res.json(payload);
});

// --- Company catalog (Vivamax / Viva One by production company) ---
router.get('/company/:companyId', async (req, res) => {
  const { companyId } = req.params;
  if (!/^\d+$/.test(companyId)) {
    return res.status(422).json({ error: 'companyId must be numeric' });
  }
  const { kind, sort = 'popular', page = 1 } = req.query;
  const pageNum = Math.max(1, Number(page) || 1);

  const cacheKey = `co:${companyId}:${kind || 'all'}:${sort}:${pageNum}`;
  const cached = networkCache.get(cacheKey);
  if (cached && Date.now() - cached.t < NETWORK_CACHE_TTL) {
    return res.json(cached.v);
  }

  const fetchKinds = kind === 'movie' ? ['movie'] : kind === 'series' ? ['tv'] : ['movie', 'tv'];
  const responses = await Promise.all(
    fetchKinds.map((k) => discoverByCompany(companyId, k, sort, pageNum)),
  );
  const { items, totalPages, totalItems } = mergeDiscover(responses, fetchKinds, sort);

  const payload = {
    companyId: Number(companyId),
    items,
    page: pageNum,
    totalPages,
    totalItems,
  };
  networkCache.set(cacheKey, { t: Date.now(), v: payload });
  res.json(payload);
});

export default router;
