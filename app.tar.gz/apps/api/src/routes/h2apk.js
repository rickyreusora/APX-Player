import { Router } from 'express';
import {
    isIntegrationConfigured,
    respondNotConfigured,
} from '../utils/integrationConfig.js';

const router = Router();

// The H2APK server is a separate Go service the administrator hosts
// (it needs the Android SDK toolchain, which cannot run inside this
// sandbox). The admin points this env var at their running instance,
// e.g. H2APK_URL=http://localhost:8011  or  https://h2apk.example.com
const H2APK_URL = process.env.H2APK_URL ? String(process.env.H2APK_URL).trim().replace(/\/+$/, '') : '';

const POCKETBASE_HOST = 'http://localhost:8090';

/**
 * Verify the caller is an administrator by validating their PocketBase
 * auth token against the users collection. Returns the user record when
 * the token belongs to an admin, otherwise null.
 *
 * The browser sends the raw PocketBase token in the Authorization header
 * (the same value stored in pb.authStore.token).
 */
async function verifyAdmin(req) {
    const auth = req.headers.authorization || '';
    const token = auth.replace(/^Bearer\s+/i, '').trim();
    if (!token) return null;
    try {
        const res = await fetch(`${POCKETBASE_HOST}/api/collections/users/auth-refresh`, {
            method: 'POST',
            headers: { Authorization: token },
        });
        if (!res.ok) return null;
        const data = await res.json();
        const record = data?.record;
        if (record && record.role === 'admin' && !record.banned) return record;
    } catch {
        return null;
    }
    return null;
}

// Every H2APK route requires an authenticated administrator.
router.use(async (req, res, next) => {
    const admin = await verifyAdmin(req);
    if (!admin) {
        return res.status(403).json({ error: 'Administrator access required.' });
    }
    req.admin = admin;
    next();
});

// Configuration probe — the admin UI calls this before showing the builder.
router.get('/status', (req, res) => {
    res.json({ configured: isIntegrationConfigured('H2APK_URL'), url: H2APK_URL || null });
});

// Start a build. Forwards the BuildRequest JSON body to the H2APK server.
router.post('/build', async (req, res) => {
    if (!isIntegrationConfigured('H2APK_URL')) {
        return respondNotConfigured(res, { integration: 'H2APK', envKeys: 'H2APK_URL' });
    }

    const upstream = await fetch(`${H2APK_URL}/api/build`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body || {}),
    });

    if (!upstream.ok) {
        const detail = await upstream.text().catch(() => '');
        res.status(upstream.status);
        try {
            return res.json(JSON.parse(detail));
        } catch {
            return res.json({ success: false, error: detail || upstream.statusText });
        }
    }

    const data = await upstream.json();
    res.json(data);
});

// Poll build status.
router.get('/status/:id', async (req, res) => {
    if (!isIntegrationConfigured('H2APK_URL')) {
        return respondNotConfigured(res, { integration: 'H2APK', envKeys: 'H2APK_URL' });
    }

    const upstream = await fetch(`${H2APK_URL}/api/status/${req.params.id}`);
    if (!upstream.ok) {
        throw new Error(`h2apk status failed: ${upstream.status} ${upstream.statusText}`);
    }
    const data = await upstream.json();
    res.json(data);
});

// SSE log stream — pipes the upstream event stream straight to the browser.
router.get('/log/:id', async (req, res) => {
    if (!isIntegrationConfigured('H2APK_URL')) {
        return respondNotConfigured(res, { integration: 'H2APK', envKeys: 'H2APK_URL' });
    }

    const upstream = await fetch(`${H2APK_URL}/api/log/${req.params.id}`);
    if (!upstream.ok) {
        throw new Error(`h2apk log failed: ${upstream.status} ${upstream.statusText}`);
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    const reader = upstream.body.getReader();
    const onAbort = () => {
        try { reader.cancel(); } catch { /* ignore */ }
        res.end();
    };
    req.on('close', onAbort);

    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            res.write(value);
            res.flush?.();
        }
    } catch {
        // client disconnected or stream ended — nothing to surface
    } finally {
        req.off('close', onAbort);
        res.end();
    }
});

// Named artifact (release builds return both .aab and -release.apk).
router.get('/download-file/:id/:name', async (req, res) => {
    if (!isIntegrationConfigured('H2APK_URL')) {
        return respondNotConfigured(res, { integration: 'H2APK', envKeys: 'H2APK_URL' });
    }
    const name = String(req.params.name || '').replace(/[^a-zA-Z0-9._-]/g, '');
    if (!name) return res.status(400).json({ error: 'Missing file name.' });

    const upstream = await fetch(`${H2APK_URL}/api/download-file/${encodeURIComponent(req.params.id)}/${encodeURIComponent(name)}`);
    if (!upstream.ok) {
        throw new Error(`h2apk download failed: ${upstream.status} ${upstream.statusText}`);
    }
    const contentType = upstream.headers.get('content-type');
    if (contentType) res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
    const reader = upstream.body.getReader();
    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            res.write(value);
        }
    } finally {
        res.end();
    }
});

// Download a finished artifact — streams the file with its original headers.
router.get('/download/:id', async (req, res) => {
    if (!isIntegrationConfigured('H2APK_URL')) {
        return respondNotConfigured(res, { integration: 'H2APK', envKeys: 'H2APK_URL' });
    }

    const upstream = await fetch(`${H2APK_URL}/api/download/${req.params.id}`);
    if (!upstream.ok) {
        throw new Error(`h2apk download failed: ${upstream.status} ${upstream.statusText}`);
    }

    const contentType = upstream.headers.get('content-type');
    const contentDisposition = upstream.headers.get('content-disposition');
    if (contentType) res.setHeader('Content-Type', contentType);
    if (contentDisposition) res.setHeader('Content-Disposition', contentDisposition);

    const reader = upstream.body.getReader();
    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            res.write(value);
        }
    } finally {
        res.end();
    }
});

export default router;
