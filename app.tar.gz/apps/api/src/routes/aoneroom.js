import { Router } from 'express';
import { Readable } from 'node:stream';
import { consumeDownloadToken } from '../utils/downloadQuota.js';

// videodownloader.site search + detail + download workflow.
//
// The site resolves titles through the OneRoom h5 BFF
// (h5-api.aoneroom.com). A guest token is issued by the search-suggest
// endpoint (set-cookie `token`) and is accepted as `Authorization: Bearer`
// by the search and per-episode download endpoints. The detail endpoint is
// public. We only ever deliver downloads the service reports as
// `vipLocked: false` with a real file URL — protected or unavailable sources
// are surfaced as unavailable so the UI can offer in-app playback instead.

const router = Router();

const BFF = 'https://h5-api.aoneroom.com';
const UA = 'ApXPlayer/1.0 (+https://maruyatvph.com)';
const ORIGIN = 'https://videodownloader.site';

const COMMON_HEADERS = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'User-Agent': UA,
    Origin: ORIGIN,
    Referer: `${ORIGIN}/`,
    'X-Client-Info.package_name': 'downloader',
};

// In-memory guest token cache. The token is valid for ~90 days, so a single
// bootstrap per process is enough; we refresh lazily if a call rejects it.
let cachedToken = null;

function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchJson(url, options = {}) {
    const res = await fetch(url, {
        ...options,
        headers: { ...COMMON_HEADERS, ...(options.headers || {}) },
    });
    if (!res.ok) {
        throw new Error(`aoneroom upstream failed: ${res.status} ${res.statusText}`);
    }
    return res;
}

// Bootstrap a guest token by calling search-suggest, which sets it as a cookie.
async function getGuestToken() {
    if (cachedToken) return cachedToken;
    const res = await fetch(`${BFF}/wefeed-h5api-bff/subject/search-suggest`, {
        method: 'POST',
        headers: COMMON_HEADERS,
        body: JSON.stringify({ keyword: 'downloader', perPage: 1 }),
    });
    if (!res.ok) {
        throw new Error(`aoneroom token bootstrap failed: ${res.status} ${res.statusText}`);
    }
    const cookie = res.headers.get('set-cookie') || '';
    const match = cookie.match(/token=([^;]+)/);
    if (!match) {
        throw new Error('aoneroom token bootstrap failed: no token cookie');
    }
    cachedToken = match[1];
    return cachedToken;
}

async function authedJson(url, options = {}) {
    let token = await getGuestToken();
    for (let attempt = 0; attempt < 2; attempt += 1) {
        const res = await fetch(url, {
            ...options,
            headers: {
                ...COMMON_HEADERS,
                Authorization: `Bearer ${token}`,
                ...(options.headers || {}),
            },
        });
        if (res.status === 401 || res.status === 403) {
            // Token rejected — refresh once and retry.
            cachedToken = null;
            token = await getGuestToken();
            continue;
        }
        if (!res.ok) {
            throw new Error(`aoneroom upstream failed: ${res.status} ${res.statusText}`);
        }
        return res.json();
    }
    throw new Error('aoneroom auth failed after token refresh');
}

function pickCover(cover) {
    if (!cover) return '';
    if (typeof cover === 'string') return cover;
    return cover.url || cover.thumbnail || '';
}

function mapSubject(s) {
    if (!s) return null;
    return {
        id: s.subjectId || s.id || '',
        subjectId: s.subjectId || '',
        title: s.title || s.postTitle || '',
        description: s.description || '',
        poster: pickCover(s.cover),
        genre: s.genre || '',
        country: s.countryName || '',
        year: s.releaseDate ? String(s.releaseDate).slice(0, 4) : '',
        releaseDate: s.releaseDate || '',
        rating: s.imdbRatingValue ? Number(s.imdbRatingValue) : 0,
        subjectType: s.subjectType || 0,
        hasResource: !!s.hasResource,
        detailPath: s.detailPath || '',
        subtitles: s.subtitles || '',
    };
}

// GET /aoneroom/suggest?keyword= — autocomplete suggestions (also bootstraps token).
router.get('/suggest', async (req, res) => {
    const keyword = (req.query.keyword || '').trim();
    if (!keyword) {
        return res.status(422).json({ error: 'keyword query param is required.' });
    }
    const token = await getGuestToken();
    const r = await fetch(`${BFF}/wefeed-h5api-bff/subject/search-suggest`, {
        method: 'POST',
        headers: { ...COMMON_HEADERS, Authorization: `Bearer ${token}` },
        body: JSON.stringify({ keyword, perPage: 10 }),
    });
    if (!r.ok) {
        throw new Error(`aoneroom suggest failed: ${r.status} ${r.statusText}`);
    }
    const data = await r.json();
    const items = (data?.data?.items || [])
        .map((it) => it?.word)
        .filter((w) => typeof w === 'string' && w.length);
    res.json({ suggestions: items });
});

// GET /aoneroom/search?keyword=&page=&perPage= — subject search results.
router.get('/search', async (req, res) => {
    const keyword = (req.query.keyword || '').trim();
    if (!keyword) {
        return res.status(422).json({ error: 'keyword query param is required.' });
    }
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const perPage = Math.min(24, Math.max(1, parseInt(req.query.perPage, 10) || 12));
    const body = { keyword, page, perPage };
    const data = await authedJson(`${BFF}/wefeed-h5api-bff/subject/search`, {
        method: 'POST',
        headers: { 'X-Source': 'downloader' },
        body: JSON.stringify(body),
    });
    if (!data || data.code !== 0) {
        throw new Error(`aoneroom search failed: ${data?.message || 'unknown error'}`);
    }
    const items = (data?.data?.items || []).map(mapSubject).filter(Boolean);
    const pager = data?.data?.pager || {};
    res.json({
        items,
        page: parseInt(pager.page, 10) || page,
        perPage,
        totalCount: parseInt(pager.totalCount, 10) || items.length,
        hasMore: !!pager.hasMore,
    });
});

// GET /aoneroom/detail?detailPath= — subject detail with seasons/episodes.
router.get('/detail', async (req, res) => {
    const detailPath = (req.query.detailPath || '').trim();
    if (!detailPath) {
        return res.status(422).json({ error: 'detailPath query param is required.' });
    }
    const r = await fetchJson(
        `${BFF}/wefeed-h5api-bff/detail?detailPath=${encodeURIComponent(detailPath)}`,
    );
    const data = await r.json();
    if (!data || data.code !== 0) {
        throw new Error(`aoneroom detail failed: ${data?.message || 'unknown error'}`);
    }
    const d = data.data || {};
    const subject = mapSubject(d.subject);
    const resource = d.resource || {};
    const seasons = (resource.seasons || []).map((s) => ({
        season: s.se || 1,
        maxEp: s.maxEp || 0,
        resolutions: (s.resolutions || []).map((r2) => r2.resolution),
    }));
    res.json({
        subject,
        source: resource.source || '',
        seasons,
    });
});

// GET /aoneroom/download?subjectId=&se=&ep=&detailPath= — resolved download links.
router.get('/download', async (req, res) => {
    const { subjectId, detailPath } = req.query;
    const se = parseInt(req.query.se, 10) || 1;
    const ep = parseInt(req.query.ep, 10) || 1;
    if (!subjectId || !detailPath) {
        return res.status(422).json({ error: 'subjectId and detailPath query params are required.' });
    }
    const params = new URLSearchParams({
        subjectId: String(subjectId),
        se: String(se),
        ep: String(ep),
        detailPath: String(detailPath),
    });
    params.set('supportCodecs[h264]', '1');
    const data = await authedJson(`${BFF}/wefeed-h5api-bff/subject/download?${params.toString()}`);
    if (!data || data.code !== 0) {
        throw new Error(`aoneroom download resolve failed: ${data?.message || 'unknown error'}`);
    }
    const d = data.data || {};
    const downloads = (d.downloads || [])
        .filter((f) => f && f.url && !f.vipLocked && !f.vip_locked)
        .map((f) => ({
            url: f.url,
            format: f.format || 'MP4',
            resolution: f.resolution || 0,
            size: Number(f.size) || 0,
            duration: Number(f.duration) || 0,
            codec: f.codecName || '',
        }));
    res.json({
        available: downloads.length > 0,
        downloads,
        captions: Array.isArray(d.captions) ? d.captions : [],
        hasResource: !!d.hasResource,
        vipLocked: !!d.vipLocked,
        reason: downloads.length ? '' : d.vipLocked ? 'vip_locked' : 'no_downloadable_format',
    });
});

// GET /aoneroom/file?subjectId=&se=&ep=&detailPath=&filename=&token= — stream a resolved
// episode file as a download attachment. Requires a valid single-use token
// minted by POST /download/claim so the 3-free-then-1-credit limit cannot
// be bypassed.
router.get('/file', async (req, res) => {
    const consumed = await consumeDownloadToken(req.query.token);
    if (!consumed.valid) {
        return res.status(403).json({ error: 'download_token_required', reason: consumed.reason });
    }
    const { subjectId, detailPath } = req.query;
    const se = parseInt(req.query.se, 10) || 1;
    const ep = parseInt(req.query.ep, 10) || 1;
    if (!subjectId || !detailPath) {
        return res.status(422).json({ error: 'subjectId and detailPath query params are required.' });
    }
    const params = new URLSearchParams({
        subjectId: String(subjectId),
        se: String(se),
        ep: String(ep),
        detailPath: String(detailPath),
    });
    params.set('supportCodecs[h264]', '1');
    const data = await authedJson(`${BFF}/wefeed-h5api-bff/subject/download?${params.toString()}`);
    if (!data || data.code !== 0) {
        throw new Error(`aoneroom download resolve failed: ${data?.message || 'unknown error'}`);
    }
    const d = data.data || {};
    const file = (d.downloads || []).find((f) => f && f.url && !f.vipLocked && !f.vip_locked);
    if (!file) {
        return res.status(404).json({
            error: 'download_unavailable',
            reason: d.vipLocked ? 'vip_locked' : 'no_downloadable_format',
        });
    }
    const upstream = await fetch(file.url, { headers: { 'User-Agent': UA, Referer: ORIGIN } });
    if (!upstream.ok) {
        throw new Error(`aoneroom file upstream failed: ${upstream.status} ${upstream.statusText}`);
    }
    const ext = 'mp4';
    const safeName =
        (req.query.filename && String(req.query.filename).replace(/[^\w.-]+/g, '_')) ||
        `apx-video_S${se}E${ep}.${ext}`;
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'video/mp4');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
    const len = upstream.headers.get('content-length');
    if (len) res.setHeader('Content-Length', len);
    Readable.fromWeb(upstream.body).pipe(res);
});

export default router;
