import { Router } from 'express';
import healthCheck from './health-check.js';
import tmdb from './tmdb.js';
import livetv from './livetv.js';
import youtube from './youtube.js';
import h2apk from './h2apk.js';
import download from './download.js';
import aoneroom from './aoneroom.js';

const router = Router();

export default () => {
    router.get('/health', healthCheck);
    router.use('/tmdb', tmdb);
    router.use('/livetv', livetv);
    router.use('/youtube', youtube);
    router.use('/h2apk', h2apk);
    router.use('/download', download);
    router.use('/aoneroom', aoneroom);

    return router;
};
