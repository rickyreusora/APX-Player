import { Router } from 'express';
import { Readable } from 'node:stream';
import {
    getQuota,
    claimDownload,
    consumeDownloadToken,
} from '../utils/downloadQuota.js';

// Download workflow mirrored from videodownloader.site (OmniSave).
//
// That site resolves a pasted video link through its public SEO BFF
// (api.seocloud.biz): submit a job, poll until it completes, then hand the
// browser a direct MP4 the service itself hosts. We only ever deliver files
// that job reports as completed and not VIP-locked — protected or
// unavailable sources are reported as such so the UI can offer in-app
// playback instead.

const router = Router();
const SEO_BFF = 'https://api.seocloud.biz';
const UA = 'ApXPlayer/1.0 (+https://maruyatvph.com)';
const POLL_INTERVAL_MS = 2500;
const POLL_ATTEMPTS = 24;

const ALLOWED_HOSTS = [
    'youtube.com',
    'youtu.be',
    'tiktok.com',
    'instagram.com',
    'facebook.com',
    'fb.com',
    'fb.watch',
    'x.com',
    'twitter.com',
    'xiaohongshu.com',
    'ted.com',
    'reddit.com',
];

function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

function parseSourceUrl(raw) {
    if (!raw || typeof raw !== 'string') return null;
    let parsed;
    try {
        parsed = new URL(raw.trim());
    } catch {
        return null;
    }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
    const host = parsed.hostname.replace(/^(www|m|vm|mobile)\./, '').toLowerCase();
    if (!ALLOWED_HOSTS.includes(host)) return null;
    return parsed.toString();
}

function platformOf(url) {
    const host = new URL(url).hostname.replace(/^(www|m|vm|mobile)\./, '').toLowerCase();
    if (host === 'youtu.be') return 'youtube';
    if (host === 'fb.com' || host === 'fb.watch') return 'facebook';
    if (host === 'twitter.com') return 'x';
    if (host === 'xiaohongshu.com') return 'rednote';
    return host.split('.')[0];
}

async function bff(path, options = {}) {
    const res = await fetch(`${SEO_BFF}${path}`, {
        ...options,
        headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'x-request-lang': 'en',
            'x-client-info': JSON.stringify({ timezone: 'UTC' }),
            'User-Agent': UA,
            Origin: 'https://videodownloader.site',
            Referer: 'https://videodownloader.site/',
            ...(options.headers || {}),
        },
    });
    if (!res.ok) {
        throw new Error(`download service failed: ${res.status} ${res.statusText}`);
    }
    return res.json();
}

// Submit a link and poll until the service finishes parsing it.
async function resolveLink(sourceUrl) {
    const submitted = await bff('/wefeed-seo-bff/video-job/submit', {
        method: 'POST',
        body: JSON.stringify({ sourceUrl }),
    });
    if (!submitted || submitted.code !== 0 || !submitted.taskId) {
        return {
            available: false,
            reason: 'submit_failed',
            message: (submitted && submitted.message) || 'The download service could not start this job.',
        };
    }

    const taskId = submitted.taskId;
    for (let attempt = 0; attempt < POLL_ATTEMPTS; attempt += 1) {
        await sleep(POLL_INTERVAL_MS);
        const status = await bff(
            `/wefeed-seo-bff/video-job/status?taskId=${encodeURIComponent(taskId)}`,
        );
        if (!status || status.code !== 0) continue;
        if (status.status === 'failed') {
            return {
                available: false,
                reason: 'job_failed',
                message: status.errorMessage || 'This link could not be downloaded.',
            };
        }
        if (status.status === 'completed' && status.result) {
            const formats = (status.result.formats || [])
                .filter((f) => f && f.url && !f.vipLocked && !f.videoOnly)
                .map((f) => ({
                    quality: f.formatNote || f.ext || 'MP4',
                    ext: f.ext || 'mp4',
                    size: Number(f.size) || 0,
                    url: f.url,
                }));
            if (!formats.length) {
                return {
                    available: false,
                    reason: status.result.vipLocked ? 'vip_locked' : 'no_downloadable_format',
                    title: status.result.title || '',
                };
            }
            return {
                available: true,
                title: status.result.title || '',
                platform: status.result.platform || platformOf(sourceUrl),
                thumbnail: status.result.thumbnail || '',
                formats,
            };
        }
    }
    return { available: false, reason: 'timeout' };
}

// GET /download/quota — remaining free downloads + credit balance for the caller.
router.get('/quota', async (req, res) => {
    try {
        const quota = await getQuota(req.headers.authorization);
        res.json(quota);
    } catch (err) {
        if (err?.status === 401) return res.status(401).json({ error: 'Sign in to view your download quota.' });
        throw err;
    }
});

// POST /download/claim — reserve one download (free or 1 credit) and mint a
// single-use token. The token is appended to the file URL as ?token=.
router.post('/claim', async (req, res) => {
    const source = (req.body && req.body.source) || 'link';
    let result;
    try {
        result = await claimDownload(req.headers.authorization, { source });
    } catch (err) {
        if (err?.status === 401) return res.status(401).json({ error: 'Sign in to download.' });
        throw err;
    }
    if (result.needsTopUp) {
        return res.status(402).json({
            needsTopUp: true,
            error: 'You have used all 3 free downloads and have no credits. Top up to keep downloading.',
        });
    }
    res.json(result);
});

// GET /download/resolve?kind=&id=&season=&episode= — catalog title download availability.
//
// ApX catalog titles (movies/TV from TMDB) play through the Videasy embed
// player. They are streaming sources with no authorized direct file to
// download, so we report them as streaming-only and the UI offers in-app
// playback instead. This keeps the downloader honest: only sources that
// actually permit a direct file are delivered as downloads.
router.get('/resolve', (req, res) => {
    const { kind, id } = req.query;
    if (!kind || !id) {
        return res.status(422).json({
            error: 'kind and id query params are required.',
        });
    }
    res.json({
        available: false,
        reason: 'streaming_only',
        message: 'ApX catalog titles stream in the in-app player; no direct file download is available.',
    });
});

// GET /download/file — catalog titles are streaming-only, so a direct file is
// never available. A valid download token is still required so the claim
// step (and therefore the quota) cannot be bypassed.
router.get('/file', async (req, res) => {
    const consumed = await consumeDownloadToken(req.query.token);
    if (!consumed.valid) {
        return res.status(403).json({ error: 'download_token_required', reason: consumed.reason });
    }
    res.status(404).json({
        error: 'download_unavailable',
        reason: 'streaming_only',
        message: 'This title is a streaming source with no direct file to download.',
    });
});

// GET /download/link/resolve?url= — report downloadable formats for a link.
router.get('/link/resolve', async (req, res) => {
    const sourceUrl = parseSourceUrl(req.query.url);
    if (!sourceUrl) {
        return res.status(422).json({
            error: 'Paste a full https link from a supported platform (YouTube, TikTok, Instagram, Facebook, X, RedNote, TED, or Reddit).',
        });
    }
    const result = await resolveLink(sourceUrl);
    res.json({ ...result, platform: result.platform || platformOf(sourceUrl) });
});

// GET /download/link/file?url=&format=&token= — stream a resolved file as a
// download. Requires a valid single-use token minted by POST /download/claim.
router.get('/link/file', async (req, res) => {
    const consumed = await consumeDownloadToken(req.query.token);
    if (!consumed.valid) {
        return res.status(403).json({ error: 'download_token_required', reason: consumed.reason });
    }
    const sourceUrl = parseSourceUrl(req.query.url);
    if (!sourceUrl) {
        return res.status(422).json({ error: 'A valid source link is required.' });
    }
    const result = await resolveLink(sourceUrl);
    if (!result.available) {
        return res.status(404).json({ error: 'download_unavailable', reason: result.reason });
    }
    const wanted = Number(req.query.format);
    const format = result.formats[Number.isInteger(wanted) ? wanted : 0] || result.formats[0];

    const upstream = await fetch(format.url, { headers: { 'User-Agent': UA } });
    if (!upstream.ok) {
        throw new Error(`download upstream failed: ${upstream.status} ${upstream.statusText}`);
    }

    const ext = (format.ext || 'mp4').replace(/[^\w]/g, '') || 'mp4';
    const safeName =
        (req.query.filename && String(req.query.filename).replace(/[^\w.-]+/g, '_')) ||
        `apx-video.${ext}`;
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'video/mp4');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
    const len = upstream.headers.get('content-length');
    if (len) res.setHeader('Content-Length', len);

    Readable.fromWeb(upstream.body).pipe(res);
});

export default router;
