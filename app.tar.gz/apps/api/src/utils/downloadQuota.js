// Server-side download quota + single-use token enforcement for the
// /downloader page.
//
// Flow:
//   1. Frontend calls POST /download/claim with the user's PocketBase JWT.
//   2. claimDownload() validates the user, decides free-vs-credit, deducts
//      atomically via the superuser client, and mints a single-use
//      download_token (10 min TTL).
//   3. The file-streaming endpoints call consumeDownloadToken(tokenId) to
//      validate + mark the token used before streaming. A token can only
//      be consumed once, so replaying a URL cannot bypass the limit.
//
// All writes go through the superuser PocketBase client because the users
// collection locks `credits` and `free_downloads_used` against self-edits.

import Pocketbase from 'pocketbase';
import adminPb from './pocketbaseClient.js';

export const FREE_DOWNLOAD_LIMIT = 3;
const TOKEN_TTL_MS = 10 * 60 * 1000; // 10 minutes
const POCKETBASE_HOST = 'http://localhost:8090';

function bearer(authHeader) {
    if (!authHeader || typeof authHeader !== 'string') {
        const e = new Error('Not authenticated');
        e.status = 401;
        throw e;
    }
    const m = authHeader.match(/^Bearer\s+(.+)$/i);
    if (!m) {
        const e = new Error('Not authenticated');
        e.status = 401;
        throw e;
    }
    return m[1];
}

// Validate the caller's JWT and return their user record. Uses a per-request
// client so the superuser client's authStore is never touched.
async function getAuthenticatedUser(authHeader) {
    const token = bearer(authHeader);
    const pb = new Pocketbase(POCKETBASE_HOST);
    pb.autoCancellation(false);
    pb.authStore.save(token, null);
    try {
        await pb.collection('users').authRefresh();
    } catch (err) {
        const e = new Error('Not authenticated');
        e.status = 401;
        throw e;
    }
    const record = pb.authStore.record;
    if (!record) {
        const e = new Error('Not authenticated');
        e.status = 401;
        throw e;
    }
    return record;
}

function readQuota(record) {
    const used = Math.max(0, Number(record.free_downloads_used) || 0);
    const credits = Math.max(0, Number(record.credits) || 0);
    return {
        freeUsed: used,
        freeRemaining: Math.max(0, FREE_DOWNLOAD_LIMIT - used),
        credits,
    };
}

// GET /download/quota — current remaining free downloads + credit balance.
export async function getQuota(authHeader) {
    const record = await getAuthenticatedUser(authHeader);
    return readQuota(record);
}

// POST /download/claim — reserve one download. Deducts a free download or
// one credit and mints a single-use token. Returns { needsTopUp: true } when
// the user has no free downloads and no credits.
export async function claimDownload(authHeader, { source = 'aoneroom' } = {}) {
    const record = await getAuthenticatedUser(authHeader);
    const { freeUsed, freeRemaining, credits } = readQuota(record);

    let kind;
    if (freeRemaining > 0) {
        kind = 'free';
    } else if (credits > 0) {
        kind = 'credit';
    } else {
        return { needsTopUp: true };
    }

    // Atomic deduction via the superuser client (locked fields).
    if (kind === 'free') {
        await adminPb.collection('users').update(record.id, {
            free_downloads_used: freeUsed + 1,
        });
    } else {
        const newBalance = credits - 1;
        await adminPb.collection('users').update(record.id, {
            credits: newBalance,
        });
        try {
            await adminPb.collection('credit_transactions').create({
                owner: record.id,
                amount: -1,
                type: 'usage',
                status: 'completed',
                method: 'system',
                notes: `Video download (${source})`,
                balance_after: newBalance,
            });
        } catch (_) {
            /* non-fatal — the deduction itself already landed */
        }
    }

    const expires = new Date(Date.now() + TOKEN_TTL_MS).toISOString();
    const token = await adminPb.collection('download_tokens').create({
        owner: record.id,
        used: false,
        kind,
        source,
        expires,
    });

    return {
        token: token.id,
        kind,
        remainingFree: kind === 'free' ? freeRemaining - 1 : 0,
        credits: kind === 'credit' ? credits - 1 : credits,
    };
}

// Validate and consume a single-use download token. Called by the
// file-streaming endpoints before delivering bytes.
export async function consumeDownloadToken(tokenId) {
    if (!tokenId || typeof tokenId !== 'string') {
        return { valid: false, reason: 'missing' };
    }
    let token;
    try {
        token = await adminPb.collection('download_tokens').getOne(tokenId);
    } catch (_) {
        return { valid: false, reason: 'invalid' };
    }
    if (token.used) {
        return { valid: false, reason: 'used' };
    }
    if (token.expires) {
        const exp = new Date(token.expires).getTime();
        if (Number.isFinite(exp) && exp < Date.now()) {
            return { valid: false, reason: 'expired' };
        }
    }
    // Mark used atomically — a concurrent replay lands on `used: true`.
    try {
        await adminPb.collection('download_tokens').update(tokenId, { used: true });
    } catch (_) {
        return { valid: false, reason: 'invalid' };
    }
    return { valid: true, kind: token.kind, owner: token.owner };
}
